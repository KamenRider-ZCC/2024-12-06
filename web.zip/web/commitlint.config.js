module.exports = {
  extends: ['./node_modules/@ballcat/commitlint-config-gitmoji']
}
