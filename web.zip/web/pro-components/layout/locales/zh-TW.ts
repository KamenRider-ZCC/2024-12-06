import settingDrawer from './zh-TW/settingDrawer'

export default {
  ...settingDrawer
}
