import settingDrawer from './zh-CN/settingDrawer'

export default {
  ...settingDrawer
}
