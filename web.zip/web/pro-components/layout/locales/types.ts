const locales = {
  'zh-CN': null,
  'en-US': null
}

export type LocaleType = keyof typeof locales
