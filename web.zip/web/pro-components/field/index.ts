export type ProFieldEmptyText = string | false
