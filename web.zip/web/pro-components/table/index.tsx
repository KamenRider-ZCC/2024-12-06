import ProTable from './Table'

export * from './Table'
export * from './typing'

export default ProTable
