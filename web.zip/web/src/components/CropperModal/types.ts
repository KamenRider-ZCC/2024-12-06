export interface FileObject {
  data: Blob
  name: string
}
