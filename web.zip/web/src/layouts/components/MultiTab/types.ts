export interface PageInfo {
  path: string
  name: string
  title: string
  params?: object
  query?: object
}
