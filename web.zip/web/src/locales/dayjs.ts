// dayjs 的 local 名称映射
export const localMapping: Record<string, string> = {
  'zh-CN': 'zh-cn',
  'en-US': 'en'
}
