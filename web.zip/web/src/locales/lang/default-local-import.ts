import localeValues from 'ant-design-vue/es/locale/zh_CN'
import 'dayjs/locale/zh-cn'

export default localeValues
