2023-5-20

## 结构

1、packages -> system 不要 api、components、hooks、styles、types

原因：组件之间耦合了，不清晰

例子：一个文件就是一个模块\组件

components 中的同样放到 system 目录下, 如：加前缀 bus-xxx

## 代码

style
reset.scss 放到 packages -> styles 

