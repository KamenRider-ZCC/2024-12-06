<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-12 11:40:45
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-17 11:33:59
 * @Description: 数据中心
-->
<template>
  <page-layout class="data-center-layout" />
</template>
<script setup lang="ts">
import { PageLayout } from '@mysteel-standard/components'
</script>
<style lang="scss" scoped>
.data-center-layout {
  :deep(.fixed-header) {
    border-bottom: 0;
  }
  :deep(.view-container) {
    padding: 16px;
  }
}
</style>
