/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-26 08:42:28
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-10-16 14:33:27
 * @Description:
 */
/// <reference types="vite/client" />
declare module '*.vue' {
  import { defineComponent } from 'vue'
  const Component: ReturnType<typeof defineComponent>
  export default Component
}
declare module 'gl-design-vue'
declare module '@mysteel-standard/components-business'
declare module '@/router'
declare module 'lodash-es'
