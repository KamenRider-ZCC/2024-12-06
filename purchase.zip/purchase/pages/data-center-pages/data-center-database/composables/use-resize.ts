/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-26 19:22:49
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-24 10:33:08
 * @Description:
 */
import { ref, Ref } from 'vue'
export default (dataToolsForm?: any, dataTableHeight?: Ref, isExcelPage?: boolean) => {
  const directoryWidth = ref(370)
  const indexHeight = ref(276)
  const dataTableRef = ref()
  const resizeEl = (e: { target: { nodeName: string } }, type?: string) => {
    if (type === 'side' && e.target.nodeName === 'svg') return
    document.onmousemove = (e) => mouseMove(e, type)
    document.onmouseup = () => {
      document.onmousemove = null
      document.onmouseup = null
    }
  }
  const mouseMove = (e: { clientX: number; clientY: number }, type?: string) => {
    const ev = e || window.event
    if (type === 'side') {
      directoryWidth.value = ev.clientX - 16
      if (directoryWidth.value > 660) {
        directoryWidth.value = 660
      } else if (directoryWidth.value < 370) {
        directoryWidth.value = 370
      }
    } else {
      const h = isExcelPage ? 121 : 215
      indexHeight.value = ev.clientY - h
      const statisticalTableHeight = dataToolsForm.statistical ? 160 : 0
      console.log('statisticalTableHeight', statisticalTableHeight)
      console.log('dataTableRef', dataTableRef.value?.clientHeight)
      if (dataTableHeight) {
        dataTableHeight.value = dataTableRef.value?.clientHeight - statisticalTableHeight
      }
    }
  }
  const isExpand = ref(true)
  const directoryRef = ref()
  const expandSide = () => {
    isExpand.value = !isExpand.value
    if (isExpand.value) {
      directoryWidth.value = 370
      directoryRef.value.style.display = 'block'
    } else {
      directoryWidth.value = 0
      directoryRef.value.style.display = 'none'
    }
  }
  return {
    directoryWidth,
    resizeEl,
    isExpand,
    expandSide,
    directoryRef,
    indexHeight,
    dataTableRef
  }
}
