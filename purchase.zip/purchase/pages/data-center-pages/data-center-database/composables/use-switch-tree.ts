/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 11:23:44
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-11 14:11:55
 * @Description:
 */
import { TabList } from '../types/interface'
import { enumToArray } from '@mysteel-standard/utils'
import { nextTick, computed, ref, onMounted } from 'vue'
export default () => {
  const treeRef = ref()
  const tabIndex = ref(TabList['公司数据库'])
  const tabData = ref(enumToArray(TabList))
  const tabName = computed(() => {
    return tabIndex.value === TabList['我的收藏'] ? 'my-collection-tree' : 'company-tree'
  })
  const tabClick = (e: { target: { value: number } }) => {
    const { value } = e.target
    nextTick(() => {
      value === TabList['我的收藏'] && treeRef.value.getMyCollectionTree()
      if (!treeRef.value?.companyTreeData?.length) {
        value === TabList['公司数据库'] && treeRef.value.getCompanyTree()
      }
    })
  }
  onMounted(() => {
    treeRef.value.getCompanyTree && treeRef.value?.getCompanyTree()
  })
  return {
    tabName,
    tabIndex,
    tabData,
    treeRef,
    tabClick
  }
}
