/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-03 08:24:52
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-12 15:38:12
 * @Description:
 */
export default () => {
  const searchValue = ref('')
  const indexSearchTitle = ref('')
  const indexSearchVisible = ref(false)
  const searchIndexRef = ref()
  const searchIndex = () => {
    indexSearchTitle.value = '指标搜索'
    indexSearchVisible.value = true
    if (!searchValue.value) return
    nextTick(() => {
      searchIndexRef.value.handleSearch()
    })
  }
  //添加指标
  const dataBaseRef = ref()
  const addIndex = (data: any[]) => {
    dataBaseRef.value.addIndex(data)
  }
  //提取、添加指标
  const extractOrAddIndex = async (data: any[], isExTract: boolean, isAddExtract?: boolean) => {
    dataBaseRef.value.addIndex(data, isExTract, isAddExtract)
  }
  return {
    searchValue,
    indexSearchTitle,
    indexSearchVisible,
    searchIndex,
    searchIndexRef,
    dataBaseRef,
    extractOrAddIndex,
    addIndex
  }
}
