import api from '../../api/index'
import useTree from '../../hooks/use-tree'
import { ref } from 'vue'
/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 10:38:19
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-07 09:52:38
 * @Description:
 */
export default (emits: any, isDirectory?: boolean) => {
  const treeLoading = ref<boolean>(false)
  const treeData = ref([
    {
      moduleType: 1,
      label: '我的收藏',
      type: 1,
      pid: 0,
      id: 0,
      children: [],
      isLeaf: false,
      isEnd: 0
    }
  ])
  const replaceFields = ref({
    children: 'children',
    title: 'label',
    key: 'id'
  })
  //点击展开收起、多选
  const { selectedTreeKeys, selectedTreeNodes, expandedKeys, nodeClick, treeExpand, allCollapse } =
    useTree(isDirectory)
  const getTreeData = async () => {
    treeLoading.value = true
    const params = {
      isDirectory: isDirectory ? '1' : '0' // 是否只查目录 0否 1是
    }
    const { err, res } = await api.getCollectIndexList(params)
    treeLoading.value = false
    if (!err && res) {
      const { data } = res
      treeData.value[0].children = data || []
    }
  }
  //展开收起
  const dbClick = (node: { isLeaf: boolean; data: Object }) => {
    selectedTreeNodes.value = []
    selectedTreeKeys.value = []
    if (node.isLeaf) {
      emits('db-click-node', [node.data], false, true)
    }
  }
  return {
    treeData,
    replaceFields,
    selectedTreeKeys,
    expandedKeys,
    getTreeData,
    treeLoading,
    nodeClick,
    dbClick,
    selectedTreeNodes,
    treeExpand,
    allCollapse
  }
}
