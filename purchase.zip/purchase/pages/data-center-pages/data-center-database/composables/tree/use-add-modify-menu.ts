/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 11:23:44
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-05 09:12:45
 * @Description:
 */
import { CollectTreeType, MenuFormType } from '../../types/interface'
import { message } from 'gl-design-vue'
import api from '../../api/index'
import { useResetData } from '@mysteel-standard/hooks'
export default (getTreeData: Function) => {
  const { dataState: addModifyMenuForm, resetDataState: resetAddModifyMenuForm } = useResetData({
    catalogName: '',
    id: undefined
  })
  const addModifyMenuVisible = ref(false)
  const addModifyMenuTitle = ref('')
  const isEdit = ref(false)
  //新增编辑目录
  const sureAddModifyMenu = async (formData: MenuFormType) => {
    const menuApi = isEdit.value ? api.editMenu : api.addMenu
    const type = formData.isLeaf ? 2 : 1 //类型，1：目录，2：指标
    const params = {
      pid: formData.pid,
      catalogName: formData.catalogName,
      id: formData.id || undefined,
      type
    }
    const { err } = await menuApi(params)
    if (!err) {
      addModifyMenuVisible.value = false
      getTreeData()
      message.success(isEdit.value ? '编辑成功！' : '新增成功！')
    }
  }
  // 新增编辑目录弹窗
  const addModifyMenu = (item: { label: string; id?: number }, data: CollectTreeType) => {
    isEdit.value = item.label === '编辑目录' ? true : false
    addModifyMenuVisible.value = true
    addModifyMenuTitle.value = item.label
    let obj = {}
    if (!isEdit.value) {
      //新增
      resetAddModifyMenuForm() //重置
      obj = {
        ...addModifyMenuForm,
        pid: data.id
      }
    } else {
      obj = {
        catalogName: data.catalogName,
        id: data.id
      }
    }
    Object.assign(addModifyMenuForm, obj)
  }
  return {
    addModifyMenuTitle,
    addModifyMenuForm,
    addModifyMenuVisible,
    sureAddModifyMenu,
    addModifyMenu
  }
}
