/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 16:12:30
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-12 16:18:00
 * @Description:
 */
import { message } from 'gl-design-vue'
import { Modal } from 'gl-design-vue'
import { createVNode } from 'vue'
import { ExclamationCircleOutlined } from '@ant-design/icons-vue'
import api from '../../api/index'
import useAddModifyMenu from './use-add-modify-menu'
import { OperationMenuType, CollectTreeType } from '../../types/interface'

export default (
  getTreeData: Function,
  emits: any,
  isDirectory: boolean,
  allCollapse: Function,
  selectedTreeNodes?: Ref
) => {
  //新增编辑目录
  const {
    addModifyMenuTitle,
    addModifyMenuForm,
    addModifyMenuVisible,
    sureAddModifyMenu,
    addModifyMenu
  } = useAddModifyMenu(getTreeData)

  //删除目录
  const sureDelete = async (data: CollectTreeType, isDelete: boolean) => {
    const ids: any[] = []
    selectedTreeNodes?.value.map((item: any) => {
      ids.push(item.id)
    })
    const { err } = await api.deleteMenu(ids)
    if (!err) {
      message.success(isDelete ? '删除成功' : '取消收藏成功')
      // 刷新树
      getTreeData()
    }
  }
  const deleteMenu = (
    item: Object,
    data: CollectTreeType,
    message = '确定删除吗？',
    isDelete = true
  ) => {
    //二次确认提示
    Modal.confirm({
      title: message,
      icon: createVNode(ExclamationCircleOutlined),
      onOk() {
        sureDelete(data, isDelete)
      }
    })
  }
  //添加指标、提取指标
  const handleIndex = (item: OperationMenuType, data: CollectTreeType) => {
    if (data.isLeaf) {
      emits('extract-or-add-index', selectedTreeNodes?.value, item.label === '提取指标')
    } else {
      // 文件夹
      Modal.confirm({
        title: item.label === '添加指标' ? '添加文件夹下所有指标？' : '提取文件夹下所有指标？',
        icon: createVNode(ExclamationCircleOutlined),
        onOk() {
          const nodeData = getItem([data])
          emits('extract-or-add-index', nodeData, item.label === '提取指标')
        }
      })
    }
  }
  // 选中后进行数据递归过滤
  const getItem = (data: CollectTreeType[]): CollectTreeType[] => {
    let result = []
    result = data.filter((item) => item.isLeaf)
    for (const item of data) {
      if (item.children) {
        result = result.concat(getItem(item.children))
      }
    }
    return result
  }
  //取消收藏
  const cancelCollect = (item: { label: string }, data: CollectTreeType) => {
    deleteMenu(item, data, '确定取消收藏？', false)
  }
  const operationMenu = <OperationMenuType>{
    新增目录: addModifyMenu,
    编辑目录: addModifyMenu,
    删除目录: deleteMenu,
    添加指标: handleIndex,
    提取指标: handleIndex,
    取消收藏: cancelCollect,
    全部收起: allCollapse
  }
  const menuClick = (item: { label: string }, data: Object) => {
    operationMenu[item.label](item, data)
  }
  const treeMenu = [
    {
      label: '新增目录',
      condition: (data: { isLeaf: boolean; type: number }) => data.type === 1,
      handle: menuClick
    },
    {
      label: '编辑目录',
      condition: (data: { isLeaf: boolean; id: number; type: number }) =>
        data.type === 1 && data.id !== 0,
      handle: menuClick
    },
    {
      label: '删除目录',
      condition: (data: { isLeaf: boolean; id: number; type: number }) =>
        data.type === 1 && data.id !== 0,
      handle: menuClick
    },
    {
      label: '添加指标',
      condition: () => !isDirectory,
      handle: menuClick
    },
    {
      label: '提取指标',
      condition: () => !isDirectory,
      handle: menuClick
    },
    {
      label: '取消收藏',
      condition: (data: { isLeaf: boolean; type: number }) => data.isLeaf && data.type === 2,
      handle: menuClick
    },
    {
      label: '全部收起',
      handle: menuClick
    }
  ]

  return {
    treeMenu,
    menuClick,
    //新增编辑目录
    addModifyMenuTitle,
    addModifyMenuForm,
    addModifyMenuVisible,
    sureAddModifyMenu
  }
}
