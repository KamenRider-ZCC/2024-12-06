<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 13:47:39
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-15 10:47:26
 * @Description: 
-->
<template>
  <div class="tag-box" v-for="item in typesList" :key="item.key">
    <div class="tags-bar flex" v-if="item.list && item.list.length">
      <div class="type">{{ item.tagName }}：</div>
      <div
        class="tags flex flex1"
        :class="{ 'tags-more': item.isShowMore }"
        v-if="!item.isShowMulti"
      >
        <div
          class="tag flex-c"
          v-for="listItem in item.list"
          :key="item.key + listItem"
          @click="chooseTag(item.key, [listItem])"
        >
          {{ listItem }}
        </div>
      </div>
      <!-- 多选 -->
      <div class="mult pos-r flex1" v-if="item.isShowMulti">
        <div class="tag-group">
          <gl-checkbox-group
            v-model:value="checkedVariety"
            name="checkboxgroup"
            :options="item.list"
          />
        </div>
        <div class="pos-a btns flex-c">
          <gl-button @click="item.isShowMulti = false">取消</gl-button>
          <gl-button @click="chooseTag(item.key, checkedVariety)" type="primary"> 确定 </gl-button>
        </div>
      </div>
      <div class="btn-right flex" v-if="!item.isShowMulti">
        <gl-button ghost type="primary" v-if="item.list.length > 8" @click="showMore(item)">
          <icon
            :name="item.isShowMore ? 'icon-down_outlined' : 'icon-arrow-down'"
            color="#023985"
          />
          {{ item.isShowMore ? '收起' : '更多' }}
        </gl-button>
        <gl-button ghost type="primary" v-if="item.list.length > 2" @click="showMulti(item)">
          多选
          <icon name="icon-add" color="#023985" />
        </gl-button>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
interface TagObject {
  varietyList: string[]
  cityList: string[]
  companyList: string[]
  indexList: string[]
}
interface Props {
  tagListData: TagObject
}
interface TypeList {
  key: string
  tagName: string
  list: string[]
  isShowMore: boolean
  isShowMulti: boolean
}
interface Emits {
  (e: 'query-index', key: string, curSelect: any[]): void
}

const props = defineProps<Props>()
const emits = defineEmits<Emits>()
const typesList = ref<TypeList[]>([])

watch(
  () => props.tagListData,
  (val) => {
    const { varietyList, cityList, companyList, indexList } = val
    typesList.value = [
      {
        key: 'varietyList',
        tagName: '品种',
        list: varietyList,
        isShowMore: false,
        isShowMulti: false
      },
      {
        key: 'cityList',
        tagName: '城市',
        list: cityList,
        isShowMore: false,
        isShowMulti: false
      },
      {
        key: 'companyList',
        tagName: '企业',
        list: companyList,
        isShowMore: false,
        isShowMulti: false
      },
      {
        key: 'indexList',
        tagName: '指标',
        list: indexList,
        isShowMore: false,
        isShowMulti: false
      }
    ]
  },
  { deep: true }
)

const checkedVariety = ref<string[]>([])
const chosenTags = reactive<string[]>([])
const chooseTag = (key: string, item: string[]) => {
  chosenTags.length = 0
  chosenTags.push(...item)
  emits('query-index', key, chosenTags)
}
const showMore = (item: any) => {
  item.isShowMore = !item.isShowMore
}
const showMulti = (item: any) => {
  item.isShowMulti = true
  item.isShowMore = false
}
</script>
<style lang="scss">
@import '../../style/search-condition.scss';
</style>
