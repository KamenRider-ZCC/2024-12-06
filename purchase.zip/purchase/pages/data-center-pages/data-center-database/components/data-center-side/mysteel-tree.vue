<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 14:06:16
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-12 16:13:43
 * @Description: 
-->
<template>
  <gl-spin :spinning="mysteelTreeLoading">
    <ms-tree
      v-model:selectedKeys="mysteelSelectedKeys"
      v-model:expandedKeys="mysteelExpandedKeys"
      autoExpandParent
      block-node
      multiple
      :tree-data="mysteelTreeData"
      :fieldNames="mysteelFields"
      @select="mysteelNodeClick"
      @menu-click="mysteelMenuClick"
      :load-data="mysteelTreeLoad"
      @expand="mysteelTreeExpand"
    >
      <template #default="{ data }">
        <tree-node-mysteel :data="data" :list="mysteelTreeMenu" @dblclick="mysteelDbClick(data)">
          <template #menu>
            <node-menu
              v-if="mysteelTreeMenu && mysteelTreeMenu.length"
              :list="mysteelTreeMenu"
              :data="data"
            />
          </template>
        </tree-node-mysteel>
      </template>
    </ms-tree>
  </gl-spin>
</template>
<script setup lang="ts">
import { MsTree, TreeNodeMysteel, NodeMenu } from '@mysteel-standard/components'
import useMysteelTree from '../../composables/tree/use-mysteel-tree'
import { MysteelDataType } from '../../types/interface'
interface Emits {
  (e: 'db-click-node', data: any[], isExtract: boolean, isAddExtract: boolean): void
  (e: 'collect-index', label: string, data: Object): void
  (e: 'extract-or-add-index', isExTract: boolean, nodes: MysteelDataType[]): void //添加提取指标
}
const emits = defineEmits<Emits>()
interface Props {
  frameIds: any[]
  indexIds: any[]
}
const props = defineProps<Props>()

const {
  treeData: mysteelTreeData,
  replaceFields: mysteelFields,
  selectedTreeKeys: mysteelSelectedKeys,
  expandedKeys: mysteelExpandedKeys,
  treeLoading: mysteelTreeLoading,
  treeMenu: mysteelTreeMenu,
  nodeClick: mysteelNodeClick,
  menuClick: mysteelMenuClick,
  dbClick: mysteelDbClick,
  onLoadData: mysteelTreeLoad,
  getTreeData: getMysteelTree,
  treeExpand: mysteelTreeExpand
} = useMysteelTree(emits, props)

defineExpose({ getMysteelTree })
</script>
