<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 11:23:44
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-12 16:15:24
 * @Description: 
-->
<template>
  <!-- 我的收藏 -->
  <gl-spin :spinning="collectionTreeLoading">
    <MsTree
      v-model:selectedKeys="myCollectionSelectedKeys"
      v-model:expandedKeys="myCollectionExpandedKeys"
      autoExpandParent
      block-node
      draggable
      multiple
      :tree-data="myCollectionTreeData"
      :fieldNames="myCollectionFields"
      :node-menus="myCollectionTreeMenu"
      @select="myCollectionNodeClick"
      @menu-click="myCollectionMenuClick"
      @drop="dropMyCollectionTree"
      @db-click="dbClick"
      @expand="myCollectionTreeExpand"
    />
    <add-modify-menu-modal
      v-if="addModifyMenuVisible"
      :addModifyMenuForm="addModifyMenuForm"
      v-model:addModifyMenuVisible="addModifyMenuVisible"
      :visibleTitle="addModifyMenuTitle"
      @sure-add-modify-menu="sureAddModifyMenu"
    />
  </gl-spin>
</template>
<script setup lang="ts">
import { MsTree } from '@mysteel-standard/components'
import useMyCollectionTree from '../../composables/tree/use-my-collection-tree'
import useMyCollectionTreeMenu from '../../composables/tree/use-my-collection-tree-menu'
import useTreeDrag from '../../composables/tree/use-tree-drag'
import { CollectTreeType } from '../../types/interface'
import AddModifyMenuModal from './add-modify-menu-modal.vue'
interface Emits {
  (e: 'db-click-node', data: any[], isExtract: boolean, isAddExtract: boolean): void //双击添加指标
  (e: 'extract-or-add-index', isExTract: boolean, nodes: CollectTreeType[]): void //添加提取指标
}
const emits = defineEmits<Emits>()
// 我的收藏树
const {
  treeData: myCollectionTreeData,
  replaceFields: myCollectionFields,
  selectedTreeKeys: myCollectionSelectedKeys,
  expandedKeys: myCollectionExpandedKeys,
  getTreeData: getMyCollectionTree,
  treeLoading: collectionTreeLoading,
  nodeClick: myCollectionNodeClick,
  dbClick,
  selectedTreeNodes,
  treeExpand: myCollectionTreeExpand,
  allCollapse
} = useMyCollectionTree(emits)
//树菜单操作
const {
  treeMenu: myCollectionTreeMenu,
  menuClick: myCollectionMenuClick,
  addModifyMenuTitle,
  addModifyMenuForm,
  addModifyMenuVisible,
  sureAddModifyMenu
} = useMyCollectionTreeMenu(
  getMyCollectionTree,
  emits,
  false, //是否是目录
  allCollapse,
  selectedTreeNodes
)
//树拖拽
const { handleDrop: dropMyCollectionTree } = useTreeDrag(getMyCollectionTree, collectionTreeLoading)
defineExpose({ getMyCollectionTree })
</script>
