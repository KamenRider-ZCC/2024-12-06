/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-26 11:21:00
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-13 15:25:02
 * @Description:计算弹窗formItems配置
 */
export const FREQUENCY_LIST = [
  {
    name: '日度',
    value: 1
  },
  {
    name: '周度',
    value: 2
  },
  {
    name: '月度',
    value: 3
  },
  {
    name: '季度',
    value: 4
  },
  {
    name: '半年度',
    value: 5
  },
  {
    name: '年度',
    value: 6
  }
]
export const CAL_WAY_LOW_LIST = [
  { name: '合计值', value: 'sum' },
  { name: '平均值', value: 'avg' },
  { name: '第一条', value: 'first' },
  { name: '最后一条', value: 'last' },
  { name: '最大值', value: 'max' },
  { name: '最小值', value: 'min' }
]
export const CAL_WAY_HEIGHT_LIST = [
  { name: '分拆', value: 'avg' },
  { name: '复制', value: 'copy' }
]

export const MOVEMENT_LIST = [
  { name: '前移', value: 0 },
  { name: '后移', value: 1 }
]
export const RADIO_LIST = [
  {
    name: '百分比变化',
    value: 0
  },
  {
    name: '数值变化',
    value: 1
  }
]
export const INTERVAL_SUM_LIST = [
  {
    name: '周',
    id: 0,
    value: 'week'
  },
  {
    name: '月',
    id: 1,
    value: 'month'
  },
  {
    name: '季',
    id: 2,
    value: 'quarter'
  },
  {
    name: '半年',
    id: 3,
    value: 'halfyear'
  },
  {
    name: '年',
    id: 4,
    value: 'year'
  }
]
export const CALCULATION_FORMITEMS: any = {
  变频: [
    {
      type: 'select',
      label: '新频度',
      name: 'newFrequency',
      options: FREQUENCY_LIST
    },
    {
      type: 'select',
      label: '降低频率',
      name: 'calWayLow',
      options: CAL_WAY_LOW_LIST,
      disabled: 'calWayLowDisabled'
    },
    {
      type: 'select',
      label: '提高帧率',
      name: 'calWayHigh',
      options: CAL_WAY_HEIGHT_LIST,
      disabled: 'calWayHighDisabled'
    }
  ],
  后置: [
    {
      label: '区间数(正数向前,负数向后)',
      name: 'interval',
      type: 'number',
      controls: true,
      labelCol: { style: { width: '195px' } }
    }
  ],
  指数化: [
    {
      label: '基期',
      name: 'date',
      type: 'datePicker',
      width: '200px'
    },
    {
      label: '基点(1-1000)',
      name: 'point',
      type: 'number',
      min: '1',
      max: '1000',
      controls: true
    }
  ],
  替换数据: [
    {
      label: '替换前数据',
      name: 'preData',
      type: 'input-number'
    },
    {
      label: '替换后数据',
      name: 'postData',
      type: 'input-number'
    }
  ],
  区间求和: [
    {
      label: '区间求和',
      name: 'rangeInterval',
      type: 'select',
      options: INTERVAL_SUM_LIST
    }
  ],
  移动平均: [
    {
      label: '移动设置',
      name: 'moveType',
      type: 'radioGroup',
      options: MOVEMENT_LIST
    },
    {
      label: '移动期数',
      name: 'moveValue',
      type: 'number'
    }
  ],
  HP滤波: [
    {
      label: '平滑系数',
      name: 'lambdaPara',
      type: 'number'
    }
  ]
}
