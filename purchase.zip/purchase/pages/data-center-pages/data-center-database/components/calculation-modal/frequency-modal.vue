<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-19 11:04:48
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-13 16:05:22
 * @Description: 
-->
<template>
  <form-modal
    :title="visibleTitle"
    v-model:visible="visible"
    :formItems="formItems"
    v-model:formParams="form"
    :formConfig="formConfig"
    @ok="handleOk"
    @change-item="changeForm"
  ></form-modal>
</template>
<script setup lang="ts">
import {
  //变频
  FREQUENCY_LIST,
  CAL_WAY_LOW_LIST,
  CAL_WAY_HEIGHT_LIST
} from '../constants/calculation'
import { message } from 'gl-design-vue'
import { FrequencyEnum } from '../../types/interface'
import { FormModal } from '@mysteel-standard/components'
interface CalculationForm {
  newFrequency: number
  calWayLow: string
  calWayHigh: string
}
interface Props {
  calculationVisible: boolean
  visibleTitle: string
  calculationForm: CalculationForm
  tableSelection: any[]
}

interface Emits {
  (e: 'update:calculationVisible', val: boolean): void
  (e: 'submit', form: Object): void
}

const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  calculationVisible: false,
  visibleTitle: ''
})
const form = ref({ ...props.calculationForm, calWayLowDisabled: false, calWayHighDisabled: false })
const selection = computed(() => props.tableSelection)

const visible = computed({
  get() {
    return props.calculationVisible
  },
  set(val: boolean) {
    emits('update:calculationVisible', val)
  }
})

const formConfig = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 }
}
const formItems = computed(() => [
  {
    type: 'select',
    label: '新频度',
    name: 'newFrequency',
    options: FREQUENCY_LIST
  },
  {
    type: 'select',
    label: '降低频率',
    name: 'calWayLow',
    options: CAL_WAY_LOW_LIST,
    disabled: form.value.calWayLowDisabled
  },
  {
    type: 'select',
    label: '提高帧率',
    name: 'calWayHigh',
    options: CAL_WAY_HEIGHT_LIST,
    disabled: form.value.calWayHighDisabled
  }
])
const frequencyToDays = {
  日度: 1,
  周度: 7,
  旬度: 10,
  月度: 30,
  季度: 90,
  半年度: 180,
  年度: 365
}
const differentFre = (value: number) => {
  const arr = selection.value.map((item) => item.frequency)
  const setArray = [...new Set(arr)]
  if (arr.length === 1 || setArray.length === 1) {
    let frequency = arr[0]
    if (frequencyToDays[frequency] > value) {
      form.value.calWayLowDisabled = true
      form.value.calWayHighDisabled = false
    } else if (frequencyToDays[frequency] < value) {
      form.value.calWayLowDisabled = false
      form.value.calWayHighDisabled = true
    } else {
      form.value.calWayLowDisabled = true
      form.value.calWayHighDisabled = true
    }
  } else {
    form.value.calWayLowDisabled = false
    form.value.calWayHighDisabled = false
  }
}
const frequencyName = {
  1: '日度',
  2: '周度',
  3: '月度',
  4: '季度',
  5: '半年度',
  6: '年度',
  7: '旬度'
}
const changeForm = (item: any) => {
  if (item.name === 'newFrequency') {
    const type = frequencyName[form.value[item.name]]
    differentFre(frequencyToDays[type])
  }
}
const handleOk = () => {
  if (form.value.calWayLowDisabled && form.value.calWayHighDisabled) {
    message.error('同原指标频度相同，请重新选择频度!')
    return
  }
  const { newFrequency, calWayLow, calWayHigh } = form.value
  const data = {
    newFrequency,
    calWayLow,
    calWayHigh
  }
  emits('submit', data)
  handleCancel()
}
const handleCancel = () => {
  visible.value = false
}

watch(
  () => visible.value,
  (val: any) => {
    if (val) {
      const type = frequencyName[form.value.newFrequency]
      differentFre(frequencyToDays[type])
    }
  },
  { deep: true, immediate: true }
)
</script>
