<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-19 11:04:48
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-07 16:15:35
 * @Description: 
-->
<template>
  <gl-modal
    v-model:visible="visible"
    centered
    :title="visibleTitle"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <gl-form :model="form" labelAlign="right" ref="formRef">
      <gl-form-item label="变化类型">
        <gl-select v-model:value="form.changeType">
          <gl-select-option v-for="(item, i) in changeTypeArr" :key="i" :value="item.value">
            {{ item.label }}
          </gl-select-option>
        </gl-select>
      </gl-form-item>
      <gl-form-item label="变化选项">
        <gl-radio-group v-model:value="form.changeOption">
          <gl-radio v-for="(item, i) in changeOptionArr" :value="item.value" :key="i">
            {{ item.name }}
          </gl-radio>
        </gl-radio-group>
      </gl-form-item>
      <gl-form-item label="环比期数">
        <gl-input-number :disabled="form.changeOption === 'yoy'" v-model:value="form.seqPeriod" />
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>
<script setup lang="ts">
import { enumToArray } from '@mysteel-standard/utils'
import { message } from 'gl-design-vue'
interface CalculationForm {
  changeOption: string
  changeType: number
  seqPeriod: undefined | number
}
interface Props {
  calculationVisible: boolean
  visibleTitle: string
  calculationForm: CalculationForm
}
enum ChangeTypeArr {
  百分比变化 = 0,
  数值变化 = 1
  // 累计平均值 = 3
}
interface Emits {
  (e: 'update:calculationVisible', val: boolean): void
  (e: 'submit', form: Object): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  calculationVisible: false,
  visibleTitle: ''
})

const form = computed(() => props.calculationForm)
const visible = computed({
  get() {
    return props.calculationVisible
  },
  set(val: boolean) {
    emits('update:calculationVisible', val)
  }
})
const changeTypeArr = ref(enumToArray(ChangeTypeArr))
const changeOptionArr = [
  {
    name: '同比',
    value: 'yoy'
  },
  {
    name: '环比',
    value: 'qoq'
  }
]

const handleOk = () => {
  const { changeOption, seqPeriod } = form.value
  if (changeOption === 'qoq' && !seqPeriod) {
    message.error('环比期数不能为空！')
    return
  }
  emits('submit', form.value)
  handleCancel()
}
const handleCancel = () => {
  visible.value = false
}
</script>
