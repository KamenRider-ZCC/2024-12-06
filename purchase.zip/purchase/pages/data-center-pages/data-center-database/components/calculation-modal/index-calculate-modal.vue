<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-19 11:04:48
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-15 11:24:15
 * @Description: 
-->
<template>
  <form-modal
    :title="visibleTitle"
    v-model:visible="visible"
    :formItems="formItems"
    v-model:formParams="form"
    @ok="handleOk"
  ></form-modal>
</template>
<script setup lang="ts">
import { FormModal } from '@mysteel-standard/components'
import { message } from 'gl-design-vue'
interface Props {
  calculationVisible: boolean
  visibleTitle: string
  calculationForm: any
  calculationFormItem: any[]
}

interface Emits {
  (e: 'update:calculationVisible', val: boolean): void
  (e: 'submit', form: any): void
}
const emits = defineEmits<Emits>()
const props = defineProps<Props>()
const form = computed(() => props.calculationForm)
const formItems = computed(() => props.calculationFormItem)
const visible = computed({
  get() {
    return props.calculationVisible
  },
  set(val: boolean) {
    emits('update:calculationVisible', val)
  }
})

const handleOk = () => {
  if (form.value.deriveOption === 13 && !form.value.moveValue) {
    //移动平均:13
    message.error('移动期数不能为空！')
    return
  }
  emits('submit', form.value)
  handleCancel()
}
const handleCancel = () => {
  visible.value = false
}
</script>
