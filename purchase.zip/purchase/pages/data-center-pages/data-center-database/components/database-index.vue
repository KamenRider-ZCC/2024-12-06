<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-12 09:47:40
 * @LastEditors: zouchuanfeng
 * @Description: 
-->
<template>
  <gl-layout class="data-center-wrap">
    <slot name="side" ref="sideRef" />
    <gl-layout-content class="data-center-content">
      <div class="data-center-top-button">
        <data-center-top-button
          :dateForm="dateForm"
          :tableSelection="indexTableSelection"
          @collect="collectData"
          @remove="removeCheck"
          @change-date="changeDate"
          @extract="exTractData"
        />
      </div>
      <!-- 指标、图表 begin -->
      <gl-tabs v-model:activeKey="activeTab">
        <gl-tab-pane :key="1" tab="指标">
          <div class="data-center-index" :style="{ height: `${indexHeight}px` }">
            <!-- 指标-->
            <index-top-button
              :tableSelection="indexTableSelection"
              @handle-calculation="indexCalculation"
              @extract="exTractData"
            />
            <div class="data-center-index-table">
              <index-table
                :loading="indexTableLoading"
                v-model:tableData="indexTableData"
                v-model:tableSelection="indexTableSelection"
                @invert-check="invertCheck"
                @remove-check="removeCheck"
                @extract="exTractData"
                @delete-row="deleteRow"
                @select-change="selectChange"
              />
            </div>
            <div id="resize-up-div" @mousedown="resizeEl">
              <!-- <div class="move-outlined">
                <icon name="icon-move_outlined" color="#333" />
              </div> -->
            </div>
          </div>
          <!-- 数据详情 -->
          <div class="data-center-data-table">
            <data-top-button
              ref="dataTopButtonRef"
              :tableSelection="indexTableSelection"
              @data-tool-operation="dataToolsOperation"
              @extract="exTractData"
              @export="exportData"
              @flex-col-width="flexColWidth"
              :disabled="!dataTableData.length"
            />
            <div class="data-center-data-info" ref="dataTableRef">
              <div class="data-table" :style="{ height: `${dataTableHeight}px` }">
                <data-table
                  ref="detailTable"
                  :loading="dataTableLoading"
                  :headList="dataTableHeadList"
                  v-model:tableData="dataTableData"
                  @view-index-info="viewIndexInfo"
                  :dateForm="dateForm"
                />
              </div>
              <!-- 统计 -->
              <div class="statistical-table" v-if="dataToolsForm.statistical">
                <data-table
                  key="statistical"
                  :loading="statisticalTableLoading"
                  v-model:tableData="statisticalTableData"
                  :headList="statisticalTableHeadList"
                  isStatistical
                  :dateForm="dateForm"
                />
              </div>
            </div>
            <!-- 指标详情 -->
            <index-info-modal
              v-if="indexInfoVisible"
              v-model:indexInfoVisible="indexInfoVisible"
              :visibleTitle="indexInfoTitle"
              :indexInfoForm="indexInfoForm"
            />
          </div>
        </gl-tab-pane>
        <gl-tab-pane :key="2" tab="图表" :forceRender="true">
          <!-- 图表 -->
          <div class="data-center-chart">
            <ms-diagram :chartId="chartId" ref="diagramRef" @extract="extractChartData" />
          </div>
        </gl-tab-pane>
      </gl-tabs>
      <!-- 指标、图表 end -->
    </gl-layout-content>
  </gl-layout>
</template>
<script setup lang="ts">
import { MsDiagram } from '@mysteel-standard/components-business'
import IndexTable from './data-center-content/index-table.vue'
import DataTable from './data-center-content/data-table.vue'
import DataCenterTopButton from './data-center-content/data-center-top-button.vue'
import IndexTopButton from './data-center-content/index-top-button.vue'
import DataTopButton from './data-center-content/data-top-button.vue'
import useDataTable from '../composables/table/use-data-table'
import useIndexTable from '../composables/table/use-index-table'
import IndexInfoModal from './data-center-content/index-info-modal.vue'
import useResize from '../composables/use-resize'
import useDiagram from '../composables/use-diagram'
import { ref, reactive } from 'vue'
const activeTab = ref(1)
interface Emits {
  (e: 'collect-index', title: string, data: any[], isDirectory: boolean, form: any): void
}
const emits = defineEmits<Emits>()
const dateForm = reactive({
  date: [],
  dateType: 0, //时间类型 0:公立 1:农历
  timeCount: null, //日期区间 最后：（日、周、月、年）
  timeType: null, //时间描述类型字符串（日， 周，月，年）
  intervalType: null
})
const dataTableHeight = ref(257)
//指标列表
const indexSelectedKeys = ref<any[]>([])
const indexTableSelection = ref<any[]>([])
//数据详情列表
const {
  dataTableData,
  dataTableLoading,
  dataToolsOperation,
  exportData,
  flexColWidth,
  viewIndexInfo,
  indexInfoVisible,
  indexInfoTitle,
  indexInfoForm,
  // 统计列表
  statisticalTableLoading,
  statisticalTableData,
  dataToolsForm, //数据工具
  dataToolsReset,
  dataTableHeadList,
  statisticalTableHeadList,
  detailTable,
  lastResultKey
} = useDataTable(indexTableSelection, dateForm, dataTableHeight)
const { resizeEl, indexHeight, dataTableRef } = useResize(dataToolsForm, dataTableHeight)
//图表回显
const diagramRef = ref()
const updateChartData = () => {
  const params = {
    indexCodes: indexTableSelection.value
      .filter((i: { isDerive: number }) => !i.isDerive)
      .map((item: { indexCode: string }) => item.indexCode),
    indexData: indexTableSelection.value,
    beginTime: dateForm.date && dateForm.date.length ? dateForm.date[0] : '',
    endTime: dateForm.date && dateForm.date.length ? dateForm.date[1] : '',
    timeCount: dateForm.timeCount,
    timeType: dateForm.timeType,
    dateType: dateForm.dateType,
    intervalType: dateForm.intervalType,
    deriveIndexObjs: indexTableSelection.value
      .filter((i: { isDerive: number }) => i.isDerive)
      .map((item: any) => {
        return {
          indexCode: item.indexCode,
          unit: item.unit,
          indexName: item.indexName,
          frequency: item.frequency,
          decimalPlaces: item.decimalPlaces,
          indexShortName: item.indexShortName
        }
      }) // 衍生指标
  }
  diagramRef.value?.initChartData(params)
}
const selectChange = (selections: any[]) => {
  indexTableSelection.value = [...selections]
  indexSelectedKeys.value = selections.map((item: any) => item.indexCode)
}
//修改时间
const changeDate = (data: Object) => {
  Object.assign(dateForm, data)
  exTractData()
  updateChartData()
}
//指标列表
const {
  indexTableData,
  indexTableLoading,
  exTractData,
  removeCheck,
  collectData,
  addIndex,
  invertCheck,
  indexCalculation,
  deleteRow,
  dataTopButtonRef,
  getIndexTableData
} = useIndexTable(
  emits,
  dataTableData,
  statisticalTableData,
  indexTableSelection,
  indexSelectedKeys,
  dateForm,
  dataTableLoading,
  dataTableHeadList,
  dataToolsReset,
  dataTableHeight,
  lastResultKey,
  flexColWidth,
  updateChartData
)
//图表请求参数和编辑id
const { chartId, extractChartData } = useDiagram(
  indexTableSelection,
  dateForm,
  activeTab,
  getIndexTableData
)
defineExpose({ addIndex, exTractData, getIndexTableData })
</script>
<style lang="scss" scoped>
@import '../style/database-index.scss';
</style>
