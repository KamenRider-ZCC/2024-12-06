<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-19 11:04:48
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-06-19 16:42:14
 * @Description: 
-->
<template>
  <form-modal
    :title="visibleTitle"
    v-model:visible="visible"
    :formItems="formItems"
    v-model:formParams="form"
    @ok="handleOk"
  ></form-modal>
</template>
<script setup lang="ts">
import { FormModal } from '@mysteel-standard/components'
interface Props {
  calculationVisible: boolean
  visibleTitle: string
  calculationForm: Object
  calculationFormItems: any[]
}

interface Emits {
  (e: 'update:calculationVisible', val: boolean): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  calculationVisible: false,
  visibleTitle: ''
})

const form = computed(() => props.calculationForm)
const formItems = computed(() => props.calculationFormItems)
const visible = computed({
  get() {
    return props.calculationVisible
  },
  set(val: boolean) {
    emits('update:calculationVisible', val)
  }
})

// 确认新建、重命名目录
const handleOk = () => {}
</script>
