export { default as IndustryChain } from './index.vue'
