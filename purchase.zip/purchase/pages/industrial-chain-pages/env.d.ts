/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-02 10:47:26
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-01 11:41:38
 * @Description:
 */
/// <reference types="vite/client" />
declare module '*.vue' {
  import { defineComponent } from 'vue'
  const Component: ReturnType<typeof defineComponent>
  export default Component
}

declare module 'gl-design-vue'
declare module '@mysteel-standard/components'
declare module '@mysteel-standard/components-business'
declare module '@mysteel-standard/hooks'
declare module '@mysteel-standard/apis'
declare module 'lodash-es'
declare module 'vue-super-flow'
declare module 'vue-drag-resize/src'
declare module 'vue3-super-flow'
declare module 'moment'
