export interface TabData {
  label: string
  value: number
}

export interface MapData {
  nodeId: number
}

export const positionMap = {
  // part1
  1: 'top: 39px; left: 472px',
  2: 'top: 212px; left: 16px',
  3: 'top: 212px; left: 616px',
  4: 'top: 384px; left: 160px',
  5: 'top: 384px; left: 472px;',
  // part2
  6: 'top: 36px; left: 16px',
  // part3
  7: 'top: -60px; left: 320px;',
  8: 'top: 20px; left: 20px;',
  9: 'top: 20px; left: 320px;',
  10: 'top: 80px; left: 20px;',
  11: 'top: 80px; left: 320px',
  12: 'top: 140px; left: 20px;',
  // part4
  13: 'top: 20px; left: 20px',
  14: 'top: 20px; left: 320px;',
  // part5
  15: 'top: 80px; left: -367px',
  16: 'top: 20px; left: 31px',
  17: 'top: 20px; left: 331px',
  18: 'top: 80px; left: 31px',
  19: 'top: 80px; left: 331px',
  20: 'top: 140px; left: 31px',
  21: 'top: 140px; left: 331px',
  // part6
  22: 'top: 80px; left: -367px',
  23: 'top: 20px; left: 31px',
  24: 'top: 20px; left: 331px',
  25: 'top: 80px; left: 31px',
  26: 'top: 80px; left: 331px',
  27: 'top: 140px; left: 31px',
  // part7
  28: 'top: 20px; left: -367px',
  29: 'top: 20px; left: 31px',
  30: 'top: 20px; left: 331px',
  // part8
  // 31: 'top: 20px; left: 20px',
  32: 'top: 20px; left: 20px',
  33: 'top: 88px; left: 20px',
  34: 'top: 156px; left: 20px',
  35: 'top: 224px; left: 20px',
  36: 'top: 292px; left: 20px',
  37: 'top: 360px; left: 20px',
  38: 'top: 428px; left: 20px'
}

export const iconNameMap = {
  1: 'jiaotan',
  2: 'tiekuangshi',
  3: 'lantan',
  4: 'meitan',
  5: 'jiaotan',
  6: 'tongfeisuiliao',
  7: 'tiekuangshi',
  8: 'menggui',
  9: 'tongjingkuang',
  10: 'dianjietong',
  11: 'zhonghouban',
  12: 'tongjingkuang',
  13: 'menggui',
  14: 'tongjingkuang',
  15: 'banpi',
  16: 'reyabanjuan',
  17: 'lengyabanjuan',
  18: 'tongbo',
  19: 'tongbandai',
  20: 'reyakaipingban',
  21: 'lengyakaipingban',
  22: 'fangpi',
  23: 'tegang',
  24: 'jingtonggan',
  25: 'shifatong',
  26: 'jiaogang',
  27: 'gongmojugang',
  28: 'guanpi',
  29: 'wufengguan',
  30: 'hanguan',
  31: 'jiaotongyunshu',
  32: 'fangdichan',
  33: 'jixie',
  34: 'qiche',
  35: 'jiadian',
  36: 'chuanye',
  37: 'wujin'
}

export const titleItemData = [
  {
    breedName: '交通运输',
    style: 'top: 20px; left: 20px; width: 130px',
    className: 'jiaotongyunshu'
  },
  {
    breedName: '房地产',
    style: 'top: 88px; left: 20px; width: 130px',
    className: 'fangdichan'
  },
  {
    breedName: '机械',
    style: 'top: 156px; left: 20px; width: 130px',
    className: 'jixie'
  },
  {
    breedName: '汽车',
    style: 'top: 224px; left: 20px; width: 130px',
    className: 'qiche'
  },
  {
    breedName: '家电',
    style: 'top: 292px; left: 20px; width: 130px',
    className: 'jiadian'
  },
  {
    breedName: '船业',
    style: 'top: 360px; left: 20px; width: 130px',
    className: 'chuanye'
  },
  {
    breedName: '五金',
    style: 'top: 428px; left: 20px; width: 130px',
    className: 'wujin'
  }
]

export const initTableColumns = [
  {
    title: '时间',
    dataIndex: 'date',
    key: 'date',
    ellipsis: true,
    width: 90
  },
  {
    title: '-',
    dataIndex: '-',
    key: '-',
    ellipsis: true
  }
]
