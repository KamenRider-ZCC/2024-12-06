<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-31 14:29:56
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-28 17:00:43
 * @Description: 
-->
<template>
  <gl-spin :spinning="loading">
    <div class="relevant-diagram-wrap">
      <div v-if="chartList && chartList.length" class="diagram-item">
        <chart-set-item
          v-for="(item, i) in chartList"
          class="chart-item"
          :element="{ id: item.chartId, name: item.chartName, uuid: item.chartId }"
          :key="i"
          :collectAble="true"
        />
      </div>

      <div v-else class="nodata">
        <i></i>
        <span>暂无数据</span>
      </div>
    </div>
  </gl-spin>
</template>
<script lang="ts" setup>
import { ref, watch, onMounted } from 'vue'
import { ChartSetItem } from '@mysteel-standard/components-business'
import api from '../../api'
interface Props {
  breed: any
  configId: string
}
const props = defineProps<Props>()

const loading = ref(false)
const chartList: any = ref([])

const getDiagramInfo = async () => {
  loading.value = true
  const { res, err } = await api.getNodeDetail({
    configId: props.configId,
    nodeId: props.breed.nodeId
  })
  loading.value = false
  if (res && !err) {
    const { chartConfig } = res.data
    if (chartConfig?.length) {
      chartList.value = chartConfig
    }
  }
}
onMounted(() => {
  getDiagramInfo()
})
</script>

<style lang="scss" scoped>
.nodata {
  height: calc(100% - 40px);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  border: unset !important;

  > i {
    display: inline-block;
    height: 172px;
    width: 400px;
  }
}
.relevant-diagram-wrap {
  .diagram-item {
    overflow: auto;
    height: calc(100vh - 120px);
    .chart-item {
      height: 530px;
      margin: 16px 0;
    }
  }
}
</style>
