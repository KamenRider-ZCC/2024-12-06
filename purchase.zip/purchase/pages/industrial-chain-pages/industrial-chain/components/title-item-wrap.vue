<template>
  <div class="title-item-wrap">
    <span class="item-name">
      <icon :name="'icon-' + className" size="22" />
      <span class="item-name-text">
        {{ breedName }}
      </span>
    </span>
  </div>
</template>

<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'

interface Props {
  breedName: string
  className: string
}
const props = defineProps<Props>()
</script>
