<template>
  <div class="stainless-map industrial-chain-map">
    <div class="part1 parent-item">
      <div class="part-title">长流程</div>
      <ItemWrap
        v-for="item in mapData1"
        :key="item.nodeId"
        :data="item"
        :style="positionMapRef[item.nodeId]"
        :className="iconNameMapRef[item.nodeId]"
        @show-details="showDetails"
      />
      <TitleItemWrap
        :breedName="'不锈钢'"
        :style="'top: 212px; left: 1684px'"
        :className="'buxiugang'"
      />
      <div class="liangang huizhuan-liangang liangang-h">
        <img src="../assets/huizhuan.png" />
        <p>回转窑</p>
      </div>
      <div class="liangang lvre-liangang liangang-h">
        <img src="../assets/gaolu.png" />
        <p>矿热炉炼铁</p>
      </div>
      <div class="liangang shaojie-liangang liangang-h">
        <img src="../assets/gaolu.png" />
        <p>烧结</p>
      </div>
      <div class="liangang gaolu-liangang liangang-h">
        <img src="../assets/gaolu.png" />
        <p>高炉炼铁</p>
      </div>

      <div class="liangang dianlu-liangang liangang-w">
        <img src="../assets/dianlu.png" />
        <p>电炉</p>
      </div>
      <div class="liangang AOD-liangang liangang-w">
        <img src="../assets/AOD.png" />
        <p>AOD炉炼钢</p>
      </div>
      <div class="liangang LF-liangang liangang-w">
        <img src="../assets/gaolu.png" />
        <p>LF精炼炉</p>
      </div>
      <div class="liangang lianzhu-liangang liangang-w">
        <img src="../assets/lianzhu.png" />
        <p>连铸机</p>
      </div>

      <div class="line line1"></div>
      <div class="line line2"></div>
      <div class="line line3"></div>
      <div class="line line4"></div>
      <div class="line line5"></div>
      <div class="line line6"></div>
      <div class="line line7"></div>
      <div class="line line8"></div>
      <div class="line line9"></div>
      <div class="line line10"></div>
      <div class="line line11"></div>
      <div class="line line12"></div>
      <div class="line line13"></div>
      <div class="line line14"></div>
      <div class="line line15"></div>
    </div>
    <div class="part2 parent-item">
      <div class="part-title">短流程</div>
      <ItemWrap
        v-for="item in mapData2"
        :key="item.nodeId"
        :data="item"
        :style="positionMapRef[item.nodeId]"
        :className="iconNameMapRef[item.nodeId]"
        @show-details="showDetails"
      />

      <div class="line line1"></div>
    </div>
    <div class="part3 parent-item">
      <ItemWrap
        v-for="item in mapData3"
        :key="item.nodeId"
        :data="item"
        :style="positionMapRef[item.nodeId]"
        :className="iconNameMapRef[item.nodeId]"
        @show-details="showDetails"
      />

      <div class="line line1"></div>
      <div class="line line2"></div>
    </div>
    <div class="part4 parent-item">
      <ItemWrap
        v-for="item in mapData4"
        :key="item.nodeId"
        :data="item"
        :style="positionMapRef[item.nodeId]"
        :className="iconNameMapRef[item.nodeId]"
        @show-details="showDetails"
      />

      <div class="line line1"></div>
    </div>
    <div class="part5 parent-item">
      <div class="part-title">板材</div>
      <ItemWrap
        v-for="item in mapData5"
        :key="item.nodeId"
        :data="item"
        :style="positionMapRef[item.nodeId]"
        :className="iconNameMapRef[item.nodeId]"
        @show-details="showDetails"
      />

      <div class="line line1"></div>
      <div class="line line2"></div>
      <div class="line line3"></div>
    </div>
    <div class="part6 parent-item">
      <div class="part-title">型材</div>
      <ItemWrap
        v-for="item in mapData6"
        :key="item.nodeId"
        :data="item"
        :style="positionMapRef[item.nodeId]"
        :className="iconNameMapRef[item.nodeId]"
        @show-details="showDetails"
      />

      <div class="line line1"></div>
      <div class="line line2"></div>
      <div class="line line3"></div>
      <div class="line line4"></div>
    </div>
    <div class="part7 parent-item">
      <div class="part-title">管材</div>
      <ItemWrap
        v-for="item in mapData7"
        :key="item.nodeId"
        :data="item"
        :style="positionMapRef[item.nodeId]"
        :className="iconNameMapRef[item.nodeId]"
        @show-details="showDetails"
      />

      <div class="line line1"></div>
    </div>
    <div class="part8 parent-item">
      <ItemWrap
        v-for="item in mapData8"
        :key="item.nodeId"
        :data="item"
        :style="positionMapRef[item.nodeId]"
        :className="iconNameMapRef[item.nodeId]"
        @show-details="showDetails"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { MapData } from '../types/interface'
import ItemWrap from './item-wrap.vue'
import TitleItemWrap from './title-item-wrap.vue'
import useStainlessMap from '../composables/use-stainless-map'

interface Props {
  mapData: MapData[] | any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'show-details', data: any): void
}
const emits = defineEmits<Emits>()

const {
  positionMapRef,
  iconNameMapRef,
  mapData1,
  mapData2,
  mapData3,
  mapData4,
  mapData5,
  mapData6,
  mapData7,
  mapData8,
  showDetails
} = useStainlessMap(props, emits)
</script>
