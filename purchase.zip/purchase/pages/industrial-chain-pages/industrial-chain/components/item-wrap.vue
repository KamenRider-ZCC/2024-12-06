<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-07-13 15:35:12
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-12-22 10:11:23
 * @Description: 
-->
<template>
  <div class="item-wrap" @click="handleClick(data)">
    <!-- <gl-tooltip :title="data.indexList[0].indexName"> -->
      <span class="item-name ellipsis" :title="data.indexList[0].indexName">
        <icon :name="'icon-' + className" size="22" />
        <span class="item-name-text">
          {{ data.varietyName }}
        </span>
      </span>
    <!-- </gl-tooltip> -->
    <div class="item-data" :class="upDownClass(data.indexList[0].upDown)[0]">
      <!-- <gl-tooltip :title="data.indexList[0].dataValue"> -->
        <span class="item-name ellipsis" :title="data.indexList[0].dataValue">
          {{ data.indexList[0].dataValue }}
        </span>
      <!-- </gl-tooltip> -->
    </div>
    <div class="item-data" :class="upDownClass(data.indexList[0].upDown)[0]">
      <!-- <gl-tooltip :title="data.indexList[0].upDown"> -->
        <span class="item-name ellipsis" :title="data.indexList[0].upDown">
          {{ upDownClass(data.indexList[0].upDown)[1] }}{{ data.indexList[0].upDown }}
        </span>
      <!-- </gl-tooltip> -->
    </div>
  </div>
</template>

<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { upDownClass } from '../utils/index'

interface Props {
  data: any
  className: string
}
defineProps<Props>()
interface Emits {
  (e: 'show-details', data: any): void
}
const emits = defineEmits<Emits>()

const handleClick = (data: any) => {
  emits('show-details', data)
}
</script>
<style scoped lang="scss">
.ellipsis {
  display: block !important;
}
.industrial-chain-wrap .map-content .item-wrap > :first-child {
  width: 50%;
}
.industrial-chain-wrap .map-content .item-wrap > :nth-child(2) {
  width: 33%;
  padding-right: 8px;
}
.industrial-chain-wrap .map-content .item-wrap > :last-child {
  width: 33%;
  padding-right: 8px;
}
.item-name[title]:hover:after {
  content: attr(title);
  color: #fff;
  padding: 4px 8px;
  position: absolute;
  left: 0;
  top: -80%;
  z-index: 200;
  white-space: nowrap;
  background-color: rgba(37, 39, 42);
}
</style>
