<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-30 10:01:47
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-15 17:03:01
 * @Description: 产业链全景图
-->
<template>
  <div class="industrial-flow">
    <div class="flow-container" ref="flowContainerRef">
      <super-flow
        ref="superFlowRef"
        :node-list="nodeList"
        :link-list="linkList"
        :link-style="linkStyle"
        :draggable="false"
        :linkAddable="false"
        :linkEditable="false"
        :hasMarkLine="false"
      >
        <template #node="{ meta }">
          <div
            @click="handleClick(meta)"
            class="flow-node ellipsis"
            :style="{ 'text-align': meta.nodeType === 2 ? 'center' : 'left' }"
          >
            <div class="item-icon-name">
              <gl-tooltip :title="meta.indexList[0].indexName">
                <span class="item-name ellipsis">
                  <img :src="meta.fileList[0].response.message" v-if="meta.fileList?.length > 0" />
                  <icon :name="meta.nodeIcon" v-else />
                  <span class="item-name-text">
                    {{ meta.nodeName }}
                  </span>
                </span>
              </gl-tooltip>
            </div>
            <div class="item-data" :class="upDownClass(meta.indexList[0].upDown)[0]">
              <gl-tooltip :title="meta.indexList[0].dataValue">
                <span class="item-name ellipsis">
                  {{ meta.indexList[0].dataValue }}
                </span>
              </gl-tooltip>
            </div>
            <div class="item-data" :class="upDownClass(meta.indexList[0].upDown)[0]">
              <gl-tooltip :title="meta.indexList[0].dataValue + meta.indexList[0].upDown">
                <span class="item-name ellipsis">
                  {{ upDownClass(meta.indexList[0].upDown)[1] }}{{ meta.indexList[0].upDown }}
                </span>
              </gl-tooltip>
            </div>
          </div>
        </template>
      </super-flow>
      <VueDragResize
        v-for="item in dashedNodeList"
        :isActive="true"
        :isDraggable="false"
        :isResizable="false"
        :w="item.width"
        :h="item.height"
        :x="item.x"
        :y="item.y"
        :z="998"
        :key="item.id"
      >
      </VueDragResize>
    </div>
    <div class="mask-container"></div>
  </div>
</template>

<script setup lang="ts">
import { SuperFlow } from 'vue3-super-flow'
import 'vue3-super-flow/dist/style.css'
import VueDragResize from 'vue-drag-resize/src'
import { watch } from 'vue'
import { Icon } from '@mysteel-standard/components'
import useFlowData from '../composables/use-flow-data'
import { upDownClass } from '../utils/index'

//props
interface Props {
  mapData: any
}
const props = withDefaults(defineProps<Props>(), {
  mapData: ''
})
//emits
interface Emits {
  (e: 'show-details', val: any): void
}
const emits = defineEmits<Emits>()

//节点信息
const { nodeList, linkStyle, linkList, dashedNodeList } = useFlowData(emits)

//监听默认节点信息
watch(
  () => props.mapData,
  (val) => {
    if (val !== '') {
      val.nodeList.forEach((item: any) => {
        item.meta.indexList = item.indexList ? item.indexList : []
      })
      nodeList.value = val.nodeList
      linkList.value = val.linkList
      dashedNodeList.value = val.dashedNodeList
    }
  },
  { deep: true }
)

const handleClick = (data: any) => {
  emits('show-details', data)
}
</script>

<style lang="scss" scoped>
.industrial-flow {
  height: 200%;
  width: 200%;

  .flow-container {
    position: relative;
    height: 100%;
    width: 100%;
    background: #ffffff;
    .flow-node {
      width: 100%;
      display: flex;
      line-height: 23px;
      .item-icon-name {
        width: 45%;
        .item-name-text {
          margin: 0 16px;
        }
      }
      .item-data {
        width: 25%;
        margin: 0 4px;
      }
    }
    :deep(.super-flow__node) {
      z-index: 999;
    }
    :deep(.super-flow__menu) {
      z-index: 999;
    }
  }
  .mask-container {
    width: calc(100% - 8px);
    height: calc(100% - 8px);
    position: absolute;
    top: 0;
    left: 0;
    overflow: hidden;
  }
}
:deep(.super-flow__node) {
  border-radius: 4px;
  border: 1px solid #0149aa;
  padding: 8px;
  font-size: 14px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #0149aa;
  background: #ebf4ff;
}

:deep(.vdr.active) {
  &:before {
    outline: 1px dashed #0149aa;
  }
}
:deep(.vdr-stick) {
  border: 1px solid #0149aa;
}
</style>
