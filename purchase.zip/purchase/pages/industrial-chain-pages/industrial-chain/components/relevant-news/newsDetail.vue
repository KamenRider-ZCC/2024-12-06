<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-31 16:35:18
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-01 17:30:14
 * @Description: 报告资讯详情
-->
<template>
  <div class="news-detail" v-loading="loading">
    <p class="title">{{ newsData.title }}</p>
    <p class="subtitle">
      <span style="margin-right: 120px">
        {{ timeFilter(newsData.articleTime) }}
      </span>
    </p>
    <gl-divider v-if="newsData.content"></gl-divider>
    <div class="article-content" v-html="newsData.content"></div>
    <gl-divider v-if="newsData.content"></gl-divider>
    <div class="author-monitor" v-html="newsData.authorMonitor"></div>
    <div class="copyright">
      {{ newsData.copyright }}
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import moment from 'moment'
import api from '../../api'
import { onMounted } from 'vue'
import { message } from 'gl-design-vue'
//props
interface Props {
  newsItem: any
}
const props = defineProps<Props>()

const timeFilter = (n: string) => {
  if (moment(n).format('YYYY') === moment().format('YYYY')) {
    return moment(n).format('MM-DD')
  }
  return moment(n).format('YYYY-MM-DD')
}

const newsData: any = ref({})
const loading = ref(false)

onMounted(async () => {
  const params = {
    articleId: props.newsItem.articleId
  }
  loading.value = true
  const { res, err } = await api.getByArticleId(params)
  if (res && !err) {
    if (res.message === '该文章已下架') {
      message.error(res.message)
      newsData.value.title = '该文章已下架'
    } else {
      newsData.value = res.data
      newsData.value.authorMonitor = res.data.authorMonitor
        ? res.data.authorMonitor.replace(/\r\n/g, '<br/>')
        : res.data.authorMonitor
    }
  }
})
</script>

<style lang="scss" scoped>
.news-detail {
  padding: 20px;
  height: 750px;
  overflow: auto;
  .title {
    height: 40px;
    line-height: 40px;
    font-size: 28px;
    font-weight: 600;
    text-align: center;
    margin-top: 20px;
  }
  .subtitle {
    text-align: center;
    margin-top: 30px;
    height: 25px;
    line-height: 25px;
    font-size: 18px;
    font-weight: 400;
  }
  .gl-divider {
    margin: 40px 0;
  }
  .author-monitor {
    font-size: 18px;
    line-height: 40px;
  }
  .copyright {
    font-size: 18px;
    line-height: 40px;
    margin-top: 30px;
  }
}
</style>
