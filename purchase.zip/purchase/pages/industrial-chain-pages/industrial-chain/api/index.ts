/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-13 15:35:12
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-01 17:28:52
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap = {
  // 产业链配置标签
  getTabs: {
    method: 'get',
    url: '/database/panoramagram/getPanoramagramList'
  },
  // 产业链数据(解析前)
  getIndexParseInfo: {
    method: 'get',
    url: '/database/panoramagram/getIndexParseInfoNew'
  },
  // 产业链数据(解析后)
  getIndexInfo: {
    method: 'post',
    url: '/database/panoramagram/getIndexDataInfos'
  },
  // 相关数据-指标信息接口
  getIndexInfoList: {
    method: 'post',
    url: '/database/panoramagram/getIndexInfoList'
  },
  // 相关数据-指标图表接口
  getIndexChart: {
    method: 'post',
    url: '/database/panoramagram/getPanoramagramIndexChart'
  },
  // 相关数据-指标权限
  getAuthIndexCodes: {
    method: 'post',
    url: '/database/datacatalog/getAuthIndexCodes'
  },
  //产业链配置查询
  getPanoramagramDetail: {
    method: 'get',
    url: '/database/panoramagram/getConfigNode'
  },
  //节点配置查询
  getNodeDetail: {
    method: 'post',
    url: '/database/panoramagram/getNodeDetail'
  },
  //根据产业链名称查询产业链权限
  searchIndustryChainPermissionByConfigId: {
    method: 'get',
    url: '/framework/dataPerm/searchIndustryChainPermissionByConfigId'
  },
  //产业链全景图-相关资讯-相关报告 查询接口
  panoramagramRelevantList: {
    method: 'post',
    url: '/info/information/panoramagramRelevantList'
  },
  //根据文章id获取文章详情
  getByArticleId: {
    method: 'get',
    url: '/info/information/getByArticleId'
  }
}
export default request(apiMap)
