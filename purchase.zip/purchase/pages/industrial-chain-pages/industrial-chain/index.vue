<template>
  <gl-spin :spinning="loading">
    <div style="padding: 16px">
      <div class="industrial-chain-wrap" :class="type + '-container'">
        <gl-date-picker
          class="date-picker"
          v-model:value="dateValue"
          value-format="YYYY-MM-DD"
          @change="changeDate"
        />
        <div class="map-content">
          <StainlessMap
            :mapData="mapData"
            @show-details="showDetails"
            v-if="type === 'stainless'"
            :style="{ zoom: zoom }"
          />
          <Panorama :mapData="mapData" @show-details="showDetails" v-else :style="{ zoom: zoom }" />
        </div>
        <gl-drawer
          v-model:visible="visible"
          width="872"
          class="industrial-chain-drawer"
          :closable="false"
          :mask-closable="false"
          :class="{ industrialScreen: route?.fullPath === '/panorama-screen' }"
        >
          <div class="detail-header">
            <span>{{ breed.varietyName || breed.nodeName }}</span>
            <icon
              class="closeDetails"
              name="icon-unselect_outlined"
              size="20"
              @click="closeDetails"
            />
          </div>
          <div class="detail-main">
            <gl-tabs
              v-model:activeKey="activeKey"
              :destroy-inactive-tab-pane="true"
              v-if="tabs.length > 0"
            >
              <gl-tab-pane key="相关数据" tab="相关数据" v-if="showTabFilter('相关数据')">
                <relevant-data :breed="breed" @closeDetails="closeDetails" />
              </gl-tab-pane>
              <gl-tab-pane key="相关图表" tab="相关图表" v-if="showTabFilter('相关图表')">
                <relevant-diagram :breed="breed" :configId="configId" />
              </gl-tab-pane>
              <gl-tab-pane key="相关资讯" tab="相关资讯" v-if="showTabFilter('相关资讯')">
                <relevant-news
                  :breed="breed"
                  :configId="configId"
                  :type="1"
                  @closeDetails="closeDetails"
                />
              </gl-tab-pane>
              <gl-tab-pane key="相关报告" tab="相关报告" v-if="showTabFilter('相关报告')">
                <relevant-news
                  :breed="breed"
                  :configId="configId"
                  :type="2"
                  @closeDetails="closeDetails"
                />
              </gl-tab-pane>
            </gl-tabs>
            <div v-else class="nodata">
              <i></i>
              <span>暂无权限</span>
            </div>
          </div>
        </gl-drawer>
      </div>
    </div>
    <!-- 页面操作 -->
    <div class="controller-bar">
      <!-- 刷新 -->
      <div class="controller-item" @click="handleRefresh">
        <icon name="icon-shuaxin" size="20" />
      </div>
      <!-- 放大 -->
      <div class="controller-item" @click="handleZoomIn">
        <icon name="icon-add" size="20" />
      </div>
      <!-- 缩小 -->
      <div class="controller-item" @click="handleZoomOut">
        <icon name="icon-minus" size="20" />
      </div>
    </div>
  </gl-spin>
</template>
<script setup lang="ts">
import { useRouter, useRoute } from 'vue-router'
import { reactive, toRefs, ref, onMounted, onUnmounted } from 'vue'
import api from './api/index'
import { TabData, MapData } from './types/interface'
import StainlessMap from './components/stainless-map.vue'
import Panorama from './components/panorama.vue'
import { Icon } from '@mysteel-standard/components'
import useIndustrialData from './composables/use-industrial-data'
import RelevantData from './components/relevant-data/index.vue'
import RelevantDiagram from './components/relevant-diagram/index.vue'
import RelevantNews from './components/relevant-news/index.vue'
const route = useRoute()
const router = useRouter()
const type = ref('stainless')
interface State {
  configTabs: TabData[]
  configId: number
  dateValue: string
  mapData: MapData[]
  loading: boolean
  visible: boolean
  breed: any
  activeKey: string
}
const state = reactive<State>({
  configTabs: [],
  configId: 1,
  dateValue: '',
  mapData: [],
  loading: false,
  visible: false,
  breed: {},
  activeKey: '1'
})

//获取不锈钢配置信息
const { getIndexParseInfoFun, getPanoramagramDetail } = useIndustrialData()

const getIndexParseInfo = async (showLoading: boolean) => {
  state.loading = showLoading
  let data = null
  if (type.value === 'stainless') {
    data = await getIndexParseInfoFun(1, state.dateValue)
  } else {
    data = await getPanoramagramDetail(
      router.currentRoute.value.query.id as string,
      state.dateValue
    )
  }
  state.loading = false
  state.mapData = data
}

const timer = setInterval(
  async () => {
    getIndexParseInfo(false)
  },
  1000 * 60 * 5
)

onUnmounted(() => {
  clearInterval(timer)
})

onMounted(() => {
  if (router.currentRoute.value.query.id !== undefined) {
    state.configId = parseInt(router.currentRoute.value.query.id as string)
    type.value = 'panorama'
  } else {
    state.configId = 1
    type.value = 'stainless'
  }
  getDetailTab()
  getIndexParseInfo(true)
})

//获取产业链配置信息
const changeDate = () => {
  getIndexParseInfo(true)
}

const closeDetails = () => {
  state.visible = false
}

const tabs: any = ref([])
const showTabFilter = (n: string) => {
  // return tabs.value.filter((item: { name: string }) => item.name === n).length > 0
  return true
}

const getDetailTab = async () => {
  const params = {
    configId: state.configId
  }
  const { res, err } = await api.searchIndustryChainPermissionByConfigId(params)
  if (!err && res) {
    tabs.value = res.data || []
  }
}

const showDetails = (data: any) => {
  const { nodeType } = data
  if (nodeType === 2) return
  state.activeKey = tabs.value.length > 0 ? tabs.value[0].name : ''
  state.breed = data
  state.visible = true
}

const { dateValue, mapData, loading, visible, breed, activeKey, configId }: { [key: string]: any } =
  toRefs(state)

// controller
const zoom = ref(1)
const handleRefresh = () => {
  zoom.value = 1
  state.dateValue = ''
  getIndexParseInfo(true)
}

const handleZoomIn = () => {
  zoom.value += 0.1
}

const handleZoomOut = () => {
  if (zoom.value.toFixed(1) === '0.1') return
  zoom.value -= 0.1
}
</script>
<style lang="scss">
@import './style/index.scss';
.controller-bar {
  z-index: 999;
  position: absolute;
  bottom: 26px;
  right: 30px;
  .controller-item {
    cursor: pointer;
    width: 40px;
    height: 40px;
    background: #ffffff;
    border-radius: 8px;
    border: 1px solid #dddddd;
    padding: 4px 10px;
    margin: 8px;
    color: #9f9f9f;
    &:hover {
      color: #1890ff;
      border-color: #1890ff;
    }
  }
}
</style>
