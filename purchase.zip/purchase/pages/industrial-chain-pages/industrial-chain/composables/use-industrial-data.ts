/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-13 15:35:12
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-19 10:05:11
 * @Description:
 */
import api from '../api/index'
import { cloneDeep } from 'lodash-es'

export default () => {
  const getIndexParseInfoFun = async (configId: number, date: string) => {
    const { res, err } = await api.getIndexParseInfo({ configId })
    if (err) {
      return null
    }
    const indexCodes: any = []
    const deriveIndexes: any = []
    const data = cloneDeep(res.data)
    data.forEach((item: any) => {
      if (item.indexList.length > 0) {
        if (item.indexList[0].isDerive) {
          deriveIndexes.push(item.indexList[0].indexCode)
        } else {
          indexCodes.push(item.indexList[0].indexCode)
        }

        item.indexList[0].dataValue = ''
        item.indexList[0].upDown = ''
      } else {
        item.indexList = [{ dataValue: '', upDown: '' }]
      }
    })

    const params = { indexCodes, deriveIndexes, date }
    const details: any = await getIndexData(params)
    if (details.data && details.data.length > 0) {
      details.data.forEach((item: any) => {
        data.forEach((i: any) => {
          if (i.indexList.length > 0) {
            if (item.indexCode === i.indexList[0].indexCode) {
              i.indexList[0].dataValue =
                item.dataValue || item.dataValue === 0 ? item.dataValue : ''
              i.indexList[0].upDown = item.upDown || item.upDown === 0 ? item.upDown : ''
            }
            if (item.indexCode === i.indexList[0].formula) {
              i.indexList[0].dataValue =
                item.dataValue || item.dataValue === 0 ? item.dataValue : ''
              i.indexList[0].upDown = item.upDown || item.upDown === 0 ? item.upDown : ''
            }
          }
        })
      })
    }
    return data
  }

  const getPanoramagramDetail = async (configId: string, date: string) => {
    const { res, err } = await api.getPanoramagramDetail({ configId })
    if (!err && res) {
      const data = cloneDeep(res.data)
      const nodeJson = JSON.parse(data?.nodeJson)
      const nodeList = nodeJson.nodeList
      const indexList = data.indexList
      nodeList.forEach((item: any) => {
        indexList.forEach((ele: any) => {
          if (item.id === ele.nodeId) {
            item.indexList = ele.indexList
          }
        })
      })
      const indexCodes: any = []
      const deriveIndexes: any = []
      nodeList.forEach((item: any) => {
        if (item.indexList?.length > 0) {
          if (item.indexList[0].isDerive) {
            deriveIndexes.push(item.indexList[0].indexCode)
          } else {
            indexCodes.push(item.indexList[0].indexCode)
          }
          item.indexList[0].dataValue = ''
          item.indexList[0].upDown = ''
        } else {
          item.indexList = [{ dataValue: '', upDown: '' }]
        }
      })
      const params = { indexCodes, deriveIndexes, date }
      const details: any = await getIndexData(params)
      if (details.data && details.data.length > 0) {
        details.data.forEach((item: any) => {
          nodeList.forEach((i: any) => {
            if (i.indexList.length > 0) {
              if (item.indexCode === i.indexList[0].indexCode) {
                i.indexList[0].dataValue =
                  item.dataValue || item.dataValue === 0 ? item.dataValue : ''
                i.indexList[0].upDown = item.upDown || item.upDown === 0 ? item.upDown : ''
              }
              if (item.indexCode === i.indexList[0].formula) {
                i.indexList[0].dataValue =
                  item.dataValue || item.dataValue === 0 ? item.dataValue : ''
                i.indexList[0].upDown = item.upDown || item.upDown === 0 ? item.upDown : ''
              }
            }
          })
        })
      }

      return nodeJson
    }
  }

  const getIndexData = async (params: any) => {
    const { res, err } = await api.getIndexInfo(params)
    if (err) {
      return null
    }
    return res
  }

  return { getIndexParseInfoFun, getPanoramagramDetail }
}
