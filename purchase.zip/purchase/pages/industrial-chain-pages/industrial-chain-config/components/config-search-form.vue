<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-28 12:00:05
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-31 11:44:14
 * @Description: 
-->
<template>
  <gl-form ref="formRef" layout="inline" :model="configQuery">
    <gl-form-item label="产业链名称">
      <gl-input
        v-model:value="configQuery.panoramagramName"
        placeholder="请输入产业链名称"
      ></gl-input>
    </gl-form-item>
    <gl-form-item label="状态">
      <gl-select
        v-model:value="configQuery.isEnable"
        style="width: 120px"
        :options="statusOptions"
      ></gl-select>
    </gl-form-item>
    <gl-button type="primary" @click="roleSearch">
      <icon name="icon-search" />
      搜索
    </gl-button>
    <gl-button style="margin: 0 8px" @click="reset">
      <icon name="icon-reset" />
      重置
    </gl-button>
  </gl-form>
</template>
<script setup lang="ts">
import { useResetData } from '@mysteel-standard/hooks'
import { Icon } from '@mysteel-standard/components'
import { ConfigListType } from '../types/interface'
const { dataState: configQuery, resetDataState: configQueryReset } = useResetData({
  panoramagramName: '',
  isEnable: -1
})
interface Emits {
  (e: 'search', configQuery: ConfigListType): void
}
const emits = defineEmits<Emits>()
const statusOptions = [
  {
    value: -1,
    label: '全部'
  },
  {
    value: 1,
    label: '启用'
  },
  {
    value: 0,
    label: '禁用'
  }
]
const roleSearch = () => {
  const params = {
    panoramagramName: configQuery.panoramagramName,
    isEnable: configQuery.isEnable === -1 ? undefined : configQuery.isEnable
  }
  emits('search', params)
}
const reset = () => {
  configQueryReset()
  roleSearch()
}
</script>
<style lang="scss"></style>
