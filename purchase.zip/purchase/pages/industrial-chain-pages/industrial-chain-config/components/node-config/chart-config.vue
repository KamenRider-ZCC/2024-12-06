<template>
  <div class="chart-config-wrap">
    <gl-space direction="vertical" :size="8">
      <gl-button type="primary" @click="addChart"> <icon name="icon-add" />添加图表 </gl-button>
      <ms-table
        class="chart-config-table"
        row-key="chartId"
        :columns="columns"
        :data="chartConfigTable"
      >
        <template #chartName="{ record, index }">
          <div class="index-name">
            <gl-tooltip class="item" :title="record.chartName" placement="top">
              <div class="text-left" :id="`index-name_${index}`">{{ record.chartName }}</div>
            </gl-tooltip>
            <icon
              class="edit-icon"
              name="icon-edit"
              size="14"
              color="#023985"
              @click="showEdit(record, index)"
            />
            <icon
              class="edit-icon"
              name="icon-view-chart"
              @mouseover.stop="previewChart(record, index)"
              @mouseout.stop="closePreview"
            />
            <span class="default-icon" v-if="index === 0"> 默认 </span>
          </div>
        </template>
        <template #action="{ record, index }">
          <gl-button type="text" @click.stop="addChart(index)">替换图表</gl-button>
          <gl-button type="text" @click.stop="setDefault(record, index)" :disabled="index === 0">
            设为默认
          </gl-button>
          <gl-button type="text" @click.stop="move(index)">移除</gl-button>
        </template>
      </ms-table>
    </gl-space>
    <!-- 编辑图表名称 -->
    <edit-name-modal
      v-if="editVisible"
      v-model:editVisible="editVisible"
      :form="chartForm"
      editLabel="图表名称"
      editKey="chartName"
      @change-data="changeName"
    />
    <!-- 新增图表 -->
    <add-chart-modal v-model:addChartVisible="addChartVisible" @add-chart="getChartList" />
    <!-- 图表缩略图预览 -->
    <chart-preview
      :url="curThumbnail"
      v-if="curThumbnail && previewChartVisible"
      :leftPosition="leftPosition"
      id="imagesPreview"
    />
  </div>
</template>
<script setup lang="ts">
import { ref, onMounted, watch, nextTick } from 'vue'
import { MsTable, Icon } from '@mysteel-standard/components'
import EditNameModal from './edit-name-modal.vue'
import AddChartModal from './add-chart-modal.vue'
import ChartPreview from './chart-preview.vue'
import { usePreviewChart } from '../../composables/use-chart-config'
import {
  useAddOrChange,
  useMove,
  useSetDefault,
  useEditName,
  useTableSort
} from '../../hooks/use-config'
interface Props {
  chartConfig: any
}
defineProps<Props>()
const chartConfigTable = ref<any>([])

const columns = [
  {
    title: '',
    dataIndex: 'drag',
    key: 'drag',
    align: 'center',
    width: 50
  },
  {
    title: '图表名称',
    dataIndex: 'chartName',
    key: 'chartName',
    slotName: 'chartName',
    ellipsis: true
  },
  {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    width: 290
  }
]
interface Emits {
  (e: 'update:chartConfig', data: any): void
}
const emits = defineEmits<Emits>()
//编辑
const { editVisible, showEdit, changeName, chartForm } = useEditName(chartConfigTable, 'chart')
// 添加、替换图表
const {
  addVisible: addChartVisible,
  addOrChange: addChart,
  getAddList: getChartList
} = useAddOrChange(chartConfigTable, 'chart')
//移除
const { move } = useMove(chartConfigTable)
//设置默认
const { setDefault } = useSetDefault(chartConfigTable)
// 拖拽排序
const { tableSortable } = useTableSort('.chart-config-table .gl-table-tbody', chartConfigTable)
//预览图表
const { previewChartVisible, previewChart, curThumbnail, closePreview, leftPosition } =
  usePreviewChart()
// 排序
watch(
  () => chartConfigTable.value,
  (val) => {
    let chartConfig = []
    if (val && val.length) {
      nextTick(() => {
        tableSortable()
      })
      chartConfig = val.map((item: any, index: number) => {
        return {
          ...item,
          sort: index + 1,
          isDefault: index === 0 ? 1 : 0
        }
      })
    }

    emits('update:chartConfig', chartConfig)
  },
  {
    deep: true
  }
)
const initData = (data: any) => {
  chartConfigTable.value = data
}
defineExpose({ initData })
</script>
<style lang="scss" scoped>
@import '../../style/config.scss';
@include ConfigListLayout('chart-config-wrap');
</style>
