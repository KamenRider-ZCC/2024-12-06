<template>
  <form-modal
    :title="`编辑${editLabel}`"
    v-model:visible="visible"
    :formItems="indexFormItem"
    v-model:formParams="editIndexForm"
    @ok="handleOk"
  ></form-modal>
</template>
<script setup lang="ts">
import { ref, computed } from 'vue'
import { FormModal } from '@mysteel-standard/components'
interface Props {
  editVisible: boolean
  editLabel: string
  editKey: string
  form: any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'change-data', data: string): void
  (e: 'update:editVisible', val: boolean): void
}
const emits = defineEmits<Emits>()
const visible = computed({
  get() {
    return props.editVisible
  },
  set(val: boolean) {
    emits('update:editVisible', val)
  }
})
const label = computed(() => props.editLabel)
const key = computed(() => props.editKey)
const formData = computed(() => props.form)
const indexFormItem = [
  {
    type: 'input',
    label: label.value,
    class: 'form-input',
    name: key.value,
    rules: [{ required: true, message: `请输入${label.value}` }]
  }
]
const editIndexForm = ref(formData.value)

const handleOk = async () => {
  visible.value = false
  emits('change-data', editIndexForm.value[key.value])
}
</script>
<style lang="scss" scoped>
.form-input {
  .gl-input {
    width: 300px;
  }
}
</style>
