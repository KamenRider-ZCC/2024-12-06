<template>
  <div class="tag-wrap">
    <gl-tag
      :key="tag"
      v-for="tag in tagForm.keywords"
      closable
      :disable-transitions="true"
      @close="handleClose(tag)"
    >
      <gl-tooltip
        :disabled="tag.length < 15"
        class="item"
        effect="dark"
        :content="tag"
        placement="top-start"
      >
        <span>{{ tag.length > 15 ? tag.substring(0, 15) + '...' : tag }}</span>
      </gl-tooltip>
    </gl-tag>
    <gl-input
      class="input-new-tag"
      v-model:value="inputValue"
      style="width: 400px"
      @keyup.space="handleInputConfirm"
      @blur="handleInputConfirm"
      placeholder="请输入关键词，多个关键词以空格隔开"
    >
    </gl-input>
    <icon
      class="btn-close"
      name="icon-unselect_outlined"
      v-show="tagForm.keywords && tagForm.keywords.length"
      @click.stop="handleClose('')"
    />
  </div>
</template>
<script lang="ts" setup>
import { Icon } from '@mysteel-standard/components'
import { ref, computed } from 'vue'
import { message } from 'gl-design-vue'
//props
interface Props {
  form: any
}
const props = withDefaults(defineProps<Props>(), {
  form: {}
})
//emits
interface Emits {
  (e: 'update:form', val: any): void
}
const emits = defineEmits<Emits>()

const tagForm: any = computed({
  get() {
    return props.form
  },
  set(val) {
    emits('update:form', val)
  }
})
const inputValue = ref('')
const handleInputConfirm = () => {
  if (tagForm.value.keywords.length === 50) {
    message.warning('最多只能输入50个关键词')
    inputValue.value = ''
    return
  }

  let multiValue: any = inputValue.value
  if (inputValue.value.split(' ').length) {
    multiValue = multiValue.split(' ').filter((gl: string) => {
      return gl
    })
  }

  if (inputValue.value) {
    tagForm.value.keywords = [...tagForm.value.keywords, ...multiValue]
  }
  inputValue.value = ''
}
const handleClose = (tag: string) => {
  if (tag) {
    tagForm.value.keywords.splice(tagForm.value.keywords.indexOf(tag), 1)
  } else {
    tagForm.value.keywords = []
  }
}
</script>
<style lang="scss" scoped>
.tag-wrap {
  border: 1px solid #d9d9d9;
  border-radius: 3px;
  display: inline-block;
  .gl-tag {
    border-radius: 1px;
    margin: 1px;
    height: 28px;
    line-height: 28px;
    background: #f4f4f5;
    color: #666;
    border-color: #f4f4f5;
    :deep(.gl-tag-close-icon) {
      padding-top: 8px;
    }
  }
}

:deep(.input-new-tag) {
  border: none;
  height: 28px;
  line-height: 28px;
  margin: 1px 0;
}

.btn-close {
  font-size: 14px;
  color: #fff;
  margin: 7px 8px 0 0;
  border-radius: 50%;
  background-color: #666;
}
:deep(.gl-input:focus) {
  border: none;
  box-shadow: none;
}
</style>
