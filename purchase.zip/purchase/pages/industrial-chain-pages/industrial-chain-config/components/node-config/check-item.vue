<template>
  <gl-form-item
    :label="title"
    :name="name"
    class="gl-form-item check-item-wrap"
    :id="`${name}_${type}_check`"
  >
    <div class="check-wrap" ref="checkRef">
      <div>
        <gl-form-item-rest>
          <gl-checkbox
            :indeterminate="isIndeterminate[name]"
            v-model:checked="checkedObj[checkProp]"
            @change="handleCheckAllChange"
            style="width: 80px"
            >全选</gl-checkbox
          >
        </gl-form-item-rest>
      </div>
      <div class="check-right">
        <gl-checkbox-group v-model:value="checkedObj[name]" @change="handleCheckedChange">
          <gl-checkbox v-for="item in checkOptions" :value="item.value" :key="item.value">{{
            item.label
          }}</gl-checkbox>
        </gl-checkbox-group>
      </div>
    </div>
  </gl-form-item>
</template>
<script lang="ts" setup>
import { ref, computed, toRefs } from 'vue'
//props
interface Props {
  title: string
  options: Array<any>
  name: string
  type: string
  checkObj: any
  checkProp: any
}
const props = withDefaults(defineProps<Props>(), {
  form: {},
  title: '',
  options: () => [],
  name: '',
  type: '',
  checkObj: {},
  checkProp: {}
})
//emits
interface Emits {
  (e: 'update:checkObj', val: any): void
}

const emits = defineEmits<Emits>()
const checkedObj = computed({
  get() {
    return props.checkObj
  },
  set(value) {
    emits('update:checkObj', value)
  }
})
const isIndeterminate: any = ref({
  secondBreeds: false,
  firstData: false,
  secondData: false
})
const checkOptions = computed(() => props.options)
const { name, type }: any = toRefs(props)

const handleCheckAllChange = (val: any) => {
  const options = checkOptions.value.map((item) => {
    return item.value
  })
  checkedObj.value[props.name] = val.target.checked ? options : []
  if (props.name === 'secondBreeds') {
    //二级品种特殊（不是双向绑定），需要传值
    checkedObj.value.secondBreedsIsAll = val.target.checked
  }
}
const handleCheckedChange = (value: string | any[]) => {
  let checkedCount = value.length
  checkedObj.value[props.checkProp] = checkedCount === checkOptions.value.length
  if (props.name === 'secondBreeds') {
    //二级品种特殊（不是双向绑定），需要传值
    checkedObj.value.secondBreeds = value
    checkedObj.value.secondBreedsIsAll = checkedObj.value.secondBreedsIsAll
  }
  isIndeterminate.value[props.name] = checkedCount > 0 && checkedCount < checkOptions.value.length
}
</script>
<style lang="scss" scoped>
.check-item-wrap {
  overflow: hidden;
}
.check-wrap {
  display: flex;
  margin-top: 6px;
}

:deep(.gl-checkbox-wrapper) {
  width: 180px;
  margin-bottom: 16px;
  margin-left: 0 !important;
}

.check-right {
  position: relative;
  width: 100%;
  .btn-right {
    position: absolute;
    right: 0px;
    top: 0;
    :deep(.gl-btn) {
      border-color: #2d5dc1;
      span {
        color: #2d5dc1;
      }
    }
    span {
      color: #2d5dc1;
    }
  }
}
</style>
