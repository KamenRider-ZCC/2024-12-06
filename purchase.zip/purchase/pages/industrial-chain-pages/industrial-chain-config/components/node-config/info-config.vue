<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-02 10:47:26
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-12-15 15:39:38
 * @Description: 资讯配置
-->
<template>
  <gl-spin :spinning="formLoading">
    <gl-form ref="form" :model="informationForm" label-width="81px" label-position="right">
      <gl-form-item label="一级品种" name="firstBreed" class="gl-form-item">
        <div class="radio-wrap">
          <gl-radio-group v-model:value="informationForm.firstBreed" @change="handleChange">
            <gl-radio v-for="(item, index) in firstBreedOption" :value="item" :key="index">{{
              item
            }}</gl-radio>
          </gl-radio-group>
        </div>
      </gl-form-item>
      <div
        v-if="
          informationForm.firstBreed !== '国际宏观' && informationForm.firstBreed !== '下游资讯'
        "
      >
        <check-item
          v-if="informationForm.firstBreed !== '宏观' && informationForm.firstBreed !== '检修信息'"
          :options="breedOptions"
          name="secondBreeds"
          type="information"
          v-model:checkObj="informationForm"
          checkProp="secondBreedsIsAll"
          ref="secondBreedRef"
          :title="excludeList.includes(informationForm.firstBreed) ? '栏目：' : '二级品种：'"
        />
        <check-item
          v-if="!excludeList.includes(informationForm.firstBreed)"
          :options="firstOption"
          name="firstData"
          type="information"
          v-model:checkObj="informationForm"
          checkProp="firstDataIsAll"
          :title="informationForm.firstBreed === '宏观' ? '一级行业' : '选择市场'"
        />
        <check-item
          v-if="!excludeList.includes(informationForm.firstBreed)"
          :options="secondOption"
          name="secondData"
          type="information"
          v-model:checkObj="informationForm"
          checkProp="secondDataIsAll"
          :title="informationForm.firstBreed === '宏观' ? '二级行业' : '选择地区'"
        />
      </div>
      <gl-form-item label="关键词" name="keywords" class="gl-form-item tag-item">
        <keywords-tag v-model:form="informationForm" />
      </gl-form-item>
      <gl-form-item label="展示条数" name="showNum" class="gl-form-item">
        <gl-input-number
          v-model:value="informationForm.showNum"
          style="width: 400px"
          :min="1"
          :max="50"
        ></gl-input-number>
      </gl-form-item>
    </gl-form>
  </gl-spin>
</template>
<script lang="ts" setup>
import { ref, computed, nextTick, onMounted } from 'vue'
import CheckItem from './check-item.vue'
import KeywordsTag from './keywords-tag.vue'
import useCheckOption from '../../composables/use-check-option'
import api from '../../api/index'
//props
interface Props {
  infoConfig: any
}
const props = withDefaults(defineProps<Props>(), {
  infoConfig: () => {}
})
//emits
interface Emits {
  (e: 'update:infoConfig', val: any): void
}
const emits = defineEmits<Emits>()

const firstBreedOption = ref([])
const excludeList = ref([
  '不锈钢',
  '镍',
  '镍铁',
  '精炼镍',
  '废不锈钢',
  '铬',
  '下游资讯',
  '硅锰',
  '无烟煤',
  '电解铜'
])

const informationForm = computed(() => props.infoConfig)

const {
  firstOption,
  secondOption,
  breedOptions,
  getSecondBreeds,
  initOption,
  secondBreedRef,
  formLoading,
  getFirstData
} = useCheckOption('information', informationForm)

const handleChange = async (val: any) => {
  const { value } = val.target
  await getSecondBreeds(value)
  await getFirstData(value)
  emits('update:infoConfig', {
    firstBreed: value,
    secondBreeds: [],
    secondBreedsIsAll: false,
    firstData: [],
    firstDataIsAll: false,
    secondData: [],
    secondDataIsAll: false,
    keywords: [],
    showNum: 7
  })
}

const initData = (data: any) => {
  initOption(data.firstBreed)
  fetchReportCloums()
}

const fetchReportCloums = async () => {
  const { res, err } = await api.getInfoColumn()
  if (!err) {
    const { data } = res
    firstBreedOption.value = data
      .map((item: any) => item.moduleName)
      .filter((item: any) => item !== '最新资讯' && item !== '快讯')
  }
}

defineExpose({ initData })
</script>
<style lang="scss" scoped>
:deep(.gl-form-item-label) {
  width: 80px;
}
:deep(.gl-form-item) {
  margin-bottom: 16px;
}
</style>
