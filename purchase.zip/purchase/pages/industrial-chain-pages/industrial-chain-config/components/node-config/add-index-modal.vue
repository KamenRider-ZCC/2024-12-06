<!--
 * @Autor: zhouwanwan
 * @Date: 2023-08-02 10:55:01
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-15 17:11:54
 * @Description: 
-->
<template>
  <gl-modal
    v-model:visible="indexVisible"
    title="选择指标"
    @ok="handleOk"
    centered
    width="1400px"
    :confirm-loading="confirmLoading"
  >
    <ms-table-transfer v-if="indexVisible" :indexList="indexList" ref="transferRef" />
  </gl-modal>
</template>
<script setup lang="ts">
import { MsTableTransfer } from '@mysteel-standard/components-business'
import { computed, ref } from 'vue'
import { message } from 'gl-design-vue'
import api from '../../api/index'
interface Props {
  addIndexVisible: any
  indexList: any
}
interface Emits {
  (e: 'update:addIndexVisible', val: boolean): void
  (e: 'sure-add-index', data: any[]): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  addIndexVisible: false
})
const confirmLoading = ref(false)
const indexVisible = computed({
  get() {
    return props.addIndexVisible
  },
  set(val: boolean) {
    emits('update:addIndexVisible', val)
  }
})
const transferRef = ref()
const parentIds = ref<any>([])
const findPid = (list: any, id: any) => {
  return list.find((item: any) => item.id === id)
}
const getTreeId = (checkList: any, treePid: any, index: any) => {
  const obj: any = findPid(checkList, treePid)
  if (findPid(checkList, treePid)) {
    if (obj.pid !== '0') {
      parentIds.value[index].push(obj.pid)
    }
    if (checkList.length > 1) {
      getTreeId(checkList, obj.pid, index)
    }
  }
}
//获取frameIdPath(用于数据库回显)
const allParentId = (list: any, parentNodes: any) => {
  list.forEach((item: any, index: any) => {
    parentIds.value[index] = []
    parentIds.value[index].push(item.pid)
    getTreeId(parentNodes, String(item.pid), index)
  })
}
const handleOk = async () => {
  allParentId(transferRef.value.rightIndexList, transferRef.value.selectedNodes)
  const deriveIndexes: any = []
  const indexCodes: any = []
  if (transferRef.value.rightIndexList.length) {
    const checkedIndex = transferRef.value.rightIndexList
    checkedIndex.forEach((item: any, index: number) => {
      item.frameIdPath = parentIds.value[index].reverse().join('|')
      const indexParams = (item.indexParams && JSON.parse(item.indexParams)) || ''
      if (indexParams && indexParams.isDerive) {
        deriveIndexes.push(item.indexCode)
      } else {
        indexCodes.push(item.indexCode || item.code)
      }
    })
    const params = {
      indexCodes,
      deriveIndexes
    }
    let dataList = []
    confirmLoading.value = true
    const { res, err } = await api.getIndexInfo(params)
    confirmLoading.value = false
    if (!err && res) {
      const { data } = res
      if (data.length) {
        dataList = data || []
        dataList.forEach((item: any, index: any) => {
          item.frameIdPath = checkedIndex[index].frameIdPath
          item.dbType = checkedIndex[index].dbType
        })
        indexVisible.value = false
        emits('sure-add-index', dataList)
      }
    }
  } else {
    message.warning('请选择指标')
  }
}
</script>
