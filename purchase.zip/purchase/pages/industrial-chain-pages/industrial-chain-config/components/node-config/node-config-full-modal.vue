<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-28 16:04:04
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-16 14:08:11
 * @Description: 节点配置弹窗
-->
<template>
  <full-modal v-model:visible="nodeVisible" :showSubmit="false">
    <template #extra-btn>
      <gl-button
        class="btn-box-content"
        type="primary"
        @click="handleSave()"
        :loading="saveLoading"
      >
        <icon name="icon-comform_outlined" v-if="!saveLoading" />
        <span>保存</span>
      </gl-button>
    </template>
    <div class="node-config-warp">
      <div v-if="type === 'stainless'">
        <div class="nodeName" v-if="!editVarietynameFlag">
          {{ curNodeData.nodeName || varietyname }}
          <icon name="icon-edit" @click="showNodeInfo" size="14" />
        </div>
        <div v-else>
          <gl-space>
            <gl-input type="text" v-model:value="varietynameInput" style="width: 120px" />
            <icon name="icon-comform_outlined" @click="editVarietyname" size="14" />
            <icon name="icon-unselect_outlined" @click="cancelVarietyname" size="14" />
          </gl-space>
        </div>
        <div class="edit-icon"></div>
      </div>
      <div class="node-edit" v-else>
        <icon :name="curNodeData.nodeIcon"></icon>
        <div class="nodeName">{{ curNodeData.nodeName }}</div>
        <div class="edit-icon">
          <icon name="icon-edit" @click="showNodeInfo" size="14" />
        </div>
      </div>
      <gl-spin :spinning="loading">
        <div class="node-config-content">
          <gl-tabs v-model:activeKey="activeKey">
            <gl-tab-pane tab="数据配置" key="data-config" :forceRender="true">
              <data-config v-model:indexConfig="indexConfigData" ref="indexConfigRef" />
            </gl-tab-pane>
            <gl-tab-pane tab="图表配置" key="chart-config" :forceRender="true">
              <chart-config v-model:chartConfig="chartConfigData" ref="chartConfigRef" />
            </gl-tab-pane>
            <gl-tab-pane tab="资讯配置" key="info-config" :forceRender="true">
              <info-config v-model:infoConfig="infoConfigData" ref="infoConfigRef" />
            </gl-tab-pane>
            <gl-tab-pane tab="报告配置" key="report-config" :forceRender="true">
              <report-config v-model:reportConfig="reportConfigData" ref="reportConfigRef" />
            </gl-tab-pane>
          </gl-tabs>
        </div>
      </gl-spin>
    </div>
  </full-modal>
</template>
<script setup lang="ts">
import { FullModal, Icon } from '@mysteel-standard/components'
import { ref, computed } from 'vue'
import DataConfig from './data-config.vue'
import ChartConfig from './chart-config.vue'
import InfoConfig from './info-config.vue'
import ReportConfig from './report-config.vue'
interface Props {
  nodeConfigVisible: boolean
  form: any
  loading: boolean
  curNodeData: any
  type: string
}
interface Emits {
  (e: 'update:nodeConfigVisible', val: boolean): void
  (e: 'sure-node-config', data: any): void
  (e: 'show-node-info'): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  nodeConfigVisible: false
})
const saveLoading = ref(false)

const nodeVisible = computed({
  get() {
    closeLoading()
    return props.nodeConfigVisible
  },
  set(val: boolean) {
    emits('update:nodeConfigVisible', val)
  }
})
const closeLoading = () => {
  saveLoading.value = false
}

const activeKey = ref('data-config')
const indexConfigData = ref<any>([])
const chartConfigData = ref<any>([])
const infoConfigData = ref({})
const reportConfigData = ref({})
const indexConfigRef = ref()
const chartConfigRef = ref()
const infoConfigRef = ref()
const reportConfigRef = ref()
const varietyname = ref('')
const editVarietynameFlag = ref(false)
const varietynameInput = ref('')
const initData = (data: any) => {
  const { indexConfig, chartConfig, infoConfig, reportConfig } = data
  indexConfigData.value = [...indexConfig]
  chartConfigData.value = [...chartConfig]
  infoConfigData.value =
    infoConfig === null
      ? {
          firstBreed: '宏观',
          secondBreeds: [],
          secondBreedsIsAll: false,
          firstData: [],
          firstDataIsAll: false,
          secondData: [],
          secondDataIsAll: false,
          keywords: [],
          showNum: 7
        }
      : JSON.parse(infoConfig)
  reportConfigData.value =
    reportConfig === null
      ? { firstBreed: '钢材', reportType: [], keywords: [], showNum: 7 }
      : JSON.parse(reportConfig)
  indexConfigRef.value?.initData(data.indexConfig)
  chartConfigRef.value?.initData(data.chartConfig)
  infoConfigRef.value?.initData(infoConfigData.value)
  varietyname.value = data.varietyname || ''
  varietynameInput.value = varietyname.value
}
const handleSave = () => {
  saveLoading.value = true
  const form = {
    indexConfig: indexConfigData.value,
    chartConfig: chartConfigData.value,
    infoConfig: !infoConfigData.value ? '' : JSON.stringify(infoConfigData.value),
    reportConfig: !reportConfigData.value ? '' : JSON.stringify(reportConfigData.value),
    varietyname: varietyname.value
  }
  emits('sure-node-config', form)
}
//编辑标题
const showNodeInfo = () => {
  if (props.type === 'stainless') {
    editVarietynameFlag.value = true
  } else {
    emits('show-node-info')
  }
}

const editVarietyname = () => {
  editVarietynameFlag.value = false
  varietyname.value = varietynameInput.value
}

const cancelVarietyname = () => {
  editVarietynameFlag.value = false
  varietynameInput.value = varietyname.value
}

defineExpose({ initData })
</script>
<style lang="scss">
.node-config {
  &-warp {
    height: 100%;
    .gl-spin-container {
      height: 100%;
    }
    .gl-spin-nested-loading {
      height: calc(100% - 32px);
    }
    .node-edit {
      display: flex;
      align-items: center;
      .nodeName {
        margin: 0 4px 0 8px;
      }
      .edit-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 4px;
        &:hover {
          color: #023985;
          background: #ebf4ff;
        }
      }
    }
  }
  &-content {
    height: 100%;
    overflow: auto;
    :deep(.index-config-wrap) {
      height: 100%;
    }
  }
}
</style>
