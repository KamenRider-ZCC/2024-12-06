<!--
 * @Autor: zhouwanwan
 * @Date: 2023-08-01 13:57:58
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-11 21:44:07
 * @Description: 
-->
<template>
  <gl-modal v-model:visible="addVisible" title="添加图表" @ok="handleOk" centered width="700px">
    <div class="add-chart-wrap">
      <chart-set-tree @get-chart-list="getChartList" v-if="addVisible" />
      <div class="chart-list">
        <div class="chart-list-search">
          <gl-form layout="inline" :model="searchForm">
            <gl-form-item name="chartName" label="">
              <gl-input
                v-model:value="searchForm.chartName"
                placeholder="请输入图表名称"
                @press-enter="search"
              >
              </gl-input>
            </gl-form-item>
            <gl-button type="primary" @click="search">
              <icon name="icon-search" />
              搜索
            </gl-button>
            <gl-button style="margin: 0 8px" @click="reset">
              <icon name="icon-reset" />
              重置
            </gl-button>
          </gl-form>
        </div>
        <div class="chart-list-check">
          <gl-spin :spinning="chartLoading">
            <div class="check-list-wrap" v-if="searchList && searchList.length">
              <gl-checkbox
                v-model:checked="checkAll"
                :indeterminate="isIndeterminate"
                @change="handleCheckAllChange"
              >
                全选({{ checkedList.length }}/{{ searchList.length }})
              </gl-checkbox>
              <div class="check-group">
                <gl-checkbox-group v-model:value="checkedList">
                  <gl-checkbox v-for="element in searchList" :value="element.id" :key="element.id">
                    <div class="list-item">
                      <div class="chart-name ellipsis">
                        <gl-tooltip
                          class="item"
                          effect="dark"
                          :title="element.name"
                          placement="top-start"
                        >
                          <span>{{ element.name }}</span>
                        </gl-tooltip>
                      </div>
                      <div
                        class="chart-img"
                        :style="{
                          backgroundImage:
                            element && element.imageUrl ? `url(${element.imageUrl})` : false
                        }"
                      ></div>
                    </div>
                  </gl-checkbox>
                </gl-checkbox-group>
              </div>
            </div>
            <div v-else class="flex-ac chart-list-empty">
              <empty />
            </div>
          </gl-spin>
        </div>
      </div>
    </div>
  </gl-modal>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import { ChartSetTree } from '@mysteel-standard/components-business'
import { Empty, Icon } from '@mysteel-standard/components'
import { useChartCheck, useChartList } from '../../composables/use-chart-config'

interface Props {
  addChartVisible: boolean
}
const props = defineProps<Props>()
interface Emits {
  (e: 'update:addChartVisible', val: boolean): void
  (e: 'add-chart', val: any): void
}
const emits = defineEmits<Emits>()
const addVisible = computed({
  get() {
    resetCheck()
    resetSearch()
    return props.addChartVisible
  },
  set(val: boolean) {
    emits('update:addChartVisible', val)
  }
})
const searchList = ref<any[]>([])
//全选、选中项
const { checkedList, checkAll, isIndeterminate, handleCheckAllChange, resetCheck } =
  useChartCheck(searchList)
//图表列表
const { searchForm, chartLoading, search, reset, getChartList, resetSearch } = useChartList(
  resetCheck,
  searchList
)

//提交选择指标
const handleOk = () => {
  console.log('handleOk')
  const checkData = searchList.value.filter((item: any) => {
    return checkedList.value.includes(item.id)
  })
  emits('add-chart', checkData)
  addVisible.value = false
}
</script>
<style lang="scss" scoped>
$borderColor: #e8e8e8;
.add-chart-wrap {
  border: 1px solid $borderColor;
  height: 50.83vh;
  box-sizing: border-box;
  display: flex;
  .chart-set-tree {
    width: 240px;
    padding: 12px 12px 0;
    box-sizing: border-box;
    border-right: 1px solid $borderColor;
  }
  .chart-list {
    flex: 1;
    width: calc(100% - 240px);
    padding: 16px 16px 0;
    box-sizing: border-box;
    &-check {
      overflow-x: hidden;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      height: calc(100% - 62px);
      .check-group {
        height: calc(100% - 20px);
        overflow-y: auto;
        .list-item {
          margin-top: 20px;
          border: 1px solid $borderColor;
          width: 200px;
          height: 120px;
          display: flex;
          flex-direction: column;
          margin-bottom: 13px;
        }
        .chart-name {
          height: 32px;
          line-height: 32px;
          padding: 0 15px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          background: #fafafa;
          color: #333;
        }
        .chart-img {
          flex: 1;
          background-position: center;
          background-size: contain;
        }
      }
      :deep(.empty-div) {
        margin-top: 10vh;
      }
    }
    &-empty {
      height: calc(100% - 62px);
    }
    &-search {
      margin-bottom: 30px;
      :deep(.gl-btn) {
        &:last-child {
          margin-right: 0 !important;
        }
      }
    }
  }
}
</style>
