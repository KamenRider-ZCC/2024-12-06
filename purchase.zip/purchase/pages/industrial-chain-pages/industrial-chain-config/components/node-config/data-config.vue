<template>
  <div class="data-config-wrap">
    <gl-space direction="vertical" :size="8">
      <gl-button type="primary" @click="addIndex"> <icon name="icon-add" />添加指标 </gl-button>
      <div class="index-config-table">
        <ms-table
          class="data-config-table"
          :loading="tableLoading"
          :columns="columns"
          row-key="indexCode"
          :data="dataConfigTable"
        >
          <template #indexName="{ record, index }">
            <div class="index-name">
              <gl-tooltip class="item" :title="record.indexName" placement="top">
                <div class="text-left">{{ record.indexName }}</div>
              </gl-tooltip>
              <icon
                class="edit-icon"
                name="icon-edit"
                size="14"
                color="#023985"
                @click="showEdit(record, index)"
              />
              <span class="default-icon" v-if="index === 0"> 默认 </span>
            </div>
          </template>
          <template #action="{ record, index }">
            <div class="operation-buttons">
              <gl-button type="text" @click.stop="addIndex(index)">替换指标</gl-button>
              <gl-button
                type="text"
                @click.stop="setDefault(record, index)"
                :disabled="index === 0"
              >
                设为默认
              </gl-button>
              <gl-button type="text" @click.stop="move(index)">移除</gl-button>
            </div>
          </template>
        </ms-table>
      </div>
    </gl-space>
    <add-index-modal
      :indexList="indexList"
      v-model:addIndexVisible="addIndexVisible"
      @sure-add-index="getIndexList"
    />
    <edit-name-modal
      v-if="editVisible"
      v-model:editVisible="editVisible"
      :form="indexForm"
      editLabel="指标名称"
      editKey="indexName"
      @change-data="changeName"
    />
  </div>
</template>
<script setup lang="ts">
import { ref, onMounted, watch, nextTick } from 'vue'
import { MsTable, Icon } from '@mysteel-standard/components'
import {
  useAddOrChange,
  useMove,
  useSetDefault,
  useEditName,
  useTableSort
} from '../../hooks/use-config'
import AddIndexModal from './add-index-modal.vue'
import EditNameModal from './edit-name-modal.vue'
interface Props {
  indexConfig: any
}
interface Emits {
  (e: 'update:indexConfig', data: any): void
}
const emits = defineEmits<Emits>()
defineProps<Props>()
const dataConfigTable = ref<any>([])

const columns = [
  {
    title: '',
    dataIndex: 'drag',
    key: 'drag',
    align: 'center',
    width: 50
  },
  {
    title: '指标名称',
    dataIndex: 'indexName',
    key: 'indexName',
    slotName: 'indexName',
    width: 450
  },
  {
    title: '最新值',
    dataIndex: 'newestData',
    key: 'newestData',
    type: 'function',
    callback: (row: any) => {
      return typeof row.newestData === 'number' ? row.newestData : '-'
    }
  },
  {
    title: '单位',
    dataIndex: 'unit',
    key: 'unit',
    ellipsis: true,
    type: 'function',
    callback: (row: any) => {
      return row.unit ? row.unit : '-'
    }
  },
  {
    title: '开始日期',
    dataIndex: 'beginDate',
    key: 'beginDate',
    type: 'function',
    callback: (row: any) => {
      return row.beginDate ? row.beginDate : '-'
    }
  },
  {
    title: '结束日期',
    dataIndex: 'endDate',
    key: 'endDate',
    type: 'function',
    callback: (row: any) => {
      return row.endDate ? row.endDate : '-'
    }
  },
  {
    title: '指标编码',
    dataIndex: 'indexCode',
    key: 'indexCode',
    ellipsis: true,
    width: 290
  },
  {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    width: 290
  }
]
//编辑
const { editVisible, showEdit, changeName, indexForm } = useEditName(dataConfigTable)
// 添加、替换指标
const {
  addVisible: addIndexVisible,
  addOrChange: addIndex,
  getAddList: getIndexList,
  tableLoading,
  indexList
} = useAddOrChange(dataConfigTable, '')
//移除
const { move } = useMove(dataConfigTable)
//设置默认
const { setDefault } = useSetDefault(dataConfigTable)
// 拖拽排序
const { tableSortable } = useTableSort('.data-config-table .gl-table-tbody', dataConfigTable)
// 排序
watch(
  () => dataConfigTable.value,
  (val) => {
    let dataConfig = []
    if (val && val.length) {
      nextTick(() => {
        tableSortable()
      })
      dataConfig =
        val.length &&
        val.map((item: any, index: number) => {
          return {
            ...item,
            sort: index + 1,
            isDefault: index === 0 ? 1 : 0
          }
        })
    }

    emits('update:indexConfig', dataConfig)
  },
  {
    deep: true
  }
)
const initData = (data: any) => {
  dataConfigTable.value = data
}
defineExpose({ initData })
</script>
<style scoped lang="scss">
@import '../../style/config.scss';
@include ConfigListLayout('data-config-wrap');
</style>
