<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-01 11:28:43
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 11:56:57
 * @Description: 产业链配置 工作流
-->
<template>
  <div class="industrial-flow" v-if="!isEmpty">
    <div class="flow-container" ref="flowContainerRef">
      <super-flow
        ref="superFlowRef"
        :node-list="nodeList"
        :link-list="linkList"
        :link-style="linkStyle"
        :link-menu="linkMenuList"
        :node-menu="nodeMenu"
      >
        <template #node="{ meta }">
          <div
            class="flow-node ellipsis"
            :style="{ 'text-align': meta.nodeType === 2 ? 'center' : 'left' }"
          >
            <div class="item-icon-name">
              <gl-tooltip :title="meta?.indexList[0]?.indexName">
                <span class="item-name ellipsis">
                  <img :src="meta.fileList[0].response.message" v-if="meta.fileList?.length > 0" />
                  <icon :name="meta.nodeIcon" v-if="meta.nodeIcon" />
                  <span class="item-name-text">
                    {{ meta.nodeName }}
                  </span>
                </span>
              </gl-tooltip>
            </div>
            <div class="item-data" :class="upDownClass(meta?.indexList[0]?.upDown)[0]">
              <gl-tooltip :title="meta?.indexList[0]?.dataValue">
                <span class="item-name ellipsis">
                  {{ meta?.indexList[0]?.dataValue }}
                </span>
              </gl-tooltip>
            </div>
            <div class="item-data" :class="upDownClass(meta?.indexList[0]?.upDown)[0]">
              <gl-tooltip :title="meta?.indexList[0]?.dataValue + meta?.indexList[0]?.upDown">
                <span class="item-name ellipsis">
                  {{ upDownClass(meta?.indexList[0]?.upDown)[1] }}{{ meta?.indexList[0]?.upDown }}
                </span>
              </gl-tooltip>
            </div>
          </div>
        </template>
      </super-flow>
      <VueDragResize
        v-for="item in dashedNodeList"
        :parentLimitation="true"
        :isActive="true"
        :w="item.width"
        :h="item.height"
        :x="item.x"
        :y="item.y"
        :z="998"
        :key="item.id"
        :preventActiveBehavior="true"
        @resizing="resizing($event, item.id)"
        @dragstop="dragStop($event, item.id)"
      >
        <icon name="icon-del" class="btn-del" @click="delDashed(item.id)" />
      </VueDragResize>
    </div>
    <div class="mask-container"></div>
  </div>
  <div class="empty" v-else>
    <Empty :emptyText="'暂无节点，请拖入节点组件'"></Empty>
  </div>
</template>

<script setup lang="ts">
import { cloneDeep } from 'lodash-es'
import { Icon, Empty } from '@mysteel-standard/components'
import { SuperFlow } from 'vue3-super-flow'
import 'vue3-super-flow/dist/style.css'
import useInitFlow from './composables/use-init-flow'
import { createUUID } from '@mysteel-standard/utils'
import { watch, ref, nextTick } from 'vue'
import VueDragResize from 'vue-drag-resize/src'
import { upDownClass } from '../../../industrial-chain/utils/index'
interface Props {
  defaultNodeList: any
}
const props = defineProps<Props>()
//emits
interface Emits {
  (e: 'open-node-info-modal', val: any): void
  (e: 'edit-node-info', val: any): void
}
const emits = defineEmits<Emits>()

//监听默认节点信息
watch(
  () => props.defaultNodeList,
  (val) => {
    if (val !== '') {
      const nodeJson = cloneDeep(JSON.parse(val))
      nodeJson.nodeList?.forEach((item: any) => {
        item.meta.indexList = item.indexList ? item.indexList : []
      })
      nodeList.value = nodeJson.nodeList
      linkList.value = nodeJson.linkList
      dashedNodeList.value = nodeJson.dashedNodeList
      isEmpty.value = false
    }
  },
  { deep: true }
)

const isEmpty = ref(true)
const flowContainerRef = ref()
const superFlowRef = ref()
//虚宽节点
const dashedNodeList: any = ref([])
//节点信息
const { nodeList, nodeMenu, linkStyle, linkMenuList, linkList } = useInitFlow(emits)

const dragEnd = async ({ event, type, offsetLeft, offsetTop }: any) => {
  isEmpty.value = false
  await nextTick()

  const { clientX, clientY } = event
  const { top, right, bottom, left } = flowContainerRef.value.getBoundingClientRect()
  if (clientX > left && clientX < right && clientY > top && clientY < bottom) {
    const id = createUUID()

    if (type === 'node') {
      // 获取拖动元素左上角相对 super flow 区域原点坐标
      const coordinate = superFlowRef.value.getMouseCoordinate(
        clientX - offsetLeft,
        clientY - offsetTop
      )
      const nodeInfo = {
        coordinate,
        id,
        width: 220,
        height: 40,
        meta: { indexList: [] }
      }
      emits('open-node-info-modal', nodeInfo)
    } else {
      const dashedNode = {
        id,
        width: 220,
        height: 200,
        x: clientX - offsetLeft - left,
        y: clientY - offsetTop - top
      }
      dashedNodeList.value.push(dashedNode)
    }
  }
}

const addFlowNode = (nodeInfo: any) => {
  // 添加节点
  superFlowRef.value.addNode(nodeInfo)
}

//获取配置信息
const getFlowConfig = () => {
  if (!superFlowRef.value) return
  const { nodeList, linkList } = superFlowRef.value.toJSON()
  return { nodeList, linkList, dashedNodeList: dashedNodeList.value }
}

//删除虚线节点
const delDashed = (id: string) => {
  dashedNodeList.value = dashedNodeList.value.filter((item: { id: string }) => item.id !== id)
}

const resizing = ($event: any, id: string) => {
  const { left, top, width, height } = $event
  dashedNodeList.value.forEach((item: any) => {
    if (item.id === id) {
      item.width = width
      item.height = height
      item.x = left
      item.y = top
    }
  })
}
const dragStop = ($event: any, id: string) => {
  const { left, top, width, height } = $event
  dashedNodeList.value.forEach((item: any) => {
    if (item.id === id) {
      item.width = width
      item.height = height
      item.x = left
      item.y = top
    }
  })
}

defineExpose({ addFlowNode, getFlowConfig, dragEnd })
</script>

<style lang="scss" scoped>
.industrial-flow {
  height: 200%;
  width: 200%;

  .flow-container {
    position: relative;
    height: 100%;
    width: 100%;
    background: #ffffff;
    .flow-node {
      width: 100%;
      display: flex;
      line-height: 23px;
      .item-icon-name {
        width: 45%;
        .item-name-text {
          margin: 0 16px;
        }
      }
      .item-data {
        width: 25%;
        margin: 0 4px;
      }
    }
    :deep(.super-flow__node) {
      z-index: 999;
    }
    :deep(.super-flow__menu) {
      z-index: 999;
    }
  }
  .mask-container {
    width: calc(100% - 8px);
    height: calc(100% - 8px);
    position: absolute;
    top: 0;
    left: 0;
    overflow: hidden;
  }
}
:deep(.super-flow__node) {
  border-radius: 4px;
  border: 1px solid #0149aa;
  padding: 8px;
  font-size: 14px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #0149aa;
  background: #ebf4ff;
}

.empty {
  margin-top: 240px;
}

:deep(.vdr.active) {
  &:before {
    outline: 1px dashed #0149aa;
  }
}
:deep(.vdr-stick) {
  border: 1px solid #0149aa;
}

.btn-del {
  float: right;
  margin: 8px;
  color: #0149aa;
  cursor: pointer;
}

.control-content {
  position: absolute;
  right: 24px;
  bottom: 24px;
  z-index: 999;
  > div {
    width: 40px;
    height: 40px;
    background: #ffffff;
    text-align: center;
    line-height: 40px;
    font-size: 20px;
    cursor: pointer;
  }
  .reset {
    margin-bottom: 10px;
    border: 1px solid #dddddd;
    border-radius: 8px;
  }
  .zoomIn {
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    border: 1px solid #dddddd;
  }
  .zoomOut {
    border-bottom-left-radius: 8px;
    border-bottom-right-radius: 8px;
    border: 1px solid #dddddd;
    border-top: 0;
  }
}
</style>
