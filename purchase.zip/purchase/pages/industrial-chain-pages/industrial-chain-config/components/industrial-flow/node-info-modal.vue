<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-03 10:48:01
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-15 14:21:54
 * @Description: 节点新增编辑弹窗
-->
<template>
  <gl-modal
    v-model:visible="visible"
    centered
    :title="isEditNodeInfo ? '编辑节点' : '新增节点'"
    @ok="handleOk"
    :width="460"
    @cancel="handleCancel"
    :confirmLoading="loading"
  >
    <gl-form ref="formRef" :model="formState" :rules="rules">
      <gl-form-item label="节点名称" name="nodeName">
        <gl-input v-model:value.trim="formState.nodeName" :maxlength="25" style="width: 300px" />
      </gl-form-item>
      <gl-form-item label="节点图标" style="padding-left: 12px">
        <div class="icon-content">
          <div
            class="icon-item"
            v-for="(item, index) in list"
            :key="index"
            @click="chooseIcon(item)"
            :class="{ active: item === formState.nodeIcon }"
          >
            <icon
              :name="'icon-shanchu'"
              class="btn-del"
              v-show="item === formState.nodeIcon"
              @click.stop="delIcon()"
              :size="'12'"
            ></icon>
            <icon :name="item"></icon>
          </div>
        </div>
        <div class="upload-content">
          <gl-upload
            v-model:file-list="formState.fileList"
            :before-upload="beforeUpload"
            name="file"
            action="/database/varietyResearch/uploadPic"
            @change="handleChange"
            :max-count="1"
          >
            <gl-button type="primary">
              <icon name="icon-extract_outlined" />
              上传图标
            </gl-button>
            <span style="font-size: 12px; color: #333; margin: 6px">请上传16*16的SVG格式图标</span>
          </gl-upload>
        </div>
      </gl-form-item>
      <gl-form-item label="节点类型" name="nodeType" v-show="!isEditNodeInfo">
        <gl-radio-group v-model:value="formState.nodeType" name="nodeType">
          <gl-radio :value="1">产业链品种</gl-radio>
          <gl-radio :value="2">产业链流程 </gl-radio>
        </gl-radio-group>
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>

<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { iconNameList } from '../../types/interface'
import { computed, ref } from 'vue'
import { message, Upload } from 'gl-design-vue'
const list: any = iconNameList
//props
interface Props {
  nodeInfoVisible: boolean
  formInfo: any
  isEditNodeInfo: boolean
}
const props = defineProps<Props>()
//emits
interface Emits {
  (e: 'update:nodeInfoVisible', val: boolean): void
  (e: 'handle-ok'): void
}
const emits = defineEmits<Emits>()
//默认
const loading = ref(false)
const visible = computed(() => props.nodeInfoVisible)
const formRef = ref()

const formState: any = computed(() => props.formInfo)

const rules = {
  nodeName: [{ required: true, message: '请输入节点名称', trigger: 'blur', max: 25 }],
  nodeType: [{ required: true }]
}

//选择节点图表
const chooseIcon = (iconName: string) => {
  formState.value.nodeIcon = iconName
  formState.value.fileList = []
}
//移除节点图表
const delIcon = () => {
  formState.value.nodeIcon = ''
}

const handleOk = () => {
  formRef.value.validate().then(() => {
    emits('handle-ok')
  })
}
const handleCancel = () => {
  emits('update:nodeInfoVisible', false)
}

const handleChange = (info: any) => {
  loading.value = true
  if (info.file.status === 'done') {
    loading.value = false
    formState.value.nodeIcon = ''
    message.success('文件上传成功')
  } else if (info.file.status === 'error') {
    loading.value = false
    message.error('文件上传失败')
  } else if (info.file.status === 'removed') {
    loading.value = false
  }
}

const beforeUpload = (file: any) => {
  const isPNG = file.type === 'image/svg+xml'
  if (!isPNG) {
    message.error('请上传16*16的SVG格式图标')
  }
  return isPNG || Upload.LIST_IGNORE
}
</script>

<style lang="scss" scoped>
.icon-content {
  display: flex;
  border: 1px solid #3333;
  flex-wrap: wrap;
  justify-content: flex-start;
  width: 298px;
  height: 150px;
  padding-left: 8px;
  .icon-item {
    width: 25px;
    height: 25px;
    border: 1px solid #dddddd;
    text-align: center;
    margin: 5px;
    padding: 2px;
    cursor: pointer;
    color: #333;
    position: relative;
    .btn-del {
      position: absolute;
      top: -6px;
      right: -8px;
    }
    &.active {
      color: #fff;
      border-color: #023985;
      background-color: #023985;
    }
  }
}

.upload-content {
  margin-top: 16px;
}
</style>
