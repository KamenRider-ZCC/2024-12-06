<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 13:37:22
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-02 08:43:24
 * @Description:新增配置 
-->
<template>
  <form-modal
    title="新增配置"
    v-model:visible="visible"
    :formItems="formItems"
    v-model:formParams="addModifyForm"
    @ok="handleOk"
  ></form-modal>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import { FormModal } from '@mysteel-standard/components'
interface Props {
  addIndustrialChainVisible: boolean
  form: any
}
interface Emits {
  (e: 'update:addIndustrialChainVisible', val: boolean): void
  (e: 'sure-add-industrial-chain', form: any): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  addIndustrialChainVisible: false
})

const addModifyForm = computed(() => props.form)
const visible = computed({
  get() {
    return props.addIndustrialChainVisible
  },
  set(val: boolean) {
    emits('update:addIndustrialChainVisible', val)
  }
})
const formItems = [
  {
    label: '产业链名称',
    name: 'panoramagramName',
    rules: [
      { required: true, message: '请输入产业链名称' },
      { max: 25, message: '长度限制为25个字符', trigger: 'blur' }
    ]
  }
]
// 确认新建、重命名目录
const handleOk = () => {
  emits('sure-add-industrial-chain', addModifyForm.value)
  visible.value = false
}
</script>
