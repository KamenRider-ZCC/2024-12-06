<template>
  <ms-table
    class="config-table"
    :columns="columns"
    :loading="loading"
    row-key="id"
    :data="configTableData"
    @switch-change="handleSwitchChange"
  >
    <template #action="{ record }">
      <div class="operation-buttons">
        <gl-button type="text" @click.stop="handleCopy(record)" v-if="record.id !== 1">
          复制
        </gl-button>
        <gl-button type="text" :disabled="record.isEnable === 1" @click.stop="handleEdit(record)">
          编辑
        </gl-button>
        <gl-popconfirm
          v-if="configTableData.length"
          title="是否删除对应配置?"
          :disabled="record.isEnable === 1"
          @confirm="handleDelete(record.id, record.panoramagramName)"
        >
          <gl-button type="text" :disabled="record.isEnable === 1" v-if="record.id !== 1">
            删除</gl-button
          >
        </gl-popconfirm>
      </div>
    </template>
  </ms-table>
</template>
<script setup lang="ts">
import { onMounted } from 'vue'
import { ConfigListType } from '../types/interface'
import { MsTable } from '@mysteel-standard/components'
// import { checkPermit } from '@mysteel-standard/hooks'
import { useTableSort } from '../hooks/use-config'
import { computed } from 'vue'
interface Props {
  configTableData: ConfigListType[]
  loading: boolean
}
const props = defineProps<Props>()
interface Emits {
  (e: 'modify-config', record: ConfigListType): void
  (e: 'sort-change', sorter: Object): void
  (e: 'switch-change', params: any): void
  (e: 'delete', params: { id: number }): void
  (e: 'copy-config', val: ConfigListType): void
  (e: 'drag', params: any): void
}
const emits = defineEmits<Emits>()
//列表
const columns = [
  {
    title: '拖动排序',
    dataIndex: 'drag',
    key: 'drag',
    align: 'center',
    width: 100
  },
  {
    title: '展示顺序',
    dataIndex: 'sort',
    key: 'sort',
    align: 'center'
  },
  {
    title: '产业链名称',
    dataIndex: 'panoramagramName',
    key: 'panoramagramName',
    ellipsis: true,
    width: 520
  },
  {
    title: '修改人',
    dataIndex: 'updateName',
    key: 'updateName'
  },
  {
    title: '更新时间',
    dataIndex: 'updateTime',
    key: 'updateTime'
  },

  {
    title: '状态',
    dataIndex: 'isEnable',
    key: 'isEnable',
    type: 'switch'
  },
  {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    width: 220
  }
]
const tableData = computed(() => props.configTableData)
// 拖拽排序
const { tableSortable } = useTableSort('.config-table .gl-table-tbody', tableData.value, emits)
//状态切换
const handleSwitchChange = (record: ConfigListType) => {
  const { id, isEnable } = record
  const params = {
    isEnable,
    id
  }
  emits('switch-change', params)
}
//删除
const handleDelete = (id: number, panoramagramName: string) => {
  const params = { id, panoramagramName }
  emits('delete', params)
}
//编辑
const handleEdit = (record: ConfigListType) => {
  emits('modify-config', record)
}
//复制
const handleCopy = (record: ConfigListType) => {
  emits('copy-config', record)
}
// const tableChange = (page: Object, filters: Object, sorter: Object) => {
//   emits('sort-change', sorter)
// }
onMounted(() => {
  tableSortable()
})
</script>
<style lang="scss" scoped></style>
