import { ref } from 'vue'
import api from '../api'
export default (type: any, informationForm: any) => {
  // 二级品种、市场、地区
  const firstOption: any = ref([])
  const secondOption: any = ref([])
  const breedOptions: any = ref([])
  const secondBreedRef: any = ref(null)
  const formLoading: any = ref(false)

  //市场
  const getFirstData = async (breedName: string) => {
    const { res, err } = await api.getTagClassifyList({ breedName })
    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        firstOption.value = data.map((item: { tagName: any; tagId: any }) => {
          const obj = {
            label: item.tagName,
            value: item.tagId
          }
          return obj
        })
        getSecondData(data)
      }
    }
  }
  //地区
  const getSecondData = (options: any) => {
    const secondData: any[] = []
    options.forEach((item: { children: { tagName: string; tagId: string }[] }) => {
      if (item.children && item.children.length) {
        const children = item.children.map((item: { tagName: string; tagId: string }) => {
          const obj = {
            label: item.tagName,
            value: item.tagId
          }
          return obj
        })
        secondData.push(...children)
      }
      secondOption.value = [...secondData]
    })
  }
  // 获取二级品种
  const getSecondBreeds = async (val: any) => {
    const params = {
      breedName: val
    }
    formLoading.value = true
    const { res, err } = await api.getTwoMultipleChoiceTagList(params)
    formLoading.value = false
    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        breedOptions.value = data.map((item: { tagName: any; tagId: any }) => {
          const obj = {
            label: item.tagName,
            value: item.tagId
          }
          return obj
        })
      }
    }
  }
  // 初始化（二级品种、市场、地区)
  const initOption = async (breedName: string) => {
    await getSecondBreeds(breedName)
    await getFirstData(breedName)
  }
  return {
    firstOption,
    secondOption,
    breedOptions,
    secondBreedRef,
    formLoading,
    getSecondBreeds,
    initOption,
    getFirstData
  }
}
