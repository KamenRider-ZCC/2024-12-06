/*
 * @Autor: zhouwanwan
 * @Date: 2023-08-01 14:42:14
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-09 09:09:55
 * @Description:图表配置
 */
import api from '../api/index'
//全选、复选框选中
export const useChartCheck = (searchList: Ref) => {
  const state = reactive({
    isIndeterminate: false,
    checkAll: false,
    checkedList: []
  })
  const handleCheckAllChange = (e: any) => {
    const ids = searchList.value.map((item: any) => {
      return item.id
    })
    state.checkedList = e.target.checked ? ids : []
    state.isIndeterminate = false
  }
  const resetCheck = () => {
    state.isIndeterminate = false
    state.checkAll = false
    state.checkedList = []
  }
  watch(
    () => state.checkedList,
    (val: any) => {
      state.isIndeterminate = !!val.length && val.length < searchList.value.length
      state.checkAll = val.length ? val.length === searchList.value.length : false
    }
  )

  return {
    ...toRefs(state),
    handleCheckAllChange,
    resetCheck
  }
}
//图表列表、搜索
export const useChartList = (resetCheck: Function, searchList: Ref) => {
  const templateList = ref<any[]>([])

  const chartLoading = ref(false)
  const searchForm = ref({ chartName: '' })
  const getChartList = async (data: any) => {
    resetCheck()
    const { node, tabIndex } = data
    const params = {
      catalogueId: node.id,
      queryType: 0,
      type: tabIndex,
      chartType: 0
    }
    chartLoading.value = true
    const { err, res } = await api.queryChartsList(params)
    chartLoading.value = false
    if (!err && res) {
      const { list } = res.data
      templateList.value = [...list]
      searchList.value = [...list]
    }
  }
  //搜索
  const search = () => {
    const searchData = templateList.value.filter((item) => {
      return item.name.indexOf(searchForm.value.chartName) > -1
    })
    if (searchData) {
      searchList.value = [...searchData]
    }
  }
  const reset = () => {
    resetCheck()
    searchList.value = [...templateList.value]
    searchForm.value.chartName = ''
  }
  const resetSearch = () => {
    searchForm.value.chartName = ''
    getChartList({ node: { id: 0 }, tabIndex: 1 })
  }
  return {
    searchForm,
    searchList,
    chartLoading,
    search,
    reset,
    getChartList,
    resetSearch
  }
}
//预览
export const usePreviewChart = () => {
  const previewChartVisible = ref(false)
  const curThumbnail = ref('')
  const leftPosition = ref(0)
  const previewChart = (row: any, index: number) => {
    previewChartVisible.value = true
    const { config } = row
    const { imageUrl } = config && JSON.parse(config)
    curThumbnail.value = imageUrl
    const id = `index-name_${index}`
    const previewEl: any = document.getElementById(id)
    const width = previewEl.offsetWidth + 160
    leftPosition.value = width
  }
  const closePreview = () => {
    previewChartVisible.value = false
  }
  return {
    previewChartVisible,
    previewChart,
    curThumbnail,
    closePreview,
    leftPosition
  }
}
