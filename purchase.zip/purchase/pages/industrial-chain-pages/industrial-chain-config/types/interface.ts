/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-31 20:19:04
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-04 10:25:40
 * @Description:
 */
export interface ConfigListType {
  id: number
  isEnable: number | undefined
  isSystem?: number
  panoramagramName: string
  sort?: Number
  updateName?: string
  updateTime?: string
}

export const iconNameList = [
  'icon-lantan',
  'icon-meitan',
  'icon-jiaotan',
  'icon-tongfeisuiliao',
  'icon-tiekuangshi',
  'icon-dianjietong',
  'icon-zhonghouban',
  'icon-menggui',
  'icon-tongjingkuang',
  'icon-banpi',
  'icon-reyabanjuan',
  'icon-lengyabanjuan',
  'icon-tongbo',
  'icon-tongbandai',
  'icon-reyakaipingban',
  'icon-lengyakaipingban',
  'icon-fangpi',
  'icon-tegang',
  'icon-jingtonggan',
  'icon-shifatong',
  'icon-jiaogang',
  'icon-gongmojugang',
  'icon-guanpi',
  'icon-wufengguan',
  'icon-hanguan'
]
