<template>
  <page-layout class="industrial-chain-index" />
</template>
<script setup lang="ts">
import { PageLayout } from '@mysteel-standard/components'
</script>
<style lang="scss" scoped></style>
