<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-07-07 09:15:07
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-28 16:05:25
 * @Description: 
-->
<template>
  <gl-modal v-model:visible="previewVisible" :footer="null" :width="1240">
    <div v-if="headerTitle.show" :style="headerTitleStyle">{{ headerTitle.name }}</div>
    <gl-divider />
    <gl-spin :spinning="loading">
      <div class="preview-wrap">
        <edit-chart
          v-if="curEl.componentName === 'chart'"
          :curEl="curEl"
          :seasonChecked="seasonChecked"
          :indexDataSeason="indexDataSeason"
        />
        <edit-table v-if="curEl.componentName === 'table'" :data="tableData" :outline="outline" />
      </div>
    </gl-spin>
    <gl-divider />
    <div v-if="footerTitle.show" :style="footerTitleStyle">{{ footerTitle.name }}</div>
  </gl-modal>
</template>
<script setup lang="ts">
import api from '../api'
import { EditChart, EditTable } from '@mysteel-standard/components-business'
import { useUpdateDiagramTable, useUpdateDiagramChart } from '@mysteel-standard/hooks'
import { cloneDeep } from 'lodash-es'

interface Props {
  visible: any
  id: any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'update:visible', val: boolean): void
}
const emits = defineEmits<Emits>()

const outline = reactive({
  color: '#eeece1',
  style: 'solid',
  width: 1
})

const previewVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})

const loading = ref<boolean>(false)
const { updateTableData } = useUpdateDiagramTable(loading)
const state: any = reactive({
  curEl: {},
  extractParam: {}
})
const { curEl }: any = toRefs(state)
const tableData = ref<any[]>([])
const LAYOUT_TYPE: any = {
  'bar-line': 'legendLayout',
  'chart-pie': 'legendLayoutPie',
  'sequence-table': 'layoutTable',
  'free-table': 'layoutTable',
  'scatter-plot': 'legendLayoutScatter',
  'chart-radar': 'legendLayoutRadar'
}
//标题
const headerTitle = ref<any>({})
const footerTitle = ref<any>({})
const headerTitleStyle = computed(() => ({
  ...headerTitle.value,
  fontSize: `${headerTitle.value.fontSize}px`
}))
const footerTitleStyle = computed(() => ({
  ...footerTitle.value,
  fontSize: `${footerTitle.value.fontSize}px`
}))
// 季节性
const seasonChecked = ref(false)
const indexDataSeason = ref([])

const { updateChartTableData, updatePiePlotData, updateRadarData, updateSeasonChart } =
  useUpdateDiagramChart(state, loading)

watch(
  () => props.visible,
  async (val) => {
    if (val) {
      loading.value = true
      const { res, err } = await api.queryChartInfo({ chartId: props.id })
      loading.value = false
      if (res && !err) {
        const { curEl, extractParam } = JSON.parse(res.data.config)
        state.curEl = curEl
        state.extractParam = extractParam
        const { contentOption } = curEl
        headerTitle.value = contentOption[LAYOUT_TYPE[state.curEl.id]].titleFont.headerTitle
        footerTitle.value = contentOption[LAYOUT_TYPE[state.curEl.id]].titleFont.footerTitle
        // 季节性
        seasonChecked.value = contentOption.seasonChecked
        //更新图
        if (state.curEl.id === 'bar-line') {
          if (seasonChecked.value) {
            const indexData = state.curEl.contentOption.indexOptionsBarLine.filter(
              (item: any) => item.indexCode === state.curEl.contentOption.seasonIndexCode
            )[0]
            updateSeasonChart(indexData, indexDataSeason)
          } else {
            updateChartTableData({})
          }
        } else if (state.curEl.id === 'sequence-table' || state.curEl.id === 'free-table') {
          updateChartTableData()
        } else if (state.curEl.id === 'chart-pie' || state.curEl.id === 'scatter-plot') {
          updatePiePlotData()
        } else if (state.curEl.id === 'chart-radar') {
          updateRadarData()
        }
        //表格更新
        if (curEl.id === 'free-table' || curEl.id === 'sequence-table') {
          const newTableData = await updateTableData(curEl, curEl.tableData, extractParam)
          tableData.value = cloneDeep(newTableData)
        }
      }
    }
  }
)
</script>
<style lang="scss" scoped>
.preview-wrap {
  height: 600px;
  background-color: #fff;
  background-repeat: no-repeat;
  background-size: contain;
  background-position: center center;
  position: relative;
  overflow: auto;
}
</style>
