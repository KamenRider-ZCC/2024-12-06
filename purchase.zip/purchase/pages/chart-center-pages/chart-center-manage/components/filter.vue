<template>
  <div class="filtering">
    <gl-dropdown v-if="selectItem.tabValue === 2" :trigger="['click']">
      <template #overlay>
        <gl-menu>
          <gl-menu-item v-for="item in dropShowList" :key="item.id" @click="handleFilterItem(item)">
            {{ item.label }}
          </gl-menu-item>
        </gl-menu>
      </template>
      <gl-button class="filter-btn" style="margin-right: 8px">
        {{ showChartObj.label }}
        <icon name="icon-up_outlined" />
      </gl-button>
    </gl-dropdown>
    <gl-dropdown :trigger="['click']">
      <template #overlay>
        <gl-menu>
          <gl-menu-item v-for="item in dropSortList" :key="item.id" @click="handleSortItem(item)">
            <template #icon>
              <Icon v-if="item.id == 2 || item.id == 4" name="icon-asc" />
              <Icon v-else name="icon-des" />
            </template>
            {{ item.label }}
          </gl-menu-item>
        </gl-menu>
      </template>
      <gl-button class="filter-btn">
        {{ showSortObj.label }}
        <icon name="icon-up_outlined" />
      </gl-button>
    </gl-dropdown>
  </div>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { FilterList } from '../types/interface'

interface Props {
  selectItem: any
}
defineProps<Props>()
interface Emits {
  (e: 'handle-filter', val: { showChartObj: FilterList; showSortObj: FilterList }): void
}
const emits = defineEmits<Emits>()

const showChartObj = ref<FilterList>({
  id: 0,
  label: '全部'
})
const showSortObj = ref<FilterList>({
  id: 4,
  label: '按创建时间倒序'
})
const dropShowList = reactive<FilterList[]>([
  { id: 0, label: '全部' },
  { id: 1, label: '仅自建图表' },
  { id: 2, label: '仅收藏图表' }
])
const dropSortList = reactive<FilterList[]>([
  { id: 1, label: '按名称顺序' },
  { id: 2, label: '按名称倒序' },
  { id: 3, label: '按创建时间顺序' },
  { id: 4, label: '按创建时间倒序' }
])

const handleFilterItem = (item: FilterList) => {
  showChartObj.value = item
  emits('handle-filter', {
    showChartObj: showChartObj.value,
    showSortObj: showSortObj.value
  })
}
const handleSortItem = (item: FilterList) => {
  showSortObj.value = item
  emits('handle-filter', {
    showChartObj: showChartObj.value,
    showSortObj: showSortObj.value
  })
}
</script>
<style lang="scss" scoped>
.filtering,
.filter-btn {
  display: flex;
  align-items: center;
}
</style>
