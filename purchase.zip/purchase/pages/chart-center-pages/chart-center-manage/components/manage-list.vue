<template>
  <div class="manage-list">
    <div class="manage-list-header">
      <div class="title">{{ selectItem.tabName }}</div>
      <Filter :selectItem="selectItem" @handle-filter="handleFilter" />
    </div>
    <div class="manage-list-main">
      <div ref="listRef" class="chart-list" @scroll="onScroll">
        <ChartListItem
          v-for="(item, index) in chartList"
          :key="item.id"
          :item="item"
          :selectItem="selectItem"
          :class="{ latestRow: latest.includes(index) }"
          @handle-preview="handlePreview"
          @handle-edit="handleEdit"
          @menu-click="menuClick"
          @update-name="updateName"
          @handle-del="handleDel"
          @handle-copy="handleCopy"
          @cancel-collect="cancelCollect"
        />

        <div v-if="Number(pageNum) > 1 && busy" class="list-load-end">
          <span>{{ pageNum >= pages ? '--我也是有底线的--' : '--加载中--' }}</span>
        </div>
      </div>
    </div>

    <PreviewModal v-model:visible="previewVisible" :id="previewId" />
    <collectModal
      v-model:visible="collectVisible"
      :title="treeTitle"
      :tabItem="tabItem"
      :menuKey="menuKey"
      @handle-submit="handleSubmit"
    />
  </div>
</template>
<script setup lang="ts">
import Filter from './filter.vue'
import useManageList from '../composables/use-manage-list'
import ChartListItem from './chart-list-item.vue'
import PreviewModal from './preview-modal.vue'
import collectModal from './collect-modal.vue'

interface Props {
  selectItem: any
  searchValue: string
}
const props = defineProps<Props>()
interface Emits {
  (e: 'update-loading', val: boolean): void
}
const emits = defineEmits<Emits>()

const {
  chartList,
  previewVisible,
  collectVisible,
  pageNum,
  pages,
  busy,
  latest,
  treeTitle,
  tabItem,
  menuKey,
  listRef,
  previewId,
  handlePreview,
  handleEdit,
  menuClick,
  handleFilter,
  updateName,
  handleDel,
  handleCopy,
  handleSubmit,
  reset,
  cancelCollect,
  onScroll
}: { [key: string]: any } = useManageList(props, emits)

defineExpose({ reset })
</script>
