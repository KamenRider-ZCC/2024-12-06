<template>
  <gl-modal
    v-model:visible="collectVisible"
    :title="title"
    :body-style="{
      height: '380px',
      overflow: 'auto'
    }"
    @ok="handleSubmit"
  >
    <gl-spin :spinning="loading">
      <div v-if="menuKey === 4 && tabItem.value === 1" class="tab-group">
        <ms-tabs
          class="tab"
          v-model:value="tabIndex"
          :tabs="tabData"
          @change="(e:any) => tabClick(e)"
        />
      </div>
      <chart-tree
        ref="treeRef"
        :tabItem="selectTabItem"
        @update-loading="updateLoading"
        @get-catalogue-item="getCatalogueItem"
      />
    </gl-spin>
  </gl-modal>
</template>
<script setup lang="ts">
import { ChartTree } from '@mysteel-standard/components-business'
import { MsTabs } from '@mysteel-standard/components'
import { enumToArray } from '@mysteel-standard/utils'
import { TabList, TabItem } from '../types/interface'

interface Props {
  visible: boolean | any
  title: string | any
  tabItem: TabItem | any
  menuKey: number | any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'update:visible', val: boolean): void
  (e: 'handle-submit', item: any): void
}
const emits = defineEmits<Emits>()

const collectVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})

const tabData = ref(enumToArray(TabList))
const tabIndex = ref(TabList['公司图表库'])
const treeRef = ref()
const state = reactive({
  loading: false,
  selectItem: null,
  selectTabItem: tabData.value[0]
})
const { loading, selectTabItem } = toRefs(state)

watch(
  () => props.visible,
  (val) => {
    if (val) {
      let label = ''
      if (props.tabItem.value === 1) {
        label = '公司图表库'
        tabIndex.value = 1
        state.selectTabItem = props.tabItem
      } else if (props.tabItem.value === 2) {
        label = '我的图表库'
        tabIndex.value = 2
        state.selectTabItem = props.tabItem
      }
      let parent = [{ label: label, id: 0, isLeaf: false, children: [] }]
      nextTick(() => {
        treeRef.value && treeRef.value.getTree(parent)
      })
    }
  }
)
watch(
  () => props.menuKey,
  () => {
    state.selectTabItem = props.tabItem
  },
  { immediate: true }
)

const updateLoading = (flag: boolean) => {
  state.loading = flag
}

const getCatalogueItem = (item: any) => {
  state.selectItem = item
}
const handleSubmit = () => {
  emits('handle-submit', state.selectItem)
}

// 切换树
const tabClick = (e: { target: { value: number } }) => {
  const { value } = e.target
  state.selectTabItem = tabData.value.filter((item: TabItem) => item.value === value)[0]
  nextTick(() => {
    let label = ''
    if (value === 1) {
      label = '公司图表库'
    } else if (value === 2) {
      label = '我的图表库'
    }
    let parent = [{ label: label, id: 0, isLeaf: false, children: [] }]
    treeRef.value.getTree(parent)
  })
}
</script>
<style lang="scss" scoped>
.tab-group {
  margin: 0 auto 16px;
  width: 208px;
}
</style>
