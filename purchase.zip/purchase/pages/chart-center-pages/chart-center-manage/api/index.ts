import request from '@mysteel-standard/apis'
const apiMap = {
  // 图表列表
  queryChartsCatalogueList: {
    method: 'post',
    url: '/database/chart/list'
  },
  // 更新图表
  updateChart: {
    method: 'post',
    url: '/database/chart/updateChart'
  },
  // 删除图表
  deleteChart: {
    method: 'post',
    url: '/database/chart/delete'
  },
  // 删除图表
  copyChart: {
    method: 'post',
    url: '/database/chart/copy'
  },
  // 收藏图表
  collectChart: {
    method: 'post',
    url: '/database/chart/collect'
  },
  // 收藏图表
  addCompanyChart: {
    method: 'post',
    url: '/database/apply/add'
  },
  // 收藏图表
  moveChart: {
    method: 'post',
    url: '/database/chart/move'
  },
  // 查询图表
  queryChartInfo: {
    method: 'post',
    url: '/database/chart/info'
  },
  /* 获取多个指标数据曲线图 */
  diagramMultiData: {
    method: 'post',
    url: '/database/data/diagramMultiData'
  },
  // 自由表或序列表计算公式
  getTableIndexData: {
    method: 'post',
    url: '/database/data/getIndexData'
  },
  /* 获取单个指标的季节性分析 */
  diagramGroupYearData: {
    method: 'post',
    url: '/database/data/diagramGroupYearData'
  },
}
export default request(apiMap)
