export { default as ChartCenter } from './index.vue'
