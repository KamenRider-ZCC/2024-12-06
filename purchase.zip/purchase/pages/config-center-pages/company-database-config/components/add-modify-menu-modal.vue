<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 13:37:22
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-30 18:43:21
 * @Description: 
-->
<template>
  <form-modal
    :title="visibleTitle"
    :confirmLoading="loading"
    v-model:visible="visible"
    :formItems="formItems"
    v-model:formParams="addModifyForm"
    @ok="handleOk"
  ></form-modal>
</template>
<script setup lang="ts">
import { FormModal } from '@mysteel-standard/components'
import { MenuFormType } from '../types/interface'
import { computed } from 'vue'
interface Props {
  addModifyMenuVisible: boolean
  visibleTitle: string
  addModifyMenuForm: MenuFormType
  loading: boolean
}
interface Emits {
  (e: 'update:addModifyMenuVisible', val: boolean): void
  (e: 'sure-add-modify-menu', form: MenuFormType): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  addModifyMenuVisible: false,
  visibleTitle: ''
})

const addModifyForm = computed(() => props.addModifyMenuForm)
const visible = computed({
  get() {
    return props.addModifyMenuVisible
  },
  set(val: boolean) {
    emits('update:addModifyMenuVisible', val)
  }
})
const formItems = [
  {
    label: '目录名称',
    name: 'label',
    rules: [
      { required: true, message: '请输入目录名称' },
      { max: 25, message: '长度限制为25个字符', trigger: 'blur' }
    ]
  }
]
// 确认新建、重命名目录
const handleOk = () => {
  emits('sure-add-modify-menu', addModifyForm.value)
}
</script>
