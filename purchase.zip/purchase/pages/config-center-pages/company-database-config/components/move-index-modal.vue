<!--
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-17 14:11:34
 * @Description: 
-->
<template>
  <gl-modal
    v-model:visible="isVisible"
    centered
    :title="title"
    @ok="handleOk"
    @cancel="handleCancel"
    :destroyOnClose="true"
    :confirmLoading="loading"
  >
    <gl-spin :spinning="companyTreeLoading">
      <MsTree
        v-model:selectedKeys="companySelectedKeys"
        v-model:expandedKeys="companyExpandedKeys"
        autoExpandParent
        block-node
        :tree-data="companyData"
        :fieldNames="companyFields"
        @select="moveNodeClick"
        @expand="treeExpand"
      />
    </gl-spin>
  </gl-modal>
</template>
<script setup lang="ts">
import { ref, computed } from 'vue'
import { MsTree } from '@mysteel-standard/components'
import useTree from '../composables/use-tree'
import { message } from 'gl-design-vue'
interface Props {
  visible: boolean
  title: string
  loading: boolean
}
const props = defineProps<Props>()

interface Emits {
  (e: 'update:visible', val: boolean): void
  (e: 'sure-move-index', val: any): void
}
const emits = defineEmits<Emits>()

const isVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})
const selectData = ref({})
const handleOk = () => {
  if (!selectData.value) {
    message.warning('请选择有效的节点')
    return
  }
  if (!selectData.value.isEnd && selectData.value.label !== '未分配指标') {
    message.warning('请选择最底层目录')
    return
  }
  emits('sure-move-index', selectData.value)
}

const {
  treeData: companyData,
  replaceFields: companyFields,
  selectedTreeKeys: companySelectedKeys,
  expandedKeys: companyExpandedKeys,
  treeLoading: companyTreeLoading,
  getTreeData: getCompanyTree,
  nodeExpand,
  treeExpand
} = useTree(emits, 1) //1 启用
const moveNodeClick = (selectedKeys: number[], { node }: { node: any }) => {
  selectData.value = node
  if (!node.isEnd) {
    nodeExpand(node)
  }
}
const handleCancel = () => {
  isVisible.value = false
}
defineExpose({
  getCompanyTree
})
</script>
<style lang="scss" scoped>
:deep(.gl-spin-container) {
  height: 400px;
  overflow: auto;
}
</style>
