<!--
 * @Autor: zhouwanwan
 * @Date: 2023-08-18 11:17:44
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-19 17:13:42
 * @Description: 
-->
<template>
  <gl-row type="flex" justify="space-between">
    <gl-space :size="8">
      <gl-button
        v-if="checkedNodeName === '未分配指标'"
        type="primary"
        @click="handleRefreshIndex"
        :disabled="refreshFlag"
        :loading="refreshFlag"
      >
        <icon name="icon-reset" v-show="!refreshFlag" /> 刷新编码</gl-button
      >
      <gl-button
        v-if="checkedNodeName !== '未分配指标'"
        type="primary"
        @click="handleDelete"
        :disabled="!selectedKeys.length || !tableData?.length"
      >
        <icon name="icon-del" /> 批量删除</gl-button
      >
      <gl-button
        type="primary"
        @click="handleMove"
        :disabled="!selectedKeys.length || !tableData?.length"
      >
        <icon name="icon-drag" /> 移动指标</gl-button
      >
      <gl-button
        type="primary"
        @click="handleExport"
        :disabled="!selectedKeys.length || !tableData?.length"
      >
        <icon name="icon-export_index_outlined" /> 导出指标
      </gl-button>
    </gl-space>
    <gl-space v-if="checkedNodeName !== '未分配指标'">
      <gl-button type="primary" @click="handleAdd" :disabled="!curMenuData?.isEnd">
        <icon name="icon-add" /> 新增指标
      </gl-button>
    </gl-space>
  </gl-row>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { computed } from 'vue'
import { message } from 'gl-design-vue'
import api from '../api'
interface Emits {
  (e: 'handle-add'): void
  (e: 'handle-move'): void
  (e: 'handle-export'): void
  (e: 'handle-delete'): void
  (e: 'handle-refresh'): void
}
interface Props {
  curMenuData: any
  selections: any
  selectedRows: any
  tableData: any
  checkedNodeName: string
  refreshFlag: boolean
}
const props = defineProps<Props>()
const emits = defineEmits<Emits>()
const selectedKeys = computed(() => props.selections)
const handleAdd = () => {
  emits('handle-add')
}
const handleMove = () => {
  emits('handle-move')
}
const handleExport = () => {
  emits('handle-export', selectedKeys.value)
}
const handleDelete = () => {
  const index = props.selectedRows.findIndex((item: any) => item.indexType !== '2')
  if (index > -1) {
    message.warning('系统指标无法删除')
    return
  }
  const params = {
    ids: props.selections,
    indexNames: props.selectedRows.map((item: any) => item.indexName),
    type: 2
  }
  emits('handle-delete', params)
}

const handleRefreshIndex = async () => {
  emits('handle-refresh')
}
</script>
<style lang="scss" scoped></style>
