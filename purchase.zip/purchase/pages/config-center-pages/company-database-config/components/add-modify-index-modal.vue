<!--
 * @Autor: zhouwanwan
 * @Date: 2023-08-30 10:16:32
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-19 17:09:38
 * @Description:新增、编辑指标 
-->
<template>
  <gl-modal
    v-model:visible="isVisible"
    :confirmLoading="loading"
    centered
    :title="title"
    @ok="handleOk"
    :width="600"
    @cancel="handleCancel"
    :destroyOnClose="true"
  >
    <div class="index-tabs">
      <ms-tabs class="tab" v-if="!isEdit" v-model:value="tabIndex" :tabs="tabData" />
    </div>
    <div class="tab-content">
      <div v-show="tabIndex === 1" class="add-index-form">
        <ms-form v-model:formParams="indexForm" :formItems="formItems" ref="msFormRef" />
      </div>
      <div class="batch-add-index" v-show="tabIndex === 2">
        <div class="paragraph">
          <div class="paragraph-div">
            请按照指标导入模板的格式填入需要新增的指标<a
              href="/database/api/database/config/downloadTemplate"
              >点击下载</a
            >
            《指标新增模板》
          </div>
          <div class="tips tips-top">
            <p style="font-weight: bold">注意事项：</p>
            <p>1.模板中的表头名称不能更改，表头行不能删除，已有内容不能删除</p>
            <p>2.其中标“<span style="color: red">*</span>”为必填项，必须填写</p>
          </div>
        </div>
        <div class="index-file">
          <gl-form :model="formIndexFile" ref="formIndexFileRef">
            <gl-form-item name="file" label="附件" :rules="fileForRule">
              <gl-upload
                :beforeUpload="onBeforeUpload"
                :customRequest="customRequest"
                :showUploadList="false"
                withCredentials
              >
                <gl-row type="flex" class="upload-btn">
                  <gl-button>
                    <upload-outlined />
                    点击上传
                  </gl-button>
                  <div class="tips">支持格式：xls、xlsx格式</div>
                </gl-row>
              </gl-upload>
              <div class="upload-file" v-if="formIndexFile.file.length">
                <div class="upload-file-header">附件</div>
                <div class="upload-file-item">
                  <div class="upload-file-name">
                    <icon name="icon-link-icon" />
                    <p>{{ formIndexFile.file[0].name }}</p>
                  </div>
                  <gl-button @click="handleRemove" type="link" size="small"> 删除 </gl-button>
                </div>
              </div>
            </gl-form-item>
          </gl-form>
        </div>
      </div>
    </div>
  </gl-modal>
</template>
<script setup lang="ts">
import { ref, computed } from 'vue'
import { MsTabs, MsForm, Icon } from '@mysteel-standard/components'
import { UploadOutlined } from '@ant-design/icons-vue'
import useDownloadIndex from '../composables/use-download-index'
interface Props {
  visible: boolean
  title: string
  isEdit: boolean
  form: any
  loading: boolean
}
const props = defineProps<Props>()
const indexForm = computed(() => props.form)
interface Emits {
  (e: 'update:visible', val: boolean): void
  (e: 'sure-add-index', val: any): void
  (e: 'sure-batch-add-index', val: any): void
}
const emits = defineEmits<Emits>()

const isVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})

const tabData = [
  {
    label: '指标新增',
    value: 1
  },
  {
    label: '批量新增',
    value: 2
  }
]
const frequencyArr = ['日度', '周度', '旬度', '月度', '季度', '年度'].map((item) => {
  return {
    label: item,
    value: item
  }
})
const decimalPlacesArr = [
  {
    value: 0,
    label: '取整'
  },
  {
    value: -1,
    label: '不限制'
  },
  {
    value: 1,
    label: '保留1位'
  },
  {
    value: 2,
    label: '保留2位'
  },
  {
    value: 3,
    label: '保留3位'
  },
  {
    value: 4,
    label: '保留4位'
  }
]
const formItems = computed(() => {
  const data = [
    {
      label: '指标名称',
      name: 'oldIndexName',
      type: 'input',
      disabled: props.isEdit && indexForm.value.indexType === '3',
      rules: [
        { required: true, message: '请输入指标名称' },
        { max: 100, message: '长度限制为100个字符', trigger: 'blur' }
      ]
    },
    {
      label: '重新命名',
      name: 'indexName',
      disabled: !props.isEdit,
      type: 'input',
      rules: [{ max: 100, message: '长度限制为100个字符', trigger: 'blur' }]
    },
    {
      label: '指标单位',
      name: 'unit',
      type: 'input',
      disabled: props.isEdit && indexForm.value.indexType === '3',
      rules: [
        { required: true, message: '请输入指标单位' },
        { max: 25, message: '长度限制为25个字符', trigger: 'blur' }
      ]
    },
    {
      label: '指标频度',
      name: 'frequency',
      type: 'select-default',
      disabled: props.isEdit && indexForm.value.indexType === '3',
      options: frequencyArr,
      rules: [{ required: true }]
    },
    {
      label: '保留小数',
      name: 'decimalPlaces',
      type: 'select-default',
      options: decimalPlacesArr
    },
    {
      label: '数据来源',
      name: 'sourceName',
      disabled: props.isEdit && indexForm.value.indexType === '3',
      type: 'input',
      rules: [{ max: 25, message: '长度限制为25个字符', trigger: 'blur' }]
    }
  ]
  if (!props.isEdit || indexForm.value.indexType !== '3') {
    data.splice(1, 1)
    return data
  }
  return data
})

const tabIndex = ref(1)
const handleCancel = () => {
  emits('update:visible', false)
}

const { formIndexFile, fileForRule, onBeforeUpload, customRequest, handleRemove } =
  useDownloadIndex()

const msFormRef = ref()
const formIndexFileRef = ref()
const handleOk = () => {
  if (tabIndex.value === 1) {
    msFormRef.value
      .validate()
      .then(async () => {
        emits('sure-add-index', indexForm.value)
      })
      .catch(() => {
        return false
      })
  } else {
    formIndexFileRef.value
      .validate()
      .then(async () => {
        emits('sure-batch-add-index', formIndexFile.value.file[0])
      })
      .catch(() => {
        return false
      })
  }
}
</script>
<style scoped lang="scss">
.index-tabs {
  width: 50%;
  margin: 16px auto 36px;
}
.tab-content {
  height: 360px;
  overflow: auto;
  .add-index-form {
    :deep(.gl-form-item-label) {
      width: 100px;
    }
  }

  .batch-add-index {
    padding: 0px 46px;
    .upload-btn {
      align-items: center;
      .tips {
        margin-left: 10px;
      }
    }
    .paragraph {
      color: #333;
      margin-bottom: 30px;
      .title {
        margin-top: 10px;
      }
      .tips-top {
        color: #7f7f7f;
      }
      .tips {
        margin-top: 24px;
        line-height: 28px;
        overflow: hidden;
      }
    }
  }
}
.upload-file {
  border-radius: 2px;
  background: #f6faff;
  border: 1px solid #e8e8e8;
  margin-top: 16px;
  &-header {
    height: 32px;
    line-height: 32px;
    padding: 0 15px;
    color: #333;
    background: #e6f7ff;
  }
  &-name {
    color: #333;
    display: flex;
    align-items: center;
    .gl-btn {
      font-size: 12px;
    }
  }
  &-item {
    margin: 6px;
    display: flex;
    justify-content: space-between;
  }
}
</style>
