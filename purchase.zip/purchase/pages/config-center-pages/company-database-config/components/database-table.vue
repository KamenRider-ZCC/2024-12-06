<!--
 * @Autor: zhouwanwan
 * @Date: 2023-08-18 17:33:32
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-11-28 09:26:33
 * @Description: 
-->
<template>
  <ms-table
    class="database-table"
    ref="tableRef"
    :columns="columns"
    :loading="loading"
    row-key="id"
    :data="tableData"
    :height="636"
    @switch-change="handleSwitchChange"
    :customRow="handleRow"
    :scroll="{ x: '100%' }"
    :emptyText="curMenuData.isEnd ? '暂无数据' : '请选择左侧目录树的子节点，可展示数据'"
  >
    <template #priority="{ record, index }">
      <div class="input-edit-block">
        <gl-input-number
          v-if="record.showInput"
          :controls="false"
          style="width: 90px"
          v-model:value="record.priority"
          @click.native.stop
        />
        <span v-else>{{ record.priority }}</span>
        <icon
          v-show="record.showEdit"
          name="icon-edit"
          class="icon-edit"
          size="14"
          color="#023985"
          @click="editRow(record)"
        />
        <icon
          v-show="record.showInput"
          name="icon-comform_outlined"
          class="icon-comform"
          size="14"
          color="#023985"
          @click="saveEdit(record)"
        />
        <icon
          v-show="record.showInput"
          class="edit-icon"
          name="icon-unselect_outlined"
          size="14"
          color="#023985"
          @click="cancelEdit(record, index)"
        />
      </div>
    </template>
    <template #action="{ record }">
      <div class="operation-buttons">
        <gl-button type="text" @click.stop="handleEdit(record)"> 编辑 </gl-button>
        <gl-popconfirm
          v-if="tableData.length"
          title="是否删除该指标?"
          @confirm="handleDelete(record.id, record.indexName)"
        >
          <gl-button
            type="text"
            v-if="checkedNodeName !== '未分配指标' && record.indexType === '2'"
          >
            删除</gl-button
          >
        </gl-popconfirm>
      </div>
    </template>
  </ms-table>
</template>
<script setup lang="ts">
import { MsTable, Icon } from '@mysteel-standard/components'
import useTableSort from '../composables/use-table-sort'
import { computed, nextTick, onMounted } from 'vue'
import { message } from 'gl-design-vue'
interface Props {
  loading: boolean
  databaseTableData: any
  curMenuData: any
  oldConfigList: any
  checkedNodeName: string
}
const props = defineProps<Props>()
const tableData = computed(() => props.databaseTableData)
interface Emits {
  (e: 'modify', record: any): void
  (e: 'delete', params: { id: number; isConfirm: boolean }): void
  (e: 'switch-change', params: any): void
  (e: 'select-change', val: any): void
  (e: 'table-sort', val: any): void
  (e: 'change-priority', val: any): void
}
const emits = defineEmits<Emits>()

//列表
const columns = computed(() => {
  const data = [
    {
      title: '',
      dataIndex: 'drag',
      key: 'drag',
      align: 'center',
      width: 90
    },
    {
      title: '序号',
      dataIndex: 'priority',
      key: 'priority',
      slotName: 'priority',
      width: 100
    },
    {
      title: '指标名称',
      dataIndex: 'indexName',
      key: 'indexName',
      ellipsis: true,
      width: 220
    },
    {
      title: '单位',
      dataIndex: 'unit',
      key: 'unit'
    },
    {
      title: '频率',
      dataIndex: 'frequency',
      key: 'frequency'
    },
    {
      title: '来源',
      dataIndex: 'sourceName',
      key: 'sourceName'
    },
    {
      title: '分类',
      dataIndex: 'category',
      key: 'category'
    },
    {
      title: '指标编码',
      dataIndex: 'indexCode',
      key: 'indexCode',
      ellipsis: true
    },
    {
      title: '原始编码',
      dataIndex: 'oldIndexCode',
      key: 'oldIndexCode',
      ellipsis: true
    },
    {
      title: '最后修改人',
      dataIndex: 'updateUser',
      key: 'updateUser',
      ellipsis: true
    },
    {
      title: '最后修改时间',
      dataIndex: 'updateTime',
      key: 'updateTime',
      sorter: (a: any, b: any) => Date.parse(a.updateTime) - Date.parse(b.updateTime)
    },
    {
      title: '状态',
      dataIndex: 'isPublish',
      key: 'isPublish',
      type: 'switch',
      width: 130,
      sorter: (a: any, b: any) => a.isPublish - b.isPublish
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
      width: 120
    }
  ]
  if (props.checkedNodeName === '未分配指标') {
    data.splice(10, 1)
    return data
  } else {
    return data
  }
})
//状态切换
const handleSwitchChange = (record: any) => {
  const { id, isPublish } = record
  const params = {
    isEnable: isPublish,
    id,
    type: 2
  }
  emits('switch-change', params)
}
//删除
const handleDelete = (id: number, indexName: string) => {
  const params = { ids: [id], type: 2, indexNames: [indexName] }
  emits('delete', params, false)
}
//编辑
const handleEdit = (record: any) => {
  emits('modify', record)
}

const editRow = (record: any) => {
  record.showInput = true
  record.showEdit = false
}
const cancelEdit = (record: any, index: number) => {
  record.showInput = false
  record.priority = props.oldConfigList[index].priority
}
const handleRow = (record: any) => {
  return {
    onMouseenter: () => {
      if (!record.showInput) {
        record.showEdit = true
      }
    },
    onMouseleave: () => {
      record.showEdit = false
    }
  }
}
const saveEdit = (record: any) => {
  const regNumber = /^\+?[1-9][0-9]*$/
  if (regNumber.test(record.priority)) {
    const params = {
      id: Number(record.id),
      newPriority: record.priority,
      type: 2
    }
    emits('change-priority', params)
  } else {
    message.error('请输入大于0的整数')
  }
}
const { tableSortable, tableRef } = useTableSort('.database-table .gl-table-tbody', emits)

onMounted(() => {
  nextTick(() => {
    tableSortable(tableData.value)
  })
})
</script>
<style lang="scss" scoped>
.input-edit-block {
  .icon-edit,
  .icon-comform {
    margin: 0 5px;
  }
}
</style>
