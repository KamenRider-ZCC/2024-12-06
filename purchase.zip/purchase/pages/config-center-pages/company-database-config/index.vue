<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-19 09:35:57
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-11-29 15:40:37
 * @Description: 
-->
<template>
  <div class="company-database-config">
    <div class="company-database-directory">
      <div class="company-database-title">公司数据库目录</div>
      <div
        class="company-database-tree"
        ref="directoryRef"
        :style="{
          width: directoryWidth + 'px'
        }"
      >
        <company-tree @choose-node="getIndexList" />
      </div>
      <div id="resize-div" @mousedown="(e: any) => resizeEl(e, 'side')"></div>
    </div>

    <div class="company-database-content">
      <div class="search-container">
        <gl-space :size="0" direction="vertical">
          <Database-search-form
            @search="databaseSearch"
            :curMenuData="curMenuData"
            :frequencyOptions="frequencyOptions"
            :sourceOptions="sourceOptions"
            :categoryOptions="categoryOptions"
            ref="searchFormRef"
          />
          <top-button
            :curMenuData="curMenuData"
            :tableData="databaseTableData"
            :selections="tableSelectedKeys"
            :selectedRows="tableSelectedRows"
            :refreshFlag="refreshFlag"
            @handle-add="handleAdd"
            @handle-delete="handleDelete"
            @handle-move="handleMove"
            @handle-export="handleExport"
            @handle-refresh="handleRefresh"
            :checkedNodeName="checkedNodeName"
          />
        </gl-space>
      </div>
      <div class="table-container">
        <Database-table
          :loading="databaseTableLoading"
          :databaseTableData="databaseTableData"
          :curMenuData="curMenuData"
          :oldConfigList="oldConfigList"
          :key="curMenuData.id"
          @delete="handleDelete"
          @modify="handleModify"
          @switch-change="switchChange"
          @table-sort="databaseTableSort"
          @change-priority="changePriority"
          :checkedNodeName="checkedNodeName"
          :row-selection="{
            selectedRowKeys: tableSelectedKeys,
            onChange: onSelectChange
          }"
          :scroll="{ y: 560 }"
        />
      </div>
      <div class="pagination">
        <Pagination v-model:page="page" @page-change="handlePageChange" />
      </div>
    </div>
    <move-index-modal
      v-if="moveIndexVisible"
      v-model:visible="moveIndexVisible"
      :title="moveIndexTitle"
      ref="moveIndexRef"
      :loading="sureMoveLoading"
      @sure-move-index="sureMoveIndex"
    />
    <add-modify-index-modal
      v-if="addIndexVisible"
      :form="addModifyIndexForm"
      :loading="sureAddModifyLoading"
      v-model:visible="addIndexVisible"
      :isEdit="isEdit"
      :title="addIndexTitle"
      @sure-add-index="sureAddIndex"
      @sure-batch-add-index="sureBatchAddIndex"
    />
  </div>
</template>
<script setup lang="ts">
import { Pagination } from '@mysteel-standard/components'
import CompanyTree from './components/company-tree.vue'
import DatabaseSearchForm from './components/database-search-form.vue'
import TopButton from './components/top-button.vue'
import DatabaseTable from './components/database-table.vue'
import AddModifyIndexModal from './components/add-modify-index-modal.vue'
import MoveIndexModal from './components/move-index-modal.vue'
import useAddModifyIndex from './composables/use-add-modify-index'
import useDatabaseTable from './composables/use-database-table'
import useResize from './composables/use-resize'
const {
  moveIndexVisible,
  moveIndexTitle,
  curMenuData,
  moveIndexRef,
  databaseTableData,
  databaseTableLoading,
  sureMoveLoading,
  handleMove,
  handleExport,
  handleRefresh,
  refreshFlag,
  sureMoveIndex,
  getIndexList,
  databaseSearch,
  databaseTableSort,
  handleDelete,
  switchChange,
  onSelectChange,
  tableSelectedKeys,
  tableSelectedRows,
  changePriority,
  searchFormRef,
  oldConfigList,
  checkedNodeName,
  handlePageChange,
  page,
  categoryOptions
} = useDatabaseTable()
//新增编辑指标
const {
  addIndexVisible,
  addIndexTitle,
  isEdit,
  addModifyIndexForm,
  sureAddModifyLoading,
  handleAdd,
  handleModify,
  sureAddIndex,
  sureBatchAddIndex,
  frequencyOptions,
  sourceOptions
} = useAddModifyIndex(curMenuData, getIndexList)

//左侧宽度调整
const { directoryWidth, resizeEl, directoryRef } = useResize()
</script>
<style scoped lang="scss">
@import './style/index.scss';
</style>
