/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 16:12:30
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-15 13:22:15
 * @Description:
 */
import { message } from 'gl-design-vue'
import { Modal } from 'gl-design-vue'
import { createVNode } from 'vue'
import { ExclamationCircleOutlined } from '@ant-design/icons-vue'
import api from '../api/index'
import useAddModifyMenu from './use-add-modify-menu'
import { OperationMenuType } from '../types/interface'
import { ref } from 'vue'

export default (getTreeData: Function, emits: any) => {
  const addModifyMenuLoading = ref(false)
  //新增编辑目录
  const {
    addModifyMenuTitle,
    addModifyMenuForm,
    addModifyMenuVisible,
    sureAddModifyMenu,
    addModifyMenu
  } = useAddModifyMenu(getTreeData, addModifyMenuLoading)
  //删除目录
  const deleteMenu = (item: Object, data: any) => {
    Modal.confirm({
      title: '是否删除该目录？',
      icon: createVNode(ExclamationCircleOutlined),
      async onOk() {
        const params = {
          ids: [Number(data.id)],
          labels: [data.label],
          type: 1
        }
        const { err } = await api.deleteCatalog(params)
        if (!err) {
          message.success('删除成功')
          // 刷新树
          getTreeData()
        }
      }
    })
  }

  //启用禁用
  const handleEnable = async (item: Object, data: any) => {
    const isPublish = !data.isPublish
    const params = {
      type: 1, //	1:目录，2：指标
      isEnable: isPublish ? 1 : 0,
      id: Number(data.id)
    }
    const { err } = await api.enableCatalog(params)
    if (!err) {
      message.success(params.isEnable ? '启用成功！' : '停用成功！')
      // 刷新树
      getTreeData()
    }
  }
  const operationMenu = <OperationMenuType>{
    新增目录: addModifyMenu,
    编辑目录: addModifyMenu,
    删除目录: deleteMenu,
    全部启用: handleEnable,
    全部停用: handleEnable,
    启用目录: handleEnable,
    停用目录: handleEnable
  }
  const menuClick = (item: { label: string }, data: Object) => {
    operationMenu[item.label](item, data)
  }
  const treeMenu = [
    {
      label: '新增目录',
      condition: (data: { type: number }) => data.type === 1,
      disabled: (data: any): boolean => data.hasChildIndex,
      handle: menuClick
    },
    {
      label: '编辑目录',
      condition: (data: { id: number }): boolean => data.id !== 0,
      handle: menuClick
    },
    {
      label: '删除目录',
      condition: (data: { id: number }): boolean => data.id !== 0,
      handle: menuClick
    },
    {
      label: '全部启用',
      condition: (data: { isEnd: boolean; isPublish: number }): boolean =>
        !data.isEnd && !data.isPublish,
      handle: menuClick
    },
    {
      label: '全部停用',
      condition: (data: { isEnd: boolean; isPublish: number }): any =>
        !data.isEnd && data.isPublish,
      handle: menuClick
    },
    {
      label: '启用目录',
      condition: (data: { isEnd: boolean; isPublish: number }): boolean =>
        data.isEnd && !data.isPublish,
      handle: menuClick
    },
    {
      label: '停用目录',
      condition: (data: { isEnd: boolean; isPublish: number }): any => data.isEnd && data.isPublish,
      handle: menuClick
    }
  ]
  return {
    treeMenu,
    menuClick,
    //新增编辑目录
    addModifyMenuTitle,
    addModifyMenuForm,
    addModifyMenuVisible,
    sureAddModifyMenu,
    addModifyMenuLoading
  }
}
