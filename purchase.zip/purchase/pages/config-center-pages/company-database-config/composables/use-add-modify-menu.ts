/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 11:23:44
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-15 13:18:35
 * @Description:
 */
import { MenuFormType, DataBaseTreeType } from '../types/interface'
import { message } from 'gl-design-vue'
import api from '../api/index'
import { useResetData } from '@mysteel-standard/hooks'
import { ref } from 'vue'
export default (getTreeData: Function, addModifyMenuLoading: any) => {
  const { dataState: addModifyMenuForm, resetDataState: resetAddModifyMenuForm } = useResetData({
    id: undefined,
    label: '',
    parentId: undefined
  })
  const addModifyMenuVisible = ref(false)
  const addModifyMenuTitle = ref('')
  const isEdit = ref(false)
  //新增编辑目录
  const sureAddModifyMenu = async (formData: MenuFormType) => {
    addModifyMenuLoading.value = true
    const params = {
      label: formData.label,
      parentId: formData.parentId,
      id: formData.id,
      isEnable: isEdit.value ? formData.isEnable : 1
    }
    const menuApi = isEdit.value ? api.updateCatalog : api.addCatalog
    const { err } = await menuApi(params)
    addModifyMenuLoading.value = false
    if (!err) {
      addModifyMenuVisible.value = false
      getTreeData()
      message.success(isEdit.value ? '编辑成功！' : '新增成功！')
    }
  }
  // 新增编辑目录弹窗
  const addModifyMenu = (item: { label: string; id?: number }, data: DataBaseTreeType) => {
    addModifyMenuVisible.value = true
    addModifyMenuTitle.value = item.label
    addModify(item, data, 1)
  }
  const addModify = (
    item: { label: string; id?: number },
    data: DataBaseTreeType,
    type: number
  ) => {
    isEdit.value = item.label.includes('编辑') ? true : false
    let obj = {}
    resetAddModifyMenuForm()
    if (isEdit.value) {
      obj = {
        label: data.label,
        id: Number(data.id)
      }
    } else {
      obj = {
        parentId: Number(data.id),
        label: ''
      }
    }
    Object.assign(addModifyMenuForm, obj)
  }
  return {
    addModifyMenuTitle,
    addModifyMenuForm,
    addModifyMenuVisible,
    sureAddModifyMenu,
    addModifyMenu
  }
}
