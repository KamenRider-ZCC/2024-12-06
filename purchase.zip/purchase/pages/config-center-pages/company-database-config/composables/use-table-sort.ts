/*
 * @Autor: zhouwanwan
 * @Date: 2023-08-31 11:17:49
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-11 14:12:47
 * @Description:
 */
//拖拽排序
import Sortable from 'sortablejs'
import { ref } from 'vue'
export default (dom: string, emits?: any) => {
  const tableRef = ref()
  const tableSortable = (tableData: any) => {
    if (tableRef.value) {
      const tbody = document.querySelector(dom)
      // console.log('tbody', tbody)
      Sortable.create(tbody, {
        animation: 60,
        handle: '.move-icon',
        onEnd: ({ newIndex, oldIndex }: { newIndex: number; oldIndex: number }) => {
          newIndex--
          oldIndex--
          //调接口：配置列表拖拽
          // console.log('oldIndex', oldIndex, newIndex, tableData)
          const params = {
            id: Number(tableData[oldIndex].id),
            newPriority: Number(tableData[newIndex].priority)
          }
          emits('table-sort', params)
        }
      })
    }
  }
  return {
    tableSortable,
    tableRef
  }
}
