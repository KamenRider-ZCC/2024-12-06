/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-26 19:22:49
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-12 09:08:11
 * @Description:
 */
export default (dataToolsForm?: any, dataTableHeight?: Ref) => {
  const directoryWidth = ref(230)
  const indexHeight = ref(276)
  const dataTableRef = ref()
  const resizeEl = (e: { target: { nodeName: string } }, type: string) => {
    if (type === 'side' && e.target.nodeName === 'svg') return
    document.onmousemove = (e) => mouseMove(e, type)
    document.onmouseup = () => {
      document.onmousemove = null
      document.onmouseup = null
    }
  }
  const mouseMove = (e: { clientX: number; clientY: number }, type: string) => {
    const ev = e || window.event
    if (type === 'side') {
      directoryWidth.value = ev.clientX - 16
      if (directoryWidth.value > 460) {
        directoryWidth.value = 460
      } else if (directoryWidth.value < 230) {
        directoryWidth.value = 230
      }
    } else {
      indexHeight.value = ev.clientY - 265
      const statisticalTableHeight = dataToolsForm.statistical ? 160 : 0
      if (dataTableHeight) {
        dataTableHeight.value = dataTableRef.value?.clientHeight - statisticalTableHeight
      }
    }
  }
  const isExpand = ref(true)
  const directoryRef = ref()
  const expandSide = () => {
    isExpand.value = !isExpand.value
    if (isExpand.value) {
      directoryWidth.value = 230
      directoryRef.value.style.display = 'block'
    } else {
      directoryWidth.value = 0
      directoryRef.value.style.display = 'none'
    }
  }
  return {
    directoryWidth,
    resizeEl,
    isExpand,
    expandSide,
    directoryRef,
    indexHeight,
    dataTableRef
  }
}
