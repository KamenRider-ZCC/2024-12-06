/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 16:23:57
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-08 09:01:01
 * @Description:
 */
import api from '../api/index'
import { message } from 'gl-design-vue'
export default (getTreeData: Function, treeLoading: Ref) => {
  // dropPosition -1是移动到和他平级在他上面    1是移动到和他平级在他下面  0是移动到他下面作为他子集
  const handleDrop = async (info: any) => {
    const { node, dragNode, dropPosition } = info
    const dragKey = dragNode.key
    const dropPosArray = node.pos.split('-')
    const dropPos = dropPosition - Number(dropPosArray[dropPosArray.length - 1])
    let sort: any = ''
    let targetId: any = undefined
    // 0是移动到他下面作为他子集
    if (dropPos === 0) {
      console.log('0是移动到他下面作为他子集', node.id, dragNode.pid)
      targetId = Number(node.id)
      if (node.children && node.children.length) {
        sort = node.children[0].priority - 1
      }
    }
    // 1是移动到和他平级在他下面
    if (dropPos === 1) {
      console.log('1是移动到和他平级在他下面', node.id, dragNode.pid)
      targetId = Number(node.pid)
      sort = node.priority + 1
    }
    //-1是移动到和他平级在他上面
    if (dropPos === -1) {
      console.log('是移动到和他平级在他上面', node.id, dragNode.pid)
      targetId = Number(node.pid)
      sort = node.priority - 1
    }
    const params = {
      id: Number(dragKey),
      newPid: targetId,
      newPriority: sort,
      type: 1 //1 框架 2指标
    }
    treeLoading.value = true
    const { err } = await api.dragCatalog(params)
    treeLoading.value = false
    if (!err) {
      getTreeData()
      message.success('拖拽成功')
    }
  }
  return {
    handleDrop
  }
}
