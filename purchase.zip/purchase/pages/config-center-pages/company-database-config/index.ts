/*
 * @Autor: zhouwanwan
 * @Date: 2023-08-29 17:15:05
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-29 17:15:25
 * @Description:
 */
export { default as CompanyDatabaseConfig } from './index.vue'
