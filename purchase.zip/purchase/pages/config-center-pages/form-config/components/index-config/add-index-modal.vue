<template>
  <gl-modal
    v-model:visible="isVisible"
    :confirmLoading="loading"
    centered
    :title="title"
    @ok="handleOk"
    :width="1300"
    @cancel="handleCancel"
    :destroyOnClose="true"
  >
    <div class="database-config">
      <div class="data-tree">
        <company-tree ref="companyTreeRef" @choose-node="getIndexTableData" />
      </div>
      <div class="data-content">
        <div class="search-container">
          <index-search-form @search="indexSearch" ref="searchFormRef" />
        </div>
        <div class="table-container">
          <!-- {{ tableSelectedKeys }} -->
          <index-table
            :loading="indexTableLoading"
            :data="indexTableData"
            :rowClassName="getRowClassName"
            :row-key="getRowKey"
            :height="389"
            :row-selection="{
              selectedRowKeys: tableSelectedKeys,
              onChange: onSelectChange,
              onSelect: handleSelect,
              getCheckboxProps: setCheckbox
            }"
          />
        </div>
        <div class="pagination" v-if="indexPage.total">
          <Pagination v-model:page="indexPage" @page-change="indexPageChange" />
        </div>
      </div>
    </div>
  </gl-modal>
</template>
<script setup lang="ts">
import { Pagination } from '@mysteel-standard/components'
import CompanyTree from './company-tree.vue'
import IndexTable from './index-table.vue'
import IndexSearchForm from './index-search-form.vue'
import { ref, computed, nextTick, reactive } from 'vue'
import api from '../../api/index'
import { useTableData } from '@mysteel-standard/hooks'
interface Props {
  visible: boolean
  title: string
  loading: boolean
}
const props = defineProps<Props>()
interface Emits {
  (e: 'update:visible', val: boolean): void
  (e: 'sure-add-index', val: any): void
}
const emits = defineEmits<Emits>()

const isVisible = computed({
  get() {
    getTreeData()
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})
const searchFormRef = ref()
const curMenuId = ref({})
const query = reactive({})
//表格复用逻辑
const {
  tableData: indexTableData,
  tableLoading: indexTableLoading,
  page: indexPage
} = useTableData({
  tableApi: api.searchIndexInfo,
  isInit: false
})
const companyTreeRef = ref()
const tableSelection = ref([])
const tableSelectedKeys = ref([])
const getTreeData = () => {
  nextTick(() => {
    companyTreeRef.value.getCompanyTree()
  })
}
const getRowKey = (record: any) => {
  return record.indexCode
}
const onSelectChange = (selectedRowKeys: [], selectedRows: any[]) => {
  tableSelection.value = [...tableSelection.value, ...selectedRows]
  tableSelectedKeys.value = [...new Set([...tableSelectedKeys.value, ...selectedRowKeys])]
}
const handleSelect = (record: any, selected: boolean) => {
  if (!selected) {
    tableSelectedKeys.value = tableSelectedKeys.value.filter(
      (item: any) => record.indexCode !== item
    )
    tableSelection.value = tableSelection.value.filter(
      (item: any) => record.indexCode !== item.indexCode
    )
  }
}
const resetPage = () => {
  indexPage.pageNum = 1
}
//目录点击获取指标
const getIndexTableData = async (id: any) => {
  searchFormRef.value?.queryReset()
  curMenuId.value.id = id
  resetPage()
  const params = {
    parentId: id,
    type: 2,
    isCustomIndex: true
  }
  indexTableLoading.value = true
  indexTableData.length = 0
  const { err, res } = await api.getDatabaseList(params)
  indexTableLoading.value = false
  if (!err && res) {
    const { data } = res
    const filterData =
      data &&
      data.list?.length &&
      data.list.map((item: any) => {
        const obj = {
          ...item,
          indexCode: item.code,
          indexName: item.label
        }
        return obj
      })
    Object.assign(indexTableData, filterData || [])
    indexPage.total = data?.total || 0
  }
}

//搜索
const databaseSearch = async (form?: any) => {
  indexTableLoading.value = true
  const params = {
    parentId: Number(curMenuId.value.id),
    ...form,
    pageSize: indexPage.pageSize,
    pageNum: indexPage.pageNum
  }
  const { err, res } = await api.searchIndexInfo(params)
  indexTableLoading.value = false
  if (!err && res) {
    indexTableData.length = 0
    const { data } = res
    if (data?.list?.length) {
      const { list } = data
      indexTableData.push(...list)
    }
  }
}

const indexSearch = (form: any) => {
  resetPage()
  Object.assign(query, form)
  databaseSearch(form)
}
const indexPageChange = (val: { pageNum: number; pageSize: number }) => {
  indexPage.pageNum = val.pageNum
  indexPage.pageSize = val.pageSize
  databaseSearch(query)
}
const handleOk = () => {
  emits('sure-add-index', tableSelection)
}
const setCheckbox = (record: any) => ({
  disabled: Boolean(record?.formId)
})
const getRowClassName = (record: any) => {
  if (record.formId && record.formId > 0) {
    return 'row-disabled'
  }
  return ''
}
const handleCancel = () => {
  isVisible.value = false
}
</script>
<style lang="scss" scoped>
$table-layout-radius: 4px;
$pagination-height: 72px;
.database-config {
  display: flex;
  height: 550px;
  overflow: hidden;
  .data-tree {
    width: 250px;
    padding-right: 16px;
    overflow: auto;
    &::after {
      content: '';
      position: absolute;
      top: 55px;
      left: 266px;
      width: 1px;
      height: calc(100% - 108px);
      background: #e8e8e8;
    }
  }
  .data-content {
    padding-left: 16px;
    flex: 1;
    display: flex;
    flex-direction: column;
    background: #fff;
    border-radius: $table-layout-radius;
    .search-container {
      margin-bottom: 16px;
    }
    .table-container {
      flex: 1 1 auto;
      :deep(.operation-buttons) {
        margin-left: -10px;
        .gl-btn-text {
          padding: 4px 9px;
          &:hover {
            background: none;
          }
        }
      }
      :deep(.row-disabled) {
        .gl-table-cell {
          opacity: 0.5;
        }
      }
    }
    .pagination {
      height: $pagination-height;
      display: flex;
      align-items: center;
      justify-content: center;
    }
  }
}
</style>
