<!--
 * @Autor: zhouwanwan
 * @Date: 2023-09-01 15:04:24
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-09 06:40:02
 * @Description: 指标列表
-->
<template>
  <ms-table
    class="index-table"
    :columns="columns"
    :loading="loading"
    row-key="indexCode"
    :data="tableData"
  />
</template>
<script setup lang="ts">
import { MsTable } from '@mysteel-standard/components'
import { computed } from 'vue'
interface Props {
  data: any[]
  loading: boolean
}
const props = defineProps<Props>()
//列表
const columns = [
  {
    title: '序号',
    dataIndex: 'index',
    key: 'index',
    align: 'center',
    width: 80
  },
  {
    title: '指标编码',
    dataIndex: 'indexCode',
    key: 'indexCode',
    ellipsis: true
  },
  {
    title: '指标名称',
    dataIndex: 'indexName',
    key: 'indexName',
    ellipsis: true
  },
  {
    title: '所在表单',
    dataIndex: 'formName',
    key: 'formName',
    ellipsis: true,
    type: 'function',
    callback: (record: any) => {
      return record.formName || '-'
    }
  },

  {
    title: '填报人',
    dataIndex: 'submitUserName',
    key: 'submitUserName',
    type: 'function',
    ellipsis: true,
    callback: (record: any) => {
      return record.submitUserName || '-'
    }
  }
]
const tableData = computed(() => props.data)
</script>
<style lang="scss" scoped></style>
