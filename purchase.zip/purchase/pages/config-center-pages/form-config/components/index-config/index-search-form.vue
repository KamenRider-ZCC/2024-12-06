<!--
 * @Autor: zhouwanwan
 * @Date: 2023-09-04 08:17:50
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-08 23:23:05
 * @Description: 
-->
<template>
  <ms-form
    v-model:formParams="indexQuery"
    :formItems="formItems"
    layout="inline"
    labelAlign="left"
    ref="msFormRef"
    :label-col="labelCol"
  >
    <template #action>
      <gl-button type="primary" @click="indexSearch">
        <icon name="icon-search" />
        搜索
      </gl-button>
      <gl-button style="margin: 0 8px" @click="reset">
        <icon name="icon-reset" />
        重置
      </gl-button>
    </template>
  </ms-form>
</template>
<script setup lang="ts">
import { useResetData } from '@mysteel-standard/hooks'
import { Icon, MsForm } from '@mysteel-standard/components'
const formOptions = [
  { label: '全部', value: -1 },
  {
    label: '未绑定表单',
    value: 0
  },
  {
    label: '已绑定表单',
    value: 1
  }
]
const formItems = [
  {
    label: '指标搜索',
    name: 'keywords',
    type: 'input',
    placeholder: '指标名称或编码',
    style: { width: '200px' }
  },
  {
    label: '所在表单',
    name: 'formBanded',
    type: 'select-default',
    style: { width: '200px' },
    options: formOptions
  },
  {
    label: '',
    name: '',
    slotName: 'action'
  }
]
const { dataState: indexQuery, resetDataState: queryReset } = useResetData({
  formBanded: -1,
  keywords: undefined
})

interface Emits {
  (e: 'search', query: any): void
}
const emits = defineEmits<Emits>()
const labelCol = { style: { width: 'auto' } }
const indexSearch = () => {
  const params = {
    formBanded: indexQuery.formBanded === -1 ? undefined : indexQuery.formBanded,
    keywords: indexQuery.keywords
  }
  emits('search', params)
}
const reset = () => {
  queryReset()
  indexSearch()
}
defineExpose({ queryReset })
</script>
