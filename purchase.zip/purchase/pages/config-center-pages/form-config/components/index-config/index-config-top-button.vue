<!--
 * @Autor: zhouwanwan
 * @Date: 2023-09-01 10:37:41
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-11 15:03:42
 * @Description: 指标表格操作按钮
-->
<template>
  <gl-space :size="8">
    <gl-button type="primary" @click="handleAdd"> <icon name="icon-add" /> 批量添加 </gl-button>
    <gl-button
      type="primary"
      @click="handleRemove"
      :disabled="!formConfigTableData.length || !tableSelectedKeys?.length"
    >
      <icon name="icon-unselect_outlined" /> 批量移除
    </gl-button>
  </gl-space>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
interface Props {
  tableSelectedKeys: any
  formConfigTableData: any
}
interface Emits {
  (e: 'add-index'): void
  (e: 'remove-index'): void
}
const props = defineProps<Props>()
const emits = defineEmits<Emits>()
const handleAdd = () => {
  emits('add-index')
}
const handleRemove = () => {
  emits('remove-index')
}
</script>
<style lang="scss" scoped></style>
