export { default as FormConfig } from './index.vue'
