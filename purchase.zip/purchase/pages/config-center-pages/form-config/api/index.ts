/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-22 10:42:19
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-04 16:17:45
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap: object = {
  getFormConfigList: {
    method: 'post',
    url: '/datafilling/config/list'
  },
  //查询框架子节点
  getDatabaseList: {
    method: 'post',
    url: '/database/api/database/config/getFrameworkChildren'
  },
  // 新增接口
  addFormConfig: {
    method: 'post',
    url: '/datafilling/config/save'
  },
  //详情
  getFormConfigDetail: {
    method: 'post',
    url: '/datafilling/config/detail'
  },
  //编辑
  updateFormConfig: {
    method: 'post',
    url: '/datafilling/config/edit'
  },
  //删除
  deleteFormConfig: {
    method: 'post',
    url: '/datafilling/config/delete'
  },
  // 启用禁用
  enableFormConfig: {
    method: 'post',
    url: '/datafilling/config/enable'
  },
  //复制
  copyFormConfig: {
    method: 'post',
    url: '/datafilling/config/copy'
  },
  // 审批流下拉
  getProcesses: {
    method: 'get',
    url: '/datafilling/config/queryProcList'
  },
  // 分类下拉查询接口
  typeList: {
    method: 'get',
    url: '/datafilling/typeConfig/config/typeList'
  },
  //公司数据库树
  getDatabaseTree: {
    method: 'get',
    url: '/database/api/database/config/getFrameworkTree'
  },
  getCatalogNode: {
    method: 'post',
    url: '/database/datacatalog/getCatalogNode'
  },
  //指标是否使用
  checkIndexCodeUsed: {
    method: 'post',
    url: '/datafilling/config/checkIndexCodeUsed'
  },
  // 获取用户树
  getAllUser: {
    method: 'post',
    url: '/framework/user/getAllUser'
  },
  // 关联指标查询
  getFormIndexConfig: {
    method: 'get',
    url: '/datafilling/config/getFormIndexConfig'
  },
  // 搜索框架指标
  searchIndexInfo: {
    method: 'post',
    url: '/database/api/database/config/searchIndexInfo'
  }
}

export default request(apiMap)
