/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-26 08:42:28
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-01 14:02:03
 * @Description:
 */
/// <reference types="vite/client" />
declare module '*.vue' {
  import { defineComponent } from 'vue'
  const Component: ReturnType<typeof defineComponent>
  export default Component
}
declare module 'gl-design-vue'
declare module '@mysteel-standard/components'
declare module '@mysteel-standard/hooks'
declare module 'vue'
declare module 'lodash-es'
