<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-22 09:37:30
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-08-09 15:21:03
 * @Description: 分类管理
-->
<template>
  <div class="classification-config">
    <div class="search-container">
      <div class="search-form">
        <search-form @search="handleSearch" />
      </div>
      <div class="table-btn-right">
        <top-button @add-classification="showModal('新建分类', null)" />
      </div>
    </div>
    <div class="table-container">
      <classification-table
        :loading="tableLoading"
        :tableData="tableData"
        @switch-change="switchChange"
        @delete="handleDelete"
        @modify-classification="(val: any) => showModal('编辑分类', val)"
        @changeSort="changeSort"
      />
    </div>
    <div class="pagination">
      <Pagination
        v-model:page="page"
        @page-change="handlePageChange"
        v-show="tableData.length > 0"
      />
    </div>
    <!-- 新建分类 -->
    <form-modal
      v-if="modalVisible"
      :loading="modalLoading"
      :title="modalTitle"
      v-model:visible="modalVisible"
      :formItems="formItems"
      v-model:formParams="formState"
      @ok="submit"
    ></form-modal>
  </div>
</template>
<script setup lang="ts">
import { Pagination, FormModal } from '@mysteel-standard/components'
import { useTableData } from '@mysteel-standard/hooks'
import api from './api/index'
import SearchForm from './components/search-form.vue'
import TopButton from './components/top-button.vue'
import ClassificationTable from './components/classification-table.vue'
import useAddModifyModal from './composables/use-add-modify-modal'
import { message } from 'gl-design-vue'
const {
  getList,
  handlePageChange,
  handleSearch,
  tableData,
  tableLoading,
  page,
  switchChange,
  handleDelete
} = useTableData({
  tableApi: api.getListByPage,
  switchApi: api.enable,
  deleteApi: api.delete
})

const changeSort = async (params: { id: number; companySort: number }) => {
  const { res, err } = await api.changeCompanySort(params)
  if (res && !err) {
    message.success(res.message)
    getList()
  }
}

//新增编辑
const { modalVisible, modalTitle, submit, modalLoading, formItems, formState, showModal } =
  useAddModifyModal(getList)
</script>

<style lang="scss" scoped>
@import './style/index.scss';
</style>
