/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-22 09:37:01
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-22 09:40:11
 * @Description:
 */
export { default as ClassificationConfig } from './index.vue'
