<template>
  <ms-table
    :columns="columns"
    :loading="loading"
    :data="tableData"
    @switch-change="handleSwitchChange"
    class="classification-table"
    row-key="id"
  >
    <template #type="{ record }">
      <div>
        {{ record.type === 1 ? '数据填报' : record.type === 2 ? '研报目录' : '研报分类' }}
      </div>
    </template>
    <template #action="{ record }">
      <div class="operation-buttons">
        <gl-button type="text" @click.stop="handleEdit(record)">编辑</gl-button>
        <gl-popconfirm v-if="tableData.length" @confirm="handleDelete(record.id, record.name)">
          <template #title>
            <p style="font-weight: bold">确定删除吗?</p>
          </template>
          <gl-button type="text">删除</gl-button>
        </gl-popconfirm>
      </div>
    </template>
  </ms-table>
</template>
<script setup lang="ts">
import { MsTable } from '@mysteel-standard/components'
interface Props {
  tableData: any
  loading: boolean
}

interface Emits {
  (e: 'modify-classification', val: any): void
  (e: 'switch-change', val: { id: number; isEnable: number }): void
  (e: 'delete', val: { id: number }): void
}

defineProps<Props>()
const emits = defineEmits<Emits>()

//列表
const columns = [
  {
    title: '序号',
    dataIndex: 'index',
    key: 'index',
    align: 'center',
    width: 100
  },
  {
    title: '分类名称',
    dataIndex: 'name',
    key: 'name',
    width: 520
  },
  {
    title: '应用模块',
    dataIndex: 'type',
    key: 'type',
    slotName: 'type'
  },
  {
    title: '最后修改人',
    dataIndex: 'updateName',
    key: 'updateTime'
  },
  {
    title: '最后修改时间',
    dataIndex: 'updateTime',
    key: 'updateTime',
    sorter: (a: any, b: any) => Date.parse(a.updateTime) - Date.parse(b.updateTime)
  },
  {
    title: '状态',
    dataIndex: 'isEnable',
    key: 'isEnable',
    type: 'switch',
    sorter: (a: any, b: any) => a.isEnable - b.isEnable
  },
  {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    width: 220
  }
]

//编辑
const handleEdit = (val: any) => {
  emits('modify-classification', val)
}

//状态切换
const handleSwitchChange = (record: any) => {
  const { id, isEnable } = record
  const params = {
    isEnable,
    id
  }
  emits('switch-change', params)
}
//删除
const handleDelete = (id: number, name: string) => {
  const params = { id, name }
  emits('delete', params)
}
</script>
<style lang="scss" scoped>
.move-icon {
  cursor: pointer;
}
</style>
