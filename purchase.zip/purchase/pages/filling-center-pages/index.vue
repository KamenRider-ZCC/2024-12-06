<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-07-05 16:49:05
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-17 10:24:59
 * @Description: 
-->

<template>
  <page-layout class="data-fill-layout" />
</template>
<script setup lang="ts">
import { PageLayout } from '@mysteel-standard/components'
</script>
<style lang="scss" scoped></style>
