<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-23 14:30:43
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-12 14:34:28
 * @Description: 新增编辑表单
-->
<template>
  <gl-modal
    v-model:visible="visible"
    :closable="false"
    :footer="null"
    :centered="true"
    :width="1600"
  >
    <div class="modal-container">
      <div class="search-container">
        <div class="search-form">
          <gl-form ref="formRef" layout="inline" :model="formParams">
            <gl-form-item label="指标编码:">
              <gl-input
                v-model:value="formParams.indexCode"
                placeholder="请输入指标编码"
              ></gl-input>
            </gl-form-item>
            <gl-form-item label="指标名称:">
              <gl-input
                v-model:value="formParams.indexName"
                placeholder="请输入指标名称"
              ></gl-input>
            </gl-form-item>
            <gl-form-item label="指标频度:">
              <gl-select
                v-model:value="formParams.frequency"
                placeholder="请选择指标频度"
                style="width: 160px"
              >
                <gl-select-option v-for="item in frequencyArr" :key="item.id" :value="item.val">{{
                  item.name
                }}</gl-select-option>
              </gl-select>
            </gl-form-item>

            <gl-button type="primary" @click="search">
              <icon name="icon-search" />
              搜索
            </gl-button>
            <gl-button style="margin: 0 8px" @click="reset">
              <icon name="icon-reset" />
              重置
            </gl-button>
          </gl-form>
        </div>
      </div>
      <div class="btn-container">
        <gl-button type="primary" class="btn-item">
          <a :href="`/datafilling/form/downloadTemplate?configId=${configId}`" download>
            <icon name="icon-download" /> 模板下载</a
          >
        </gl-button>
        <gl-upload
          v-model:file-list="fileList"
          :action="action"
          :headers="headers"
          :max-count="1"
          :beforeUpload="onBeforeUpload"
          @change="handleChange"
          withCredentials
        >
          <gl-row type="flex" class="upload-btn">
            <gl-button type="primary" class="btn-item">
              <loading-outlined v-if="uploadLoading" />
              <icon name="icon-extract_outlined" v-else />
              批量导入
            </gl-button>
          </gl-row>
          <template #removeIcon><icon name="icon-del" /></template>
        </gl-upload>
        <gl-button type="primary" @click="submit" class="btn-item fr">
          <loading-outlined v-if="applyLoading || uploadLoading" />
          <icon name="icon-comform_outlined" v-else />

          提交数据
        </gl-button>
        <gl-button @click="toBack" class="btn-item fr">
          <icon name="icon-left_outlined" />
          返回表单
        </gl-button>
      </div>
      <div class="table-container">
        <gl-table
          :scroll="{ y: 520 }"
          :loading="tableLoading"
          :data-source="tableData"
          :columns="columns"
          :pagination="false"
          row-key="id"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'indexName'">
              <gl-tooltip>
                <template #title>{{ record.indexName }}</template>
                <div style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis">
                  {{ record.indexName }}
                </div>
              </gl-tooltip>
            </template>

            <template v-if="column.key === 'dataDate'">
              <span
                style="
                  position: absolute;
                  top:30%;
                  left: 66%;
                  pointer-events: auto;
                  transform: translateY(-50%)
                  z-index: 999;
                "
                v-if="record.frequency === '周度' && record.dataDate"
                >(w{{ getYearWeek(record.dataDate) }})</span
              >
              <gl-date-picker
                v-if="record.frequency === '日度'"
                v-model:value="record.dataDate"
                placeholder="选择日期"
                format="YYYY-MM-DD"
                style="width: 160px"
                valueFormat="YYYY-MM-DD"
                @change="(value: string) => formatChange(value, record)"
              >
              </gl-date-picker>
              <gl-date-picker
                v-if="record.frequency === '周度'"
                picker="week"
                placeholder="选择周"
                v-model:value="record.dataDate"
                style="width: 160px"
                valueFormat="YYYY-MM-DD"
                @change="(value: string) => formatChange(value, record)"
              >
              </gl-date-picker>
              <gl-date-picker
                v-if="record.frequency === '旬度'"
                v-model:value="record.dataDate"
                placeholder="选择旬"
                format="YYYY-MM-DD"
                valueFormat="YYYY-MM-DD"
                style="width: 160px"
                :disabledDate="disabledDate"
                @change="(value: string) => formatChange(value, record)"
              >
              </gl-date-picker>
              <gl-date-picker
                v-if="record.frequency === '月度'"
                v-model:value="record.dataDate"
                picker="month"
                placeholder="选择月"
                format="YYYY-MM-DD"
                valueFormat="YYYY-MM-DD"
                style="width: 160px"
                @change="(value: string) => formatChange(value, record)"
              >
              </gl-date-picker>
              <gl-date-picker
                v-if="record.frequency === '季度'"
                v-model:value="record.dataDate"
                picker="month"
                placeholder="选择季"
                format="YYYY-MM-DD"
                valueFormat="YYYY-MM-DD"
                style="width: 160px"
                @change="(value: string) => formatChange(value, record)"
              >
              </gl-date-picker>

              <gl-date-picker
                v-if="record.frequency === '年度'"
                v-model:value="record.dataDate"
                picker="year"
                placeholder="选择年"
                format="YYYY-MM-DD"
                valueFormat="YYYY-MM-DD"
                style="width: 160px"
                @change="(value: string) => formatChange(value, record)"
              >
              </gl-date-picker>
            </template>
            <template v-if="column.key === 'dataValue'">
              <gl-input-number
                v-model:value="record.dataValue"
                :controls="false"
                style="width: 100%"
              ></gl-input-number>
            </template>
          </template>
        </gl-table>
      </div>
    </div>
  </gl-modal>
</template>

<script setup lang="ts">
import { LoadingOutlined } from '@ant-design/icons-vue'
import { Icon } from '@mysteel-standard/components'
import { computed, onMounted, ref } from 'vue'
import useInitTable from '../composables/use-init-table'
import useDownloadIndex from '../composables/use-download-index'
import api from '../api/index'
import { message } from 'gl-design-vue'
interface Props {
  modalVisible: boolean
  configId: number
}
const props = defineProps<Props>()
interface Emits {
  (e: 'toBack'): void
}
const emits = defineEmits<Emits>()

const visible = computed(() => props.modalVisible)
const tableLoading = ref(false)
const frequencyArr = [
  { name: '全部', id: 0, val: '' },
  { name: '日度', id: 1, val: '日度' },
  { name: '周度', id: 2, val: '周度' },
  { name: '旬度', id: 3, val: '旬度' },
  { name: '月度', id: 4, val: '月度' },
  { name: '季度', id: 5, val: '季度' },
  { name: '年度', id: 6, val: '年度' }
]
const formParams = ref({ indexCode: '', indexName: '', frequency: '' })

//表格
const { columns, getYearWeek, formatChange, tableData, formatData, applyLoading, disabledDate } =
  useInitTable()

//上传
const { fileList, action, headers, onBeforeUpload, handleChange, uploadLoading, uploadFile } =
  useDownloadIndex()

const submit = () => {
  const hasData = tableData.value.some(
    (item: { dataValue: number }) => item.dataValue || item.dataValue === 0
  )
  if (!uploadFile.value && !hasData) {
    message.warning('数据为空，请输入数据后再提交！')
    return
  }
  apply()
}

const apply = async () => {
  const hasData = tableData.value.some(
    (item: { dataValue: number }) => item.dataValue || item.dataValue === 0
  )
  const indexList = tableData.value.map((item: { dataDate: any; frequency: any }) => {
    return {
      ...item,
      dataDate: formatData(item.dataDate, item.frequency)
    }
  })
  let params: any = {
    configId: props.configId
  }
  if (uploadFile.value && !hasData) {
    params.fillingType = 1
    params.uploadFile = uploadFile.value
  } else if (!uploadFile.value && hasData) {
    params.fillingType = 2
    params.onlineFillingData = indexList
  } else if (uploadFile.value && hasData) {
    params.fillingType = 3
    params.uploadFile = uploadFile.value
    params.onlineFillingData = indexList
  }
  applyLoading.value = true
  const { res, err } = await api.apply(params)
  applyLoading.value = false
  if (res && !err) {
    message.success('提交成功')
    toBack()
  }
}

const search = async () => {
  const param = {
    configId: props.configId,
    ...formParams.value
  }
  tableLoading.value = true
  const { res, err } = await api.getFormIndexPreValue(param)
  tableLoading.value = false
  if (res && !err) {
    tableData.value = res.data.map((item: any) => {
      if (item.dataValue === null || item.dataValue === '') {
        item.dataValue = undefined
      }
      return item
    })
  }
}

const reset = () => {
  formParams.value.indexCode = ''
  formParams.value.frequency = ''
  formParams.value.indexName = ''
  search()
}
const toBack = () => {
  emits('toBack')
}

onMounted(() => {
  search()
})
</script>

<style lang="scss" scoped>
.modal-container {
  width: 1568px;
  height: 700px;
  background-color: #fff;
  .search-container {
    display: flex;
    justify-content: space-between;
    margin: 20px 0;
    .search-form {
      margin: 0 10px;
    }
  }
  .btn-container {
    .btn-item {
      margin-right: 8px;
    }
    .fr {
      float: right;
    }
  }
  .table-container {
    margin: 16px 0;
    height: 500px;
  }
}
:deep(.gl-upload-list) {
  display: inline-block;
}
</style>
