/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-23 17:12:52
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-11 19:57:43
 * @Description:
 */
import { ref } from 'vue'
import dayjs from 'dayjs'
import quarterOfYear from 'dayjs/plugin/quarterOfYear'
dayjs.extend(quarterOfYear)
export default () => {
  const tableData = ref([])
  const applyLoading = ref(false)
  const columns = [
    {
      title: '指标名称',
      dataIndex: 'indexName',
      key: 'indexName'
    },

    {
      title: '指标编码',
      dataIndex: 'indexCode',
      key: 'indexCode',
      width: 280
    },

    {
      title: '指标频度',
      dataIndex: 'frequency',
      key: 'frequency',
      width: 120
    },

    {
      title: '上期数据日期',
      dataIndex: 'preDataDate',
      key: 'preDataDate',
      width: 160
    },

    {
      title: '上期数据',
      dataIndex: 'preDataValue',
      key: 'preDataValue',
      width: 160
    },

    {
      title: '待录入数据日期',
      dataIndex: 'dataDate',
      key: 'dataDate',
      width: 280
    },
    {
      title: '待录入数据',
      dataIndex: 'dataValue',
      key: 'dataValue',
      width: 200
    },
    {
      title: '指标单位',
      dataIndex: 'unit',
      key: 'unit',
      width: 80
    }
  ]

  const getYearWeek = (date: string) => {
    const date1 = new Date(date)
    const date2 = new Date(date1.getFullYear(), 0, 1)
    let day1 = date1.getDay()
    if (day1 === 0) day1 = 7
    let day2 = date2.getDay()
    if (day2 === 0) day2 = 7
    const d = Math.round(
      (date1.getTime() - date2.getTime() + (day2 - day1) * (24 * 60 * 60 * 1000)) / 86400000
    )
    return Math.ceil(d / 7)
  }

  const formatChange = (val: string, row: { dataDate: string; frequency: string }) => {
    if (val) {
      row.dataDate = formatData(val, row.frequency)
    }
  }

  const formatData = (date: string, type: string) => {
    const formatter = 'YYYY-MM-DD'
    let result = ''
    switch (type) {
      case '日度':
        result = date
        break
      case '周度':
        result = getFriday(date)
        break
      case '旬度':
        result = date
        break
      case '月度':
        result = dayjs(date).endOf('month').format(formatter)
        break
      case '季度':
        result = dayjs(date).endOf('quarter').format(formatter)
        break
      case '年度':
        result = dayjs(date).endOf('year').format(formatter)
        break
      default:
        result = date
    }
    return result
  }

  const getFriday = (date: string) => {
    const formatter = 'YYYY-MM-DD'
    const weekOfday = dayjs(date).endOf('week')
    //  获取本周周五的日期
    return dayjs(weekOfday).subtract(2, 'day').format(formatter)
  }

  const disabledDate = (current: any) => {
    const endDate = dayjs(current).endOf('month').format('DD')
    return !(
      dayjs(current).format('DD') === '10' ||
      dayjs(current).format('DD') === '20' ||
      dayjs(current).format('DD') === endDate
    )
  }

  return { columns, getYearWeek, formatChange, tableData, formatData, applyLoading, disabledDate }
}
