export interface model {
  //搜索条件
  breedName: string, // 品种
  breedChild?: string, // 细分品种
  areaName?: string,
  type?: string,
  weekValue: any,
  monthValue: any

}
export interface pickerOption{
  shortcuts: Array<object>,
  disabledDate:Function
  firstDayOfWeek?:number,

}
export interface type{
  label: string,
  key:string
}
export interface breed{
  moduleName:string,
  id:number,
  children:Array<object>
}


export interface forcastTableDataModel
  {
    id: number,
    userId: number,
    userName: string,
    expectForecastPrice: number,
    expertComprehensivePrice: number,
    lastActualValue: number,
    thisActualValue: number,
    forecastTrend: object,
    forecastScore: number,
    areaName: string,
    breedName: string,
    forecastType: number,
    state: number,
    dataDate:string,
    updateTime: string,
    createTime: string,
    isDelete: boolean,
    isSuccess: boolean,
    successRate: number,
    weight: number,
    up: number,
    down: number,
    flat: string,
    forecastComment: string,
    expertScoreResult: string,
    configIsExist: boolean,
    updateDate: string,
    createDate: string,
    upsAndCollarsRange: string,
    expectForecastPriceTemp?:number
    forecastCommentTemp?:number
    expertScoreResultTemp?:number
}


