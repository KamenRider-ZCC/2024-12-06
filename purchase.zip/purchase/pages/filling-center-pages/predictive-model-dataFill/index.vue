<template>
  <div style="padding: 16px">
    <div class="container expert-forecast">
      <gl-row>
        <gl-form
          :loading="formLoading"
          class="formModel"
          size="mini"
          :model="formModel"
          :label-col="labelCol"
        >
          <gl-form-item label="时间 ：">
            <gl-date-picker
              size="mini"
              v-show="formModel.type === 'week'"
              v-model:value="formModel.weekValue"
              picker="week"
              :allowClear="false"
              format="YYYY第ww周"
              valueFormat="YYYY-MM-DD"
              placeholder="选择周"
              :disabledDate="pickerOptions"
              @change="paramsChange"
            ></gl-date-picker>
            <gl-date-picker
              size="mini"
              v-show="formModel.type === 'month'"
              v-model:value="formModel.monthValue"
              :allowClear="false"
              picker="month"
              valueFormat="YYYY-MM-DD"
              placeholder="选择月"
              :disabledDate="pickerOptions"
              @change="paramsChange"
            ></gl-date-picker>
          </gl-form-item>
          <gl-form-item label="品种 ：">
            <gl-radio-group
              v-model:value="formModel.breedName"
              @change="paramsChange"
              button-style="solid"
            >
              <gl-radio-button
                v-for="item in breedNameArr"
                :key="item.id"
                :value="item.moduleName"
                >{{ item.moduleName }}</gl-radio-button
              >
            </gl-radio-group>
          </gl-form-item>
          <gl-form-item label="细分品种 ：">
            <gl-radio-group
              v-model:value="formModel.breedChild"
              @change="paramsChange"
              button-style="solid"
            >
              <gl-radio-button
                v-for="item in breedChildArr"
                :key="item.id"
                :value="item.moduleName"
                >{{ item.moduleName }}</gl-radio-button
              >
            </gl-radio-group>
          </gl-form-item>
          <gl-form-item label="区域 ：">
            <gl-radio-group
              v-model:value="formModel.areaName"
              @change="paramsChange"
              button-style="solid"
            >
              <gl-radio-button
                v-for="item in areaNameArr"
                :key="item.id"
                :value="item.moduleName"
                >{{ item.moduleName }}</gl-radio-button
              >
            </gl-radio-group>
          </gl-form-item>
          <gl-form-item label="频度 ：">
            <gl-radio-group
              v-model:value="formModel.type"
              @change="paramsChange"
              button-style="solid"
            >
              <gl-radio-button v-for="item in typeArr" :key="item.key" :value="item.key">
                {{ item.label }}
              </gl-radio-button>
            </gl-radio-group>
          </gl-form-item>
        </gl-form>
      </gl-row>
      <gl-row justify="end" type="flex" style="margin-bottom: 10px">
        <gl-button
          style="margin-right: 16px"
          size="small"
          type="primary"
          @click="fullViewVisible = true"
        >
          专家预测
        </gl-button>
      </gl-row>
      <gl-row>
        <gl-table
          :data-source="tableData"
          :pagination="false"
          :columns="indexColumns"
          :loading="loading"
          :scroll="{ y: 400 }"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.dataIndex === 'userName'">
              <slot name="userName" v-bind="{ column, record }">
                <gl-popover placement="topRight" v-if="record.forecastComment">
                  <template #content>
                    <p style="width: 400px; word-wrap: break-word">{{ record.forecastComment }}</p>
                  </template>
                  <gl-button type="text">
                    {{ record.userName }}
                  </gl-button>
                </gl-popover>
                <span v-else>{{ record.userName }}</span>
              </slot></template
            >
            <template v-if="column.dataIndex === 'successRate'">
              <slot name="successRate" v-bind="{ column, record }">
                {{
                  record.successRate !== undefined && record.successRate !== null
                    ? record.successRate + '%'
                    : '--'
                }}
              </slot>
            </template>
            <template v-if="column.dataIndex === 'forecastTrend'">
              <slot name="forecastTrend" v-bind="{ column, record }">
                <span>
                  {{ record.forecastTrend !== null ? trend[record.forecastTrend] : '--' }}
                </span>
              </slot>
            </template>
            <template v-if="column.dataIndex === 'weight'">
              <slot name="weight" v-bind="{ column, record }">
                {{
                  record.weight !== undefined && record.weight !== null ? record.weight + '%' : '--'
                }}</slot
              ></template
            >
          </template>
        </gl-table>
      </gl-row>
      <full-modal
        v-if="fullViewVisible"
        v-model:visible="fullViewVisible"
        @handle-ok="submit()"
        @handle-cancel="fullViewVisible = false"
      >
        <gl-tabs>
          <gl-tab-pane tab="专家预测" key="1">
            <forecoast-table
              @afterSubmit="afterSubmit"
              ref="forecoastTables"
              :breedNameArr="breedNameArr"
              :trend="trend"
            ></forecoast-table>
          </gl-tab-pane>
        </gl-tabs>
      </full-modal>

      <!-- <score-detail ref="scoreDetail"></score-detail> -->
    </div>
  </div>
</template>

<script setup lang="ts">
import { FullModal } from '@mysteel-standard/components'
import forecoastTable from './components/forecoastTable.vue'
import moment from 'moment'
import { debounce } from 'lodash'
import { reactive, ref, watch, onMounted } from 'vue'
import api from './api/index'
import { model, breed } from './types/interface'
import { trend, typeArr, indexColumns } from './constant/index'

const labelCol = reactive({ style: { width: '83px' } })
const forecoastTables = ref<any>(null)
const formModel = reactive<model>({
  //搜索条件
  breedName: '', // 品种
  breedChild: '', // 细分品种
  areaName: '',
  type: 'week',
  weekValue: moment().startOf('week').add(5, 'd').format('YYYY-MM-DD'),
  monthValue: moment().endOf('month').format('YYYY-MM-DD')
})

const pickerOptions = (current: any) => {
  return current && current > moment().endOf('day')
}

const breedNameArr = reactive<Array<breed>>([])
const breedChildArr = reactive<Array<breed>>([])
const areaNameArr = reactive<Array<breed>>([])

const tableData = reactive<Array<object>>([])
const loading = ref<boolean>(false)

const saveLoading = ref<boolean>(false)
const fullViewVisible = ref<boolean>(false)
const formLoading = ref<boolean>(false)

watch(
  () => formModel.breedName,
  (val) => {
    const item: Array<any> = breedNameArr.filter((i) => i.moduleName === val)
    breedChildArr.length = 0
    if (item.length > 0) {
      breedChildArr.push(...item[0].children)
      formModel.breedChild = item[0].children[0].moduleName
    }
  }
)
watch(
  () => formModel.breedChild,

  (val) => {
    const item: any = breedChildArr.filter((i) => i.moduleName === val)
    areaNameArr.length = 0
    if (item.length > 0) {
      areaNameArr.push(...item[0].children)
      formModel.areaName = item[0].children[0].moduleName
    }
  }
)
watch(
  () => formModel.weekValue,
  (val) => {
    formModel.weekValue = moment(val).startOf('week').add(5, 'd').format('YYYY-MM-DD')
  }
)
watch(
  () => formModel.monthValue,
  (val) => {
    formModel.monthValue = moment(val).endOf('month').format('YYYY-MM-DD')
  }
)

onMounted(() => fetchFormControlData())

//获取新品种
const fetchFormControlData = async () => {
  formLoading.value = true
  const { res, err } = await api.moduleSearch()
  formLoading.value = false
  breedNameArr.length = 0
  if (!err) {
    const { userModules } = res.data
    breedNameArr.push(...userModules)
    formModel.breedName = userModules[0].moduleName
    // formModel.breedChild = userModules[0].children[0].moduleName
    // formModel.areaName = userModules[0].children[0].children[0].moduleName
    paramsChange()
  }
}
const paramsChange = debounce(() => {
  getTableList()
}, 300)

// 表格接口
const getTableList = async () => {
  loading.value = true
  let date = moment().format('YYYY-MM-DD')
  if (formModel.type === 'week') {
    date = formModel.weekValue
  } else if (formModel.type === 'month') {
    date = formModel.monthValue
  }
  const params = {
    areaName: formModel.areaName,
    date: date,
    breedName: formModel.breedChild,
    type: formModel.type
  }
  const { res, err } = await api.getExpertForecastList(params)
  loading.value = false
  tableData.length = 0
  if (!err) {
    const { data } = res
    tableData.push(...data)
  }
}
const afterSubmit = (flag: boolean) => {
  saveLoading.value = false
  if (flag) {
    return
  }
  fullViewVisible.value = false
  getTableList()
}
const submit = () => {
  saveLoading.value = true
  forecoastTables.value.submitList()
}
</script>
<style lang="scss" scoped>
.expert-forecast {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  height: calc(100vh - 126px);
  background: #fff;
  border-radius: 4px;
  padding: 16px;

  .formModel {
    .gl-form-item {
      margin-bottom: 14px;
      &:last-child {
        margin-bottom: 0;
      }
    }
  }
}
</style>
