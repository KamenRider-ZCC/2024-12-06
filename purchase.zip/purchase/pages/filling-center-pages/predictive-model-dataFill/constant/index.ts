export  const columns = reactive([
  {
    title: '品种',
    dataIndex: 'breedName',
    key: 'breedName',
    minWidth: 10
  },
  {
    title: '区域',
    dataIndex: 'areaName',
    key: 'areaName',
    minWidth: 10
  },
  {
    title: '预测日期',
    dataIndex: 'dataDate',
    key: 'dataDate',
    width: 200
  },
  {
    title: '上期实际值',
    dataIndex: 'lastActualValue',
    key: 'lastActualValue',
    minWidth: 10
  },
  {
    title: '预测价格',
    dataIndex: 'expectForecastPriceTemp',
    key: 'expectForecastPriceTemp',
    minWidth: 10
  },
  {
    title: '实际预判走势',
    dataIndex: 'forecastTrend',
    key: 'forecastTrend',
    minWidth: 10
  },
  
  {
    title: '备注',
    dataIndex: 'forecastCommentTemp',
    key: 'forecastCommentTemp',
    
  }
])

export const typeArr = reactive([
  { label: '周度', key: 'week' },
  { label: '月度', key: 'month' }
])
// 预测趋势 0 持平  1 看涨  -1 看跌  默认为2   3极度悲观 4  一般悲观 5 平稳 6一般看好  7极度看好
export const trend = reactive<object | any>({
  '-1': '看跌',
  0: '持平',
  1: '看涨',
  3: '极度悲观',
  4: '一般悲观',
  5: '平稳',
  6: '一般看好',
  7: '极度看好'
})

export const indexColumns = reactive([
  {
    title: '专家成员',
    dataIndex: 'userName',
    key: 'userName',
    align:'center',
    ellipsis: true
  },
  {
    title: '预判成功率',
    dataIndex: 'successRate',
    key: 'successRate',
    align:'center',
    ellipsis: true
  },
  {
    title: '市场预判走势',
    dataIndex: 'forecastTrend',
    key: 'forecastTrend',
    align:'center',
    ellipsis: true
  },
  {
    title: '预测价格',
    dataIndex: 'expectForecastPrice',
    key: 'expectForecastPrice',
    align:'center',
    ellipsis: true
  },
  {
    title: '权重',
    dataIndex: 'weight',
    key: 'weight',
    align:'center',
    ellipsis: true
  }
])