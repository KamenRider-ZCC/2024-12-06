export * from '.'

export { default as CustomModel } from './index.vue'
