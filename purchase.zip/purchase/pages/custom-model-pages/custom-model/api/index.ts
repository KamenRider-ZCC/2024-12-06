import request from '@mysteel-standard/apis'
const apiMap: object = {
  //自定义模型配置搜索条件（品种/细分品种/区域）
  getModelList: {
    method: 'get',
    url: '/forecast/getModuleList?type=1'
  },
  //自定义模型配置列表分页查询接口
  selectConfigListByPage: {
    method: 'post',
    url: '/forecast/config/selectConfigListByPage'
  },
  //自定义模型配置详情查询接口
  configDetail: {
    method: 'get',
    url: '/forecast/config/configDetail'
  },
  //自定义模型因子查询接口（新增/编辑配置页）
  indexCodeSearch: {
    method: 'post',
    url: '/forecast/config/indexCodeSearch'
  },
  //自定义模型配置保存接口
  saveCustomConfig: {
    method: 'post',
    url: '/forecast/config/saveCustomConfig'
  },
  //自定义模型配置删除接口
  deleteCustomConfig: {
    method: 'get',
    url: '/forecast/config/deleteCustomConfig'
  },
  //自定义模型配置修改接口
  updateCustomConfig: {
    method: 'post',
    url: '/forecast/config/updateCustomConfig'
  },
  //自定义模型批量启动、禁用接口
  configBatchStartStop: {
    method: 'post',
    url: '/forecast/config/configBatchStartStop'
  },
  //自定义模型立即执行
  runBatch: {
    method: 'post',
    url: '/forecast/config/runBatch'
  },
  //查询自定义模型是否计算完成
  queryCalculateComplete: {
    method: 'get',
    url: '/forecast/custom/queryCalculateComplete'
  },
  //自定义模型因子查询（查看详情-模型数据页）
  queryCustomFactor: {
    method: 'get',
    url: '/forecast/custom/queryCustomFactor'
  },
  //自定义模型准确率、绝对误差查询（查看详情-模型数据页）
  queryConfigModeSuccessRateWithDeviate: {
    method: 'get',
    url: '/forecast/custom/queryConfigModeSuccessRateWithDeviate'
  },
  //自定义模型准确率对比、绝对误差查询（查看详情-历史数据对比页）
  querySuccessRateCompare: {
    method: 'get',
    url: '/forecast/custom/querySuccessRateCompare'
  },
  //自定义模型准确率对比数据列表查询（查看详情-历史数据对比页）
  querySuccessRateCompareList: {
    method: 'get',
    url: '/forecast/custom/querySuccessRateCompareList'
  },
  //自定义模型历史数据走势对比图数据查询（查看详情-历史数据对比页）
  historyTrendDiagram: {
    method: 'get',
    url: '/forecast/custom/historyTrendDiagram'
  },
  //线上模型因子查询（查看详情-历史数据对比-每周详情页
  queryMachineFactor: {
    method: 'post',
    url: '/forecast/custom/queryMachineFactor'
  },
  //自定义模型每周详情-价格涨跌查询（查看详情-历史数据对比-每周详情页）
  queryForecastPriceDetail: {
    method: 'get',
    url: '/forecast/custom/queryForecastPriceDetail'
  },
  //自定义预测模型均价走势图数据查询（查看详情-实时数据页
  getAvgPriceTrendDiagram: {
    method: 'get',
    url: '/forecast/custom/getAvgPriceTrendDiagram'
  },

  getCatalogNode: {
    method: 'post',
    url: '/database/datacatalog/getCatalogNode'
  },
  getCatalogTree: {
    method: 'post',
    url: '/database/datacatalog/getCatalogTree'
  },
  getCollectIndexList: {
    method: 'get',
    url: '/database/indexCollect/getCollectIndexList'
  },
  // 查询用户自己添加的指标
  getSelectedCustomIndexCodes: {
    method: 'post',
    url: '/forecast/config/getSelectedCustomIndexCodes'
  }
}

export default request(apiMap)
