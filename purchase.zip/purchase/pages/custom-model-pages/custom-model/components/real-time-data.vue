<template>
  <div class="realTimeData">
    <gl-spin :spinning="calculateLoading" tip="数据计算中，请等待！">
      <div v-if="!calculateLoading" class="chart">
        <ms-chart autoresize :option="state.option" style="width: 100%; height: 100%" />
      </div>
    </gl-spin>
  </div>
</template>

<script setup lang="ts">
import { MsChart } from '@mysteel-standard/components'
import api from '../api/index'
import { getMultiChartOption } from '../hooks/use-multiChart-option'
interface Props {
  calculateLoading: boolean
}
const props = defineProps<Props>()
const state = reactive({
  loading: false,
  option: {}
})

const getAvgPriceTrendDiagram = async (id: any) => {
  state.loading = true
  const oId = 'comprehensiveChart'

  const { res, err } = await api.getAvgPriceTrendDiagram({ configId: id })
  state.loading = false
  if (!err) {
    const { data } = res
    if (!data) {
      return
    }
    const { unit } = data

    let { actAvgPriceList: list1, foreAvgPriceList: list2 } = data
    list1 = list1 || []
    list2 = list2 || []

    for (let index = list1.length - 1; index > -1; index--) {
      const element = list1[index]
      const l2Elements = list2.map((v: any) => {
        return v.dataDate
      })
      if (l2Elements.indexOf(element.dataDate) === -1) {
        list2.unshift(element)
      }
      if (element.dataValue) {
        break
      }
    }
    const timeX = [...new Set([...list1, ...list2].map((item) => item.dataDate))]
    const l1 = list1.length
    const l2 = list2.length
    const l3 = timeX.length
    const computedlist1 = formatChartData(
      list1.map((v: any) => v.dataValue),
      l3 - l1
    )
    const computedlist2 = formatChartData(
      list2.map((v: any) => v.dataValue),
      l3 - l2,
      'left'
    )
    const dataArray = [computedlist1, computedlist2]
    const title = '均价走势及预判'
    const legend = ['实际价格', '预测价格']
    Object.assign(
      state.option,
      getMultiChartOption(title, legend, timeX, unit, dataArray, ['line', 'dottedLine'], null, oId)
    )
  }
}

const formatChartData = (array: any, length: number, pos?: string) => {
  if (length === 0) {
    return array
  }
  return pos === 'left'
    ? new Array(length).join(',').split(',').concat(array)
    : array.concat(new Array(length).join(',').split(','))
}
defineExpose({
  getAvgPriceTrendDiagram
})
</script>

<style lang="scss" scoped>
.realTimeData {
  width: 100%;
  .chart {
    width: 100%;
    height: 300px;
  }
}
.gl-spin-spinning {
  width: 100%;
  height: 100%;
}
:deep(.gl-spin-dot) {
  margin-top: 100px;
}
</style>
