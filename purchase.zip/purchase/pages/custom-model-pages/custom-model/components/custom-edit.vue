<template>
  <full-modal v-model:visible="detailVisible" submitName="保存" @handle-ok="submit">
    <div class="bd">
      <div class="item-block form-model">
        <gl-form
          :rules="state.rules"
          :model="state.formModel"
          ref="formModelRef"
          :label-col="{ style: { width: '100px' } }"
        >
          <gl-form-item label="配置名称" name="name">
            <gl-input v-model:value="state.formModel.name" style="width: 200px"></gl-input>
          </gl-form-item>
          <gl-form-item label="品种" name="parentBreedName">
            <gl-radio-group
              v-model:value="state.formModel.parentBreedName"
              @change="handleChangeParentBreedName"
            >
              <div v-if="state.edit">
                <gl-radio-button
                  v-for="item in state.parentBreedNameArr"
                  :value="item.moduleName"
                  :key="item.id"
                  :disabled="modelDetail.parentBreedName == item.moduleName ? false : true"
                  >{{ item.moduleName }}</gl-radio-button
                >
              </div>
              <div v-else>
                <gl-radio-button
                  v-for="item in state.parentBreedNameArr"
                  :value="item.moduleName"
                  :key="item.id"
                  >{{ item.moduleName }}</gl-radio-button
                >
              </div>
            </gl-radio-group>
          </gl-form-item>
          <gl-form-item label="细分品种" name="breedName">
            <gl-radio-group v-model:value="state.formModel.breedName" @change="handleChangeBreed">
              <div v-if="state.edit">
                <gl-radio-button
                  v-for="item in state.breedNameArr"
                  :value="item.moduleName"
                  :key="item.id"
                  :disabled="modelDetail.breedName == item.moduleName ? false : true"
                  >{{ item.moduleName }}</gl-radio-button
                >
              </div>
              <div v-else>
                <gl-radio-button
                  v-for="item in state.breedNameArr"
                  :value="item.moduleName"
                  :key="item.id"
                  >{{ item.moduleName }}</gl-radio-button
                >
              </div>
            </gl-radio-group>
          </gl-form-item>
          <gl-form-item label="区域" name="areaName">
            <gl-radio-group v-model:value="state.formModel.areaName" @change="handeChangeArea">
              <div v-if="state.edit">
                <gl-radio-button
                  v-for="item in state.areaNameArr"
                  :value="item.moduleName"
                  :key="item.id"
                  :disabled="modelDetail.areaName == item.moduleName ? false : true"
                  >{{ item.moduleName }}</gl-radio-button
                >
              </div>
              <div v-else>
                <gl-radio-button
                  v-for="item in state.areaNameArr"
                  :value="item.moduleName"
                  :key="item.id"
                >
                  {{ item.moduleName }}
                </gl-radio-button>
              </div>
            </gl-radio-group>
          </gl-form-item>
          <gl-form-item label="频度" name="forecastType" required>
            <gl-radio-group
              v-model:value="state.formModel.forecastType"
              @change="changeForecastType"
            >
              <gl-radio-button :value="2" v-if="state.formModel.parentBreedName !== '国际航运'"
                >周度</gl-radio-button
              >
              <gl-radio-button :value="3">月度</gl-radio-button>
            </gl-radio-group>
          </gl-form-item>
          <gl-form-item label="执行机制" name="executeMechanism">
            <gl-radio-group v-model:value="state.formModel.executeMechanism">
              <gl-radio :value="0">单次执行</gl-radio>
              <gl-radio :value="1">{{
                state.formModel.forecastType === 2 ? '每周执行' : '每月执行'
              }}</gl-radio>
            </gl-radio-group>
          </gl-form-item>
          <gl-form-item label="是否公开" name="isPublic">
            <gl-radio-group v-model:value="state.formModel.isPublic">
              <gl-radio :value="0">否</gl-radio>
              <gl-radio :value="1">是</gl-radio>
            </gl-radio-group>
          </gl-form-item>
        </gl-form>
      </div>
      <!-- <gl-divider /> -->
      <div class="item-block table-data">
        <gl-button type="primary" @click="openDialog" style="float: right; margin-bottom: 10px">
          新增模型因子
        </gl-button>
        <gl-table
          :dataSource="state.tableData"
          ref="tableDataRef"
          :columns="columns"
          :pagination="false"
          row-key="indexCode"
          :scroll="{ y: 320 }"
          :loading="state.loading"
          :row-selection="{
            selectedRowKeys: tableSelectedKeys,
            onChange: onSelectChange
          }"
        >
        </gl-table>
      </div>
      <!-- 新增指标选择弹窗 -->
      <choose-index-modal
        v-if="chooseIndexVisible"
        v-model:chooseIndexVisible="chooseIndexVisible"
        :chooseIndexForm="chooseIndexForm"
        :frequency="state.formModel.forecastType === 2 ? '周度' : '月度'"
        @choose-index="chooseIndex"
      />
    </div>
  </full-modal>
</template>
<script setup lang="ts">
import { FullModal } from '@mysteel-standard/components'
import { message } from 'gl-design-vue'
import api from '../api/index'
import { cloneDeep, uniqBy } from 'lodash-es'
import ChooseIndexModal from './choose-index-modal.vue'

interface Props {
  visible: boolean
  saveLoading: Boolean
  modelDetail: Object | any
  data: Array<Object> | any
}
const props = defineProps<Props>()

interface Emits {
  (e: 'update:visible', val: boolean): void
  (e: 'submit', val: object, list: any, configId: any): void
}
const emits = defineEmits<Emits>()

const columns = computed(() => [
  {
    title: '因素类型',
    dataIndex: 'indexBaseType',
    ellipsis: true,
    width: 150
  },
  {
    title: '最优模型因子名称',
    dataIndex: 'indexName',
    ellipsis: true,
    filters: indexNameFilter.value,
    onFilter: (value: any, record: any) => record.indexName.startsWith(value),
    filterSearch: true
  }
])
const detailVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})
const tableSelectedKeys = reactive<Array<string>>([])
const state = reactive<any>({
  formModel: {
    name: '',
    parentBreedName: '',
    breedName: '',
    areaName: '',
    forecastType: 2,
    executeMechanism: 0,
    isPublic: 0
  },
  rules: {
    name: [
      { required: true, message: '请输入配置名称', trigger: 'change' },
      { max: 20, message: '长度在20个字符之内', trigger: 'blur' }
    ],
    parentBreedName: [{ required: true, message: '请选择品种', trigger: 'change' }],
    breedName: [{ required: true, message: '请选择细分品种', trigger: 'change' }],
    areaName: [{ required: true, message: '请选择区域', trigger: 'change' }],
    executeMechanism: [{ required: true, message: '请选择执行机制', trigger: 'change' }],
    isPublic: [{ required: true, message: '请选择是否公开', trigger: 'change' }]
  },
  breedNameArr: [],
  areaNameArr: [],
  parentBreedNameArr: [],
  tableData: [],
  loading: false,
  edit: false
})
const tableDataRef = ref<any>(null)
const formModelRef = ref<any>(null)
const indexNameFilter = computed(() => {
  const indexNames = uniqBy(state.tableData, 'indexName')
  return indexNames.map((item: any) => {
    return {
      text: item.indexName,
      value: item.indexName
    }
  })
})

const onSelectChange = (selectedRowKeys: any) => {
  tableSelectedKeys.length = 0
  tableSelectedKeys.push(...selectedRowKeys)
}
const submit = () => {
  const selected = cloneDeep(tableSelectedKeys)
  const list = state.tableData.map((i: any, index: any) => {
    const item = {
      indexCode: i.indexCode,
      indexName: i.indexName,
      forecastType: i.forecastType && i.forecastType !== 0 ? i.forecastType : 2,
      status: 0,
      sort: index,
      breedName: i.breedName && i.breedName !== 0 ? i.breedName : state.formModel.breedName,
      areaName: i.areaName && i.areaName !== 0 ? i.areaName : state.formModel.areaName,
      isPrice: i.isPrice && i.isPrice !== 0 ? i.isPrice : 0
    }
    selected.forEach((data: any) => {
      if (data === i.indexCode) {
        item.status = 1
      }
    })
    return item
  })
  // console.log(selected)
  formModelRef.value
    .validate()
    .then(() => {
      const configId = Object.keys(props.modelDetail).length === 0 ? '' : props.modelDetail.id
      if (selected.length > 0) {
        emits('submit', state.formModel, list, configId)
      } else {
        message.error('请至少选择一个模型因子！')
      }
    })
    .catch(() => {
      return false
    })
}
const handleChangeParentBreedName = (val: any) => {
  const item: any = state.parentBreedNameArr.filter(
    (i: any) => i.moduleName === state.formModel.parentBreedName
  )
  if (state.formModel.parentBreedName === '国际航运') {
    state.formModel.forecastType = 3
  }
  state.breedNameArr = item[0].children
  state.areaNameArr = item[0].children[0].children
  state.formModel.breedName = item[0].children[0].moduleName
  state.formModel.areaName = item[0].children[0].children[0].moduleName
  getIndexCode()
}
const handleChangeBreed = (val: any) => {
  const item: any = state.breedNameArr.filter(
    (i: any) => i.moduleName === state.formModel.breedName
  )
  state.areaNameArr = item[0].children
  state.formModel.areaName = item[0].children[0].moduleName
  getIndexCode()
}
const handeChangeArea = () => {
  getIndexCode()
}
const changeForecastType = () => {
  getIndexCode()
}
const initFormModel = (val: any) => {
  // console.log('ttt', val)
  if (val.length > 0) {
    state.formModel.forecastType = 2
    state.formModel.parentBreedName = val[0].moduleName
    state.formModel.breedName = val[0].children[0].moduleName
    state.formModel.areaName = val[0].children[0].children[0].moduleName
    state.parentBreedNameArr = val
    state.breedNameArr = val[0].children
    state.areaNameArr = val[0].children[0].children
  }
}
const getIndexCode = async () => {
  state.loading = true
  const params = {
    parentBreedName: state.formModel.parentBreedName,
    breedName: state.formModel.breedName,
    areaName: state.formModel.areaName,
    forecastType: state.formModel.forecastType,
    configId: props.modelDetail.id
  }
  const { res, err } = await api.indexCodeSearch(params)
  state.loading = false
  if (!err) {
    const { data } = res
    // console.log('data', props.modelDetail, state.tableData)
    state.tableData = data
    const ids: any = []
    if (Object.keys(props.modelDetail).length !== 0) {
      props.modelDetail.indexList.forEach((i: any) => {
        state.tableData.forEach((item: any) => {
          if (item.indexCode === i.indexCode) {
            ids.push(item.indexCode)
          }
        })
      })
      onSelectChange(ids)
    }
    if (!state.edit) {
      state.tableData.forEach((data: any) => {
        if (props.data.isChoose) {
          ids.push(data.indexCode)
        }
      })
      onSelectChange(ids)
    }
  }
}

const chooseIndexVisible = ref()
const chooseIndexForm: any = reactive({
  indexList: []
})
const openDialog = async () => {
  const params = {
    areaName: state.formModel.areaName,
    breedName: state.formModel.breedName,
    configId: props.modelDetail.id,
    // factorName: '',
    parentBreedName: state.formModel.parentBreedName
  }
  const { res, err } = await api.getSelectedCustomIndexCodes(params)
  if (res && !err) {
    chooseIndexForm.indexList = res.data
  } else {
    chooseIndexForm.indexList = []
  }
  chooseIndexVisible.value = true
}
const chooseIndex = () => {
  const tableData = cloneDeep(state.tableData)
  tableData.push(...chooseIndexForm.indexList)
  state.tableData = uniqBy(tableData, 'indexCode')
}

watch(
  () => props.modelDetail,
  (newVal) => {
    if (Object.keys(newVal).length !== 0) {
      state.formModel.parentBreedName = newVal.parentBreedName
      state.formModel.breedName = newVal.breedName
      state.formModel.areaName = newVal.areaName
      state.formModel.forecastType = newVal.forecastType
      state.formModel.name = newVal.name
      state.formModel.executeMechanism = newVal.executeMechanism
      state.formModel.isPublic = newVal.isPublic
      const item: any = state.parentBreedNameArr.filter(
        (i: any) => i.moduleName === newVal.parentBreedName
      )
      state.breedNameArr = item[0].children
      const area: any = state.breedNameArr.filter((i: any) => i.moduleName === newVal.breedName)
      state.areaNameArr = area[0].children
      state.edit = true
    } else {
      initFormModel(props.data)
      state.formModel.name = ''
      state.formModel.executeMechanism = 0
      state.formModel.isPublic = 0
      state.edit = false
    }
    getIndexCode()
  },
  { deep: true, immediate: true }
)
watch(
  () => props.data,
  (val: any) => {
    // console.log('props', props.data)
    if (state.formModel.breedName === '' && val && val.length > 0) {
      initFormModel(val)
    }
  },
  { deep: true, immediate: true }
)
</script>
<style lang="scss" scoped></style>
