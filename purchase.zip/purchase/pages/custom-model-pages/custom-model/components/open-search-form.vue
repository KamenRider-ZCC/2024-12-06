<template>
  <gl-form ref="formRef" layout="inline" :model="dataState">
    <gl-form-item label="配置名称">
      <gl-input v-model:value="dataState.name" placeholder="请输入配置名称"></gl-input>
    </gl-form-item>
    <gl-form-item label="品种">
      <gl-select ref="select" v-model:value="dataState.parentBreedName" style="width: 120px">
        <gl-select-option
          v-for="item in formControl"
          :key="item.id"
          :label="item.moduleName"
          :value="item.moduleName"
          >{{ item.moduleName }}</gl-select-option
        >
      </gl-select>
    </gl-form-item>
    <gl-form-item label="细分品种">
      <gl-select ref="select" v-model:value="dataState.breedName" style="width: 120px">
        <gl-select-option
          v-for="item in breedNameArr"
          :key="item.id"
          :label="item.moduleName"
          :value="item.moduleName"
          >{{ item.moduleName }}</gl-select-option
        >
      </gl-select>
    </gl-form-item>
    <gl-form-item label="区域">
      <gl-select ref="select" v-model:value="dataState.areaName" style="width: 120px">
        <gl-select-option
          v-for="item in areaNameArr"
          :key="item.id"
          :label="item.moduleName"
          :value="item.moduleName"
          >{{ item.moduleName }}</gl-select-option
        >
      </gl-select>
    </gl-form-item>
    <gl-form-item v-if="isPublic === 0" label="状态">
      <gl-select ref="select" v-model:value="dataState.status" style="width: 100px">
        <gl-select-option
          v-for="item in statusArr.list"
          :key="item.value"
          :label="item.label"
          :value="item.value"
          >{{ item.label }}</gl-select-option
        >
      </gl-select>
    </gl-form-item>
    <gl-form-item v-else label="模型归属人">
      <gl-input v-model:value="dataState.createUserName" placeholder="请输入模型归属人"></gl-input>
    </gl-form-item>
    <gl-button type="primary" @click="handleSearch">
      <icon name="icon-search" />
      搜索
    </gl-button>
    <gl-button style="margin: 0 8px" @click="reset">
      <icon name="icon-reset" />
      重置
    </gl-button>
  </gl-form>
</template>
<script setup lang="ts">
import { useResetData } from '@mysteel-standard/hooks'
import { Icon } from '@mysteel-standard/components'
import { reactive } from 'vue'
import api from '../api/index'
import { STATUS } from '../enum/index'
interface Props {
  isPublic: number
}
const props = defineProps<Props>()
const { dataState, resetDataState } = useResetData({
  name: '',
  parentBreedName: null,
  breedName: null,
  areaName: null,
  status: null,
  createUserName: '',
  isPublic: props.isPublic
})

interface Emits {
  (e: 'search', val: object): void
  (e: 'getFormControl', val: Array<Object>): void
}

const emits = defineEmits<Emits>()
const formControl = reactive<any>([])
const breedNameArr = reactive<any>([])
const areaNameArr = reactive<any>([])
const statusArr = reactive<any>(STATUS)
const handleSearch = () => {
  emits('search', dataState)
}
const reset = () => {
  resetDataState()
  initOptions()
  nextTick(() => {
    emits('search', dataState)
  })
}
// 获取级联品种区域选项
const fetchFormControlData = async () => {
  const { res, err } = await api.getModelList()
  formControl.length = 0
  if (!err) {
    Object.assign(formControl, res.data.userModules)
    emits('getFormControl', formControl)
  }
}
const initOptions = () => {
  breedNameArr.length = 0
  areaNameArr.length = 0
}

watch(
  () => dataState.parentBreedName,
  (val) => {
    if (!val) {
      dataState.breedName = null
      dataState.areaName = null
      breedNameArr.length = 0
      areaNameArr.length = 0
      return
    }

    const item = formControl.filter((i: any) => i.moduleName === val)
    Object.assign(breedNameArr, item[0].children)
    Object.assign(areaNameArr, item[0].children[0].children)
    dataState.breedName = null
    dataState.areaName = null
  }
)
watch(
  () => dataState.breedName,
  (val) => {
    if (!val) {
      return
    }
    const item = breedNameArr.filter((i: any) => i.moduleName === val)
    Object.assign(areaNameArr, item[0].children)
    dataState.areaName = null
  }
)
onMounted(() => {
  fetchFormControlData()
  emits('search', dataState)
})
</script>
<style lang="scss"></style>
