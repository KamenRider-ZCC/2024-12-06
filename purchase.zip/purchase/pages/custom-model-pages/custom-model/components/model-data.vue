<template>
  <div class="modelData">
    <div style="flex: 1">
      <ul class="top-ul">
        <li class="item-block">
          <div class="data-box">
            <p class="li-title">当前配置模型准确率</p>
            <p class="li-data">{{ state.customSuccessRate1 }}%</p>
          </div>
          <div class="pie-chart">
            <ms-chart ref="basisChart1" autoresize class="chart" :option="chartOption1" />
          </div>
        </li>
        <li class="item-block">
          <p class="li-title">当前配置模型绝对误差</p>
          <p class="li-data">
            {{ state.forecastDifference1 }}
          </p>
        </li>
      </ul>
      <gl-table
        :data-source="state.tableDataOne"
        :columns="columns"
        :pagination="false"
        row-key="id"
        ref="tableData1"
        :loading="state.loading"
        :scroll="{ y: 320 }"
        style="margin-left: -2px; margin-right: -2px"
      >
      </gl-table>
    </div>
    <div style="flex: 1; margin-left: 40px">
      <ul class="top-ul">
        <li class="item-block">
          <div class="data-box">
            <p class="li-title">最优配置模型准确率</p>
            <p class="li-data">{{ state.customSuccessRate2 }}%</p>
          </div>
          <div class="pie-chart">
            <ms-chart ref="basisChart2" autoresize class="chart" :option="chartOption2" />
          </div>
        </li>
        <li class="item-block">
          <p class="li-title">最优配置模型绝对误差</p>
          <p class="li-data">
            {{ state.forecastDifference2 }}
          </p>
        </li>
      </ul>
      <gl-table
        :data-source="state.tableDataTwo"
        :columns="columns"
        :pagination="false"
        row-key="id"
        ref="tableData2"
        :loading="state.loading"
        :scroll="{ y: 320 }"
        style="margin-left: -2px; margin-right: -2px"
      >
      </gl-table>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { detailForm } from '../types/interface'
import { MsChart } from '@mysteel-standard/components'
import api from '../api/index'
interface Props {
  configDetail: detailForm
}
const props = defineProps<Props>()
const state = reactive({
  tableDataOne: [],
  tableDataTwo: [],
  customSuccessRate1: 0,
  forecastDifference1: 0,
  customSuccessRate2: 0,
  forecastDifference2: 0,
  loading: false,
  isPublic: 1
})
const chartOption1 = reactive({})
const chartOption2 = reactive({})
const columns = reactive([
  {
    title: '最优模型因子名称',
    dataIndex: 'indexName',
    ellipsis: true,
    sorter: (a: any, b: any) => a.indexName.length - b.indexName.length
  },
  {
    title: '相关性系数',
    dataIndex: 'relativeCoefficient',
    ellipsis: true,
    sorter: (a: any, b: any) => a.relativeCoefficient - b.relativeCoefficient
  }
])
// 自定义模型因子相关性查询
const queryCustomFactor1 = async (id: any) => {
  state.loading = true
  const param = {
    configId: id,
    high: false,
    isPublic: state.isPublic
  }
  const { res, err } = await api.queryConfigModeSuccessRateWithDeviate(param)

  if (!err) {
    const { data } = res
    state.customSuccessRate1 = data.customSuccessRate || '-'
    state.forecastDifference1 = data.forecastDifference || '-'
    getAvgPriceTrendDiagramChart('customSuccessRate1', data.customSuccessRate)
    queryCustomFactorTable(data.configId, 'One')
  }
}
const queryCustomFactor2 = async (id: any) => {
  state.loading = true
  const param = {
    configId: id,
    high: true,
    isPublic: state.isPublic
  }
  const { res, err } = await api.queryConfigModeSuccessRateWithDeviate(param)

  if (!err) {
    const { data } = res
    state.customSuccessRate2 = data.customSuccessRate || '-'
    state.forecastDifference2 = data.forecastDifference || '-'

    getAvgPriceTrendDiagramChart('customSuccessRate2', data.customSuccessRate)

    queryCustomFactorTable(data.configId, 'Two')
  }
}

const getAvgPriceTrendDiagramChart = async (id: any, data: any) => {
  let option = {
    series: [
      {
        name: '任务进度',
        type: 'pie',
        radius: ['60%', '100%'],
        emphasis: { scale: false },

        labelLine: {
          show: false
        },
        data: [
          {
            value: data,
            selected: false
          },
          {
            value: 100 - data,
            label: {
              show: false
            },
            itemStyle: {
              color: '#EEEEEE'
            },
            emphasis: {
              itemStyle: { color: '#EEEEEE' }
            }
          }
        ]
      }
    ],
    color: ['#01E6E3', '#EEEEEE']
  }
  if (id === 'customSuccessRate1') {
    Object.assign(chartOption1, option)
  } else {
    Object.assign(chartOption2, option)
  }
}
const queryCustomFactorTable = async (id: any, target: any) => {
  const { res, err } = await api.queryCustomFactor({ configId: id })
  state.loading = false
  if (!err) {
    const { data }: any = res
    if (target === 'One') {
      state.tableDataOne = data.map((item: any) => {
        if (!item.relativeCoefficient && item.relativeCoefficient !== 0) {
          item.relativeCoefficient = '-'
        }
        return item
      })
    } else {
      state.tableDataTwo = data.map((item: any) => {
        if (!item.relativeCoefficient && item.relativeCoefficient !== 0) {
          item.relativeCoefficient = '-'
        }
        return item
      })
    }
  }
}
defineExpose({
  queryCustomFactor1,
  queryCustomFactor2
})
</script>

<style lang="scss" scoped>
@import '../style/index.scss';
.modelData {
  min-height: 300px;
  display: flex;
}
</style>
