<template>
  <full-modal v-model:visible="detailVisible" :showSubmit="false">
    <gl-spin :spinning="loading">
      <div class="bd">
        <div class="item-block form-model">
          <gl-form :label-col="{ style: { width: '100px' } }">
            <gl-row>
              <gl-col :span="12">
                <gl-form-item label="配置名称" name="name">
                  <span style="max-width: 300px">{{ configDetail.name }}</span>
                </gl-form-item>
                <gl-form-item label="品种" name="parentBreedName">
                  <span>{{ configDetail.parentBreedName }}</span>
                </gl-form-item>

                <gl-form-item label="细分品种" name="breedName">
                  <span>{{ configDetail.breedName }}</span>
                  <!-- <gl-radio-button :label="configDetail.breedName"></gl-radio-button> -->
                </gl-form-item>
              </gl-col>
              <gl-col :span="12">
                <gl-form-item label="区域" name="areaName">
                  <span>{{ configDetail.areaName }}</span>
                  <!-- <gl-radio-button :label="configDetail.areaName"></gl-radio-button> -->
                </gl-form-item>
                <gl-form-item label="频度" name="forecastType">
                  <span>{{ configDetail.forecastType === 2 ? '周度' : '月度' }}</span>
                </gl-form-item>
                <gl-form-item label="执行机制" name="executeMechanism">
                  <span>
                    {{
                      configDetail.executeMechanism === 0
                        ? '单次执行'
                        : configDetail.forecastType === 2
                          ? '每周执行'
                          : '每月执行'
                    }}
                  </span>
                </gl-form-item>
                <gl-form-item label="是否公开" name="isPublic">
                  <span>
                    {{ configDetail.isPublic === 0 ? '否' : '是' }}
                  </span>
                </gl-form-item>
              </gl-col>
            </gl-row>
          </gl-form>
        </div>
        <!-- <gl-divider /> -->
        <div class="item-block table-data">
          <gl-tabs v-model:activeKey="activeName">
            <gl-tab-pane tab="模型数据" key="0">
              <modelData ref="modelDataRef" :configDetail="configDetail" />
            </gl-tab-pane>
            <gl-tab-pane tab="历史数据对比" key="1">
              <historyData
                ref="historyDataRef"
                :configDetail="configDetail"
                :calculateLoading="calculateLoading"
              />
            </gl-tab-pane>
            <gl-tab-pane tab="实时数据" key="2">
              <realTimeData
                ref="realTimeDataRef"
                :configDetail="configDetail"
                :calculateLoading="calculateLoading"
              />
            </gl-tab-pane>
          </gl-tabs>
        </div>
      </div>
    </gl-spin>
  </full-modal>
</template>
<script setup lang="ts">
import { FullModal } from '@mysteel-standard/components'
import type { detailForm } from '../types/interface'
import modelData from '../components/model-data.vue'
import historyData from '../components/history-data.vue'
import realTimeData from '../components/real-time-data.vue'
interface Props {
  visible: boolean
  configDetail: detailForm
  calculateLoading: boolean
}
const props = defineProps<Props>()
const state = reactive({
  num: 0,
  num1: 0,
  num2: 0
})
const modelDataRef = ref<any>(null)
const historyDataRef = ref<any>(null)
const realTimeDataRef = ref<any>(null)

const loading = ref<boolean>(false)
interface Emits {
  (e: 'update:visible', val: boolean): void
}
const emits = defineEmits<Emits>()

const detailVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})
const activeName = ref('')

watch(
  () => activeName,
  (newVal) => {
    if (newVal.value === '0') {
      if (state.num === 0) {
        nextTick(() => {
          modelDataRef.value.queryCustomFactor1(props.configDetail.id)
          modelDataRef.value.queryCustomFactor2(props.configDetail.id)
        })
        state.num++
      }
    }
    if (newVal.value === '1') {
      if (state.num1 === 0) {
        nextTick(() => {
          historyDataRef.value.historyTrendDiagram(props.configDetail.id)
          historyDataRef.value.querySuccessRateCompare(props.configDetail.id)
          historyDataRef.value.querySuccessRateCompareList(props.configDetail.id)
        })
        state.num1++
      }
    }
    if (newVal.value === '2') {
      if (state.num2 === 0) {
        nextTick(() => {
          realTimeDataRef.value.getAvgPriceTrendDiagram(props.configDetail.id)
        })
        state.num2++
      }
    }
  },
  { deep: true, immediate: true }
)

onMounted(() => {
  state.num = 0
  state.num1 = 0
  state.num2 = 0
  activeName.value = '0'
})
</script>
<style lang="scss" scoped></style>
