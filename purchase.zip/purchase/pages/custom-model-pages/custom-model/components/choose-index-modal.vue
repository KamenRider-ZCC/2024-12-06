<template>
  <gl-modal
    v-model:visible="visible"
    class="choose-index-modal"
    title="添加指标"
    :width="1400"
    centered
    :maskClosable="false"
    @cancel="handleCancel"
  >
    <ms-table-transfer
      v-if="visible"
      ref="transferRef"
      :indexList="formState.indexList"
      :frequency="frequency"
    />

    <template #footer>
      <span class="tips">
        注意：请将无法选择的指标，在数据中心进行{{ frequency }}变频并收藏后，在我的收藏中进行添加
      </span>
      <gl-button @click="handleCancel">取消</gl-button>
      <gl-button type="primary" @click="handleOk">确定</gl-button>
    </template>
  </gl-modal>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import { MsTableTransfer } from '@mysteel-standard/components-business'
import { message } from 'gl-design-vue'
//props
interface Props {
  chooseIndexVisible: boolean
  chooseIndexForm: any
  frequency: any
}
const props = defineProps<Props>()
//emits
interface Emits {
  (e: 'update:chooseIndexVisible', val: boolean): void
  (e: 'choose-index'): void
}
const emits = defineEmits<Emits>()

const visible = computed({
  get() {
    return props.chooseIndexVisible
  },
  set(val: boolean) {
    emits('update:chooseIndexVisible', val)
  }
})
const formState = computed(() => props.chooseIndexForm)
//弹窗操作
const transferRef = ref()

const handleOk = () => {
  formState.value.indexList = transferRef.value.rightIndexList.map(
    (item: { code: string; label: string }) => ({
      indexCode: item.code,
      indexName: item.label,
      indexBaseType: '无类型'
    })
  )
  if (formState.value.indexList.length === 0) {
    message.warning('请选择指标')
    return
  }
  emits('choose-index')
  emits('update:chooseIndexVisible', false)
}
const handleCancel = () => {
  emits('update:chooseIndexVisible', false)
}
</script>

<style lang="scss" scoped>
.tips {
  float: left;
  color: #ed2222;
}
</style>
