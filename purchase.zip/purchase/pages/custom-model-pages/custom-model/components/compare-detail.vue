<template>
  <!-- <full-modal v-model:visible="state.detailVisible" :showSubmit="false"> -->
  <gl-modal
    v-model:visible="detailVisible"
    :maskClosable="false"
    :width="`${((1920 - 240) / 1920) * 100}vw`"
    wrap-class-name="full-modal"
    :footer="null"
    :closable="false"
  >
    <gl-spin :spinning="state.loading">
      <div class="bd compareDetailFullView">
        <div class="item-block form-model">
          <gl-form :label-col="{ style: { width: '100px' } }">
            <gl-row>
              <gl-col :span="12">
                <gl-form-item label="配置名称" name="name">
                  <span style="max-width: 300px">{{ configDetail.name }}</span>
                </gl-form-item>
                <gl-form-item label="品种" name="parentBreedName">
                  <span>{{ configDetail.parentBreedName }}</span>
                </gl-form-item>
                <gl-form-item label="细分品种" name="breedName">
                  <span>{{ configDetail.breedName }}</span>
                  <!-- <gl-radio-button :label="configDetail.breedName"></gl-radio-button> -->
                </gl-form-item>
              </gl-col>
              <gl-col :span="12">
                <gl-form-item label="区域" name="areaName">
                  <span>{{ configDetail.areaName }}</span>
                  <!-- <gl-radio-button :label="configDetail.areaName"></gl-radio-button> -->
                </gl-form-item>
                <gl-form-item label="执行机制" name="executeMechanism">
                  <span>
                    {{
                      configDetail.executeMechanism === 0
                        ? '单次执行'
                        : configDetail.forecastType === 2
                          ? '每周执行'
                          : '每月执行'
                    }}
                  </span>
                </gl-form-item>
              </gl-col>
            </gl-row>
          </gl-form>
        </div>
        <!-- <gl-divider /> -->
        <div class="item-block table-data">
          <div class="h4">
            <div class="line"></div>
            {{ compareParams.year }}年第{{ compareParams.week
            }}{{ configDetail.forecastType === 2 ? '周' : '月' }}
          </div>
          <gl-divider />
          <ul class="price-ul">
            <li
              class="price-li item-block"
              v-for="(item, index) in state.forecastPriceList"
              :key="index"
            >
              <p class="price-li-title">{{ item.title }}</p>
              <p class="price-li-data">
                <span v-if="item.thisRiseFall > 0" class="up">{{ item.thisPrice }}</span>
                <span v-else-if="item.thisRiseFall < 0" class="down">{{ item.thisPrice }}</span>
                <span v-else>{{ item.thisPrice }}</span>
                <span class="price-li-data-unit">{{ item.unit }}</span>
              </p>
              <gl-divider />
              <p class="updown-box">
                <span class="updown-riseFall-box">
                  <span class="riseFall-title"> 涨跌值 </span>
                  <span v-if="item.thisRiseFall > 0" class="up up-icon">
                    {{ item.thisRiseFall }}
                  </span>
                  <span v-else-if="item.thisRiseFall < 0" class="down down-icon">
                    {{ item.thisRiseFall }}
                  </span>
                  <span v-else>
                    {{ item.thisRiseFall }}
                    -
                  </span>
                </span>
                <span class="updown-gains-box">
                  <span class="riseFall-title"> 涨跌幅 </span>
                  <span v-if="item.thisRiseFall > 0" class="up up-icon">
                    {{ item.thisGains }}%
                  </span>
                  <span v-else-if="item.thisRiseFall < 0" class="down down-icon">
                    {{ item.thisGains }}%
                  </span>
                  <span v-else> {{ item.thisGains }}% - </span>
                </span>
              </p>
              <!-- <corners-border></corners-border> -->
            </li>
          </ul>
          <div class="h4">
            <div class="line"></div>
            模型因子对比
          </div>
          <gl-divider />
          <div class="compare-box">
            <div class="custom-factor">
              <h5 class="table-title">配置模型</h5>
              <gl-table
                :data-source="state.tableData1"
                :columns="columns"
                :pagination="false"
                row-key="id"
                ref="tableData1"
                :loading="state.loading"
                :scroll="{ y: 320 }"
                style="margin-right: 10px"
              >
              </gl-table>
            </div>
            <div class="machine-factor">
              <h5 class="table-title">线上模型</h5>
              <gl-table
                :data-source="state.tableData2"
                :columns="columns"
                :pagination="false"
                row-key="id"
                ref="tableData1"
                :loading="state.loading"
                :scroll="{ y: 320 }"
                style="margin-left: -2px; margin-right: -2px"
              >
              </gl-table>
            </div>
          </div>
        </div>
      </div>
    </gl-spin>
    <div class="btn-box">
      <slot name="ft">
        <gl-button class="btn-box-content" type="primary" @click="close">
          <icon name="icon-unselect_outlined" />
        </gl-button>
      </slot>
    </div>
  </gl-modal>
  <!-- </full-modal> -->
</template>
<script setup lang="ts">
import type { detailForm } from '../types/interface'
import api from '../api/index'
import { Icon } from '@mysteel-standard/components'
interface Props {
  visible: boolean
  configDetail: detailForm
  compareParams: object | any
}
const props = defineProps<Props>()
const state = reactive<any>({
  // detailVisible: true,
  loading: false,
  forecastPriceList: [],
  tableData1: [],
  loading1: false,
  tableData2: [],
  loading2: false
})
interface Emits {
  (e: 'update:visible', val: boolean): void
}
const emits = defineEmits<Emits>()
const detailVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})
const close = () => {
  detailVisible.value = false
}
const columns = reactive([
  {
    title: '最优模型因子名称',
    dataIndex: 'indexName',
    ellipsis: true,
    sorter: (a: any, b: any) => a.indexName.length - b.indexName.length
  },
  {
    title: '相关性系数',
    dataIndex: 'relativeCoefficient',
    ellipsis: true,
    sorter: (a: any, b: any) => a.relativeCoefficient - b.relativeCoefficient
  }
])
const queryForecastPriceDetail = async (params: any) => {
  state.forecastPriceList = []
  const typeList = ['factPrice', 'customPrice', 'machinePrice']
  for (const type of typeList) {
    const { res, err } = await api.queryForecastPriceDetail({
      dataDate: params.dataDate,
      configId: params.config.id,
      type: type
    })

    if (!err) {
      const { data }: any = res

      let title = ''
      if (type === 'factPrice') {
        title = '实际价格'
      } else if (type === 'customPrice') {
        title = '配置模型预测价格'
      } else if (type === 'machinePrice') {
        title = '线上模型预测价格'
      }
      data.title = title
      state.forecastPriceList.push(data)
    }
  }
}
const queryCustomFactor = async (params: any) => {
  state.loading1 = true

  const { res, err } = await api.queryCustomFactor({ configId: params.config.id })
  state.loading1 = false
  if (!err) {
    const { data } = res
    state.tableData1 = data
  }
}
const queryMachineFactor = async (params: any) => {
  state.loading2 = true

  const { res, err } = await api.queryMachineFactor({
    breedName: params.config.breedName,
    areaName: params.config.areaName,
    forecastType: 2
  })
  state.loading2 = false
  if (!err) {
    const { data } = res
    state.tableData2 = data
  }
}
watch(
  () => props.compareParams,
  (newVal) => {
    queryForecastPriceDetail(newVal)
    queryCustomFactor(newVal)
    queryMachineFactor(newVal)
  }
)
onMounted(() => {
  queryForecastPriceDetail(props.compareParams)
  queryCustomFactor(props.compareParams)
  queryMachineFactor(props.compareParams)
})
</script>
<style lang="scss" scoped>
@import '../style/index.scss';
.compareDetailFullView {
  .h4 {
    margin: 15px 0;
    line-height: 16px;
  }

  h5 {
    margin: 10px 0;
  }

  .compare-box {
    display: flex;
    justify-content: space-between;

    div {
      // width: calc(50% - 25px);
    }
  }

  .ft-box {
    padding: 6px 0 20px 0;
    position: fixed;
    right: 34px;
    z-index: 2;
  }

  .btn {
    width: 90px;
    height: 30px;
    line-height: 30px;
    border-radius: 2px;
    border: solid 1px #3f7ae7;
    text-align: center;
    float: left;
    font-size: 12px;
    cursor: pointer;
  }

  .cancel {
    background: #fff;
    color: #3f7ae7;
  }

  .submit {
    background: #3f7ae7;
    color: #fff;
    margin-left: 20px;
  }

  .btn-box {
    top: -48px;
    right: 33px;
  }
  .price-ul .price-li {
    width: 320px;
    height: 205px;
    display: inline-block;
    margin: 0 15px 15px 0;
    border: solid 1px var(--cyan, #1bc1ff);
    padding: 25px;
    font-size: 14px;
    .updown-gains-box {
      position: relative;
      margin-right: 14px;
      .riseFall-title {
        margin-right: 10px;
      }
    }
    .updown-riseFall-box {
      position: relative;
      .riseFall-title {
        margin-right: 10px;
      }
    }
    .price-li-data {
      font-size: 34px;
      margin: 20px 0;

      .price-li-data-unit {
        font-size: 12px;
      }
    }
    .updown-box {
      display: flex;
      justify-content: space-between;
    }
    .up-icon:before {
      content: '';
      position: absolute;
      right: -15px;
      top: 50%;
      transform: translateY(-50%);
      width: 0;
      height: 0;
      border-right: 5px solid transparent;
      border-left: 6px solid transparent;
      border-bottom: 6px solid #ea3b3b;
    }
    .up {
      color: #ea3b3b;
    }
    .down {
      color: #1eb348;
    }
    .down-icon:before {
      content: '';
      position: absolute;
      right: -15px;
      top: 50%;
      transform: translateY(-50%);
      width: 0;
      height: 0;
      border-right: 5px solid transparent;
      border-left: 6px solid transparent;
      border-top: 6px solid #1eb348;
    }
  }
  .line {
    float: left;
    width: 4px;
    height: 16px;
    background: var(--activeColor, #0090ff);
    margin-right: 8px;
  }
  .gl-divider-horizontal {
    margin: 15px 0;
  }
}
.table-title {
  color: #1890ff;
}
</style>
