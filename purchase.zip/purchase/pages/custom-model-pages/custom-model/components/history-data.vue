<template>
  <div class="historyData">
    <gl-spin :spinning="calculateLoading" tip="数据计算中，请等待！">
      <div v-if="!calculateLoading">
        <ul class="top-ul">
          <li class="item-block">
            <p class="li-title">配置模型绝对误差</p>
            <p class="li-data">
              {{ state.forecastDifference ? state.forecastDifference : '-' }}
            </p>
          </li>
          <li class="item-block">
            <div class="data-box">
              <p class="li-title">配置模型准确率</p>
              <p class="li-data">{{ state.customSuccessRate ? state.customSuccessRate : '-' }}%</p>
            </div>
            <div class="pie-chart">
              <ms-chart ref="basisChart1" autoresize class="chart" :option="chartOption1" />
            </div>
          </li>
          <li class="item-block">
            <div class="data-box">
              <p class="li-title">线上模型准确率</p>
              <p class="li-data">
                {{ state.machineSuccessRate ? state.machineSuccessRate : '-' }}%
              </p>
            </div>
            <div class="pie-chart">
              <ms-chart ref="basisChart2" autoresize class="chart" :option="chartOption2" />
            </div>
          </li>
        </ul>
        <div class="h4">
          <div class="line"></div>
          历史数据走势
        </div>
        <gl-divider />

        <div style="width: 100%; height: 300px">
          <ms-chart ref="basisChart3" autoresize class="chart" :option="chartOption3" />
        </div>
        <div class="h4">
          <div class="line"></div>
          准确率对比
        </div>
        <gl-divider />
        <gl-select class="year-select" v-model:value="state.year" placeholder="请选择">
          <gl-select-option v-for="(item, index) in state.years" :key="index" :value="item">
            {{ item }}
          </gl-select-option>
        </gl-select>
        <ul class="legend-ul">
          <li class="legend-li"><i class="red"></i>配置模型错误，线上模型准确</li>
          <li class="legend-li"><i class="green"></i>配置模型准确，线上模型错误</li>
          <li class="legend-li"><i class="yellow"></i>配置模型和线上模型都错误</li>
          <li class="legend-li"><i class="blue"></i>配置模型和线上模型都正确</li>
        </ul>
        <ul class="calendar-ul">
          <li class="calendar-li" v-for="(data, index) in state.dateList" :key="index">
            <div
              :class="genDetailCls(data.customSuccess, data.machineSuccess)"
              @click="compareDialog(data, index)"
            >
              <div class="calendar-title">
                <span class="week-text"
                  >第{{ index + 1 }}{{ configDetail.forecastType === 2 ? '周' : '月' }}</span
                >
                <span>{{ data.dataDateStart }}~{{ data.dataDateEnd }}</span>
              </div>
              <div class="calendar-date">
                <p>
                  <span class="title">实际价格</span>
                  <span class="price">{{ data.actPrice || '--' }}</span>
                </p>
                <p>
                  <span class="title">配置模型预测价格</span>
                  <span class="price">{{ data.customPrice || '--' }}</span>
                </p>
                <p>
                  <span class="title">线上模型预测价格</span>
                  <span class="price">{{ data.machinePrice || '--' }}</span>
                </p>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <CompareDetail
        v-if="compareVisible"
        :config-detail="configDetail"
        :compareParams="compareParams"
        v-model:visible="compareVisible"
      ></CompareDetail>
    </gl-spin>
  </div>
</template>

<script setup lang="ts">
import type { detailForm } from '../types/interface'
import { MsChart } from '@mysteel-standard/components'
import api from '../api/index'
import { getMultiChartOption } from '../hooks/use-multiChart-option'
import CompareDetail from '../components/compare-detail.vue'
interface Props {
  configDetail: detailForm
  calculateLoading: boolean
}
const props = defineProps<Props>()
const state = reactive({
  loading: false,
  forecastDifference: 0, // 配置模型绝对误差
  customSuccessRate: 0, // 自定义模型预测准确率
  machineSuccessRate: 0, // 线上预测准确率
  years: [],
  year: '',
  data: [],
  dateList: [],
  historyOption: {}
})
const chartOption1 = reactive({})
const chartOption2 = reactive({})
const chartOption3 = reactive({})
const compareVisible = ref(false)
const genDetailCls = computed((a: any, b: any) => {
  return function (a: any, b: any) {
    const obj = {
      red: a === -1 && b === 1,
      green: a === 1 && b === -1,
      yellow: a === -1 && b === -1,
      blue: a === 1 && b === 1
    }
    const targetColor = Object.entries(obj).find((item) => item[1] === true)

    return (targetColor && targetColor[0] + ' detail-color') || ''
  }
})

const querySuccessRateCompare = async (id: any) => {
  const { res, err } = await api.querySuccessRateCompare({ configId: id })

  if (!err) {
    const { data } = res
    state.forecastDifference = data.forecastDifference
    state.customSuccessRate = data.customSuccessRate
    state.machineSuccessRate = data.machineSuccessRate
    getAvgPriceTrendDiagramChart('customSuccessRate', data.customSuccessRate)
    getAvgPriceTrendDiagramChart('machineSuccessRate', data.machineSuccessRate)
  }
}
const getAvgPriceTrendDiagramChart = async (id: any, data: any) => {
  let option = {
    series: [
      {
        name: '任务进度',
        type: 'pie',
        radius: ['60%', '100%'],
        hoverAnimation: false,
        labelLine: {
          show: false
        },
        data: [
          {
            value: data,
            selected: false
          },
          {
            value: 100 - data,
            label: {
              normal: {
                show: false
              }
            },
            itemStyle: {
              normal: { color: '#EEEEEE' },
              emphasis: { color: '#EEEEEE' }
            }
          }
        ]
      }
    ],
    color: ['#01E6E3', '#EEEEEE']
  }
  if (id === 'customSuccessRate') {
    Object.assign(chartOption1, option)
  } else {
    Object.assign(chartOption2, option)
  }
}
const historyTrendDiagram = async (id: any) => {
  state.loading = true
  const { res, err } = await api.historyTrendDiagram({ configId: id })
  state.loading = false
  if (!err) {
    const { data } = res
    const dataList = data.list
    if (!dataList) {
      return
    }
    const unit: any = []
    const title = data.name
    const legend = dataList.map((v: any) => {
      unit.push(v.unit)
      return `${v.lineName}（${v.isLeft === 1 ? '左侧' : '右侧'}）`
    })
    const timeX = dataList[0].dataList.map((value: any) => value.dataDate)
    const dataArray = dataList.map((v: any) => v.dataList.map((value: any) => value.dataValue))
    const types = dataList.map((v: any) => v.type.toLocaleLowerCase())
    const yA = dataList.map((v: any) => (v.isLeft === 1 ? 0 : 1))
    Object.assign(
      chartOption3,
      getMultiChartOption(title, legend, timeX, unit[0], dataArray, types, yA)
    )
  }
}
const querySuccessRateCompareList = async (id: any) => {
  const { res, err } = await api.querySuccessRateCompareList({ configId: id })
  if (!err) {
    const { data } = res
    state.data = data
    state.years = data.map((item: any) => {
      return item.year
    })
    state.year = state.years[0]
  }
}
const compareParams = reactive({})
const compareDialog = (data: any, index: any) => {
  if (!data.customSuccess || !data.machineSuccess) return

  // state.$store.dispatch('changeCompareVisible', true)
  const params = {
    config: props.configDetail,
    dataDate: data.dataDate,
    week: index + 1,
    year: state.year
  }
  Object.assign(compareParams, params)
  compareVisible.value = true
  // this.$store.dispatch('changeCompareParams', params)
}
watch(
  () => state.year,
  (newVal) => {
    state.data.map((item: any) => {
      if (newVal === item.year) {
        state.dateList = item.dateList
      }
    })
  }
)
defineExpose({
  querySuccessRateCompare,
  querySuccessRateCompareList,
  historyTrendDiagram
})
</script>

<style lang="scss" scoped>
@import '../style/index.scss';
.historyData {
  min-height: 300px;

  .h4 {
    margin: 15px 0;
    line-height: 16px;
  }

  .year-select {
    width: 100px;
    float: right;
  }

  .legend-ul {
    min-height: 28px;
    display: flex;
    justify-content: center;

    .legend-li {
      display: flex;
      font-size: 12px;
      margin-right: 20px;
      align-items: center;
      float: left;
    }

    i {
      display: inline-block;
      width: 14px;
      height: 14px;
      border-radius: 2px;
      margin-right: 5px;
    }
  }

  .red {
    background: #d61414;
    border-color: #d61414 !important;
    .calendar-title {
      background: #e43a3a;
    }
  }

  .green {
    background: #01884b;
    border-color: #01884b !important;
    .calendar-title {
      background: #079a58;
    }
  }

  .yellow {
    background: #e2801d;
    border-color: #e2801d !important;
    .calendar-title {
      background: #ec8c2b;
    }
  }

  .blue {
    background: #0086ee;
    border-color: #0086ee !important;
    .calendar-title {
      background: #0090ff;
    }
  }

  .calendar-ul {
    margin-top: 20px;
    margin-left: 8px;
    margin-right: -12px;

    .calendar-li {
      display: inline-block;
      width: 220px;
      margin: 0 20px 20px 0;
      font-size: 14px;
      text-align: center;

      & > div {
        height: 100%;
        border: solid 1px #1bc1ff;
        color: #1bc1ff;
        border-radius: 6px;
        overflow: hidden;
      }

      .detail-color {
        cursor: pointer;
        color: #ffffff;
      }

      .calendar-title {
        height: 30px;
        line-height: 30px;
        font-size: 12px;
        display: flex;
        .week-text {
          margin-left: 20px;
          margin-right: 10px;
        }
      }

      .calendar-date {
        font-size: 12px;
        padding: 10px 10px 16px;
        p {
          line-height: 22px;
          display: flex;
        }
        .title {
          width: 100px;
          text-align: right;
          margin-left: 10px;
        }
        .price {
          flex: 1;
          text-align: center;
        }
      }
    }
  }
  .line {
    float: left;
    width: 4px;
    height: 16px;
    background: var(--activeColor, #0090ff);
    margin-right: 8px;
  }
}
:deep(.gl-spin-dot) {
  margin-top: 100px;
}
.gl-spin-spinning {
  width: 100%;
  height: 100%;
}
</style>
