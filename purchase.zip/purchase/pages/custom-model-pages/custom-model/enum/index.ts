import { createEnum } from '@mysteel-standard/utils'
export const RUN_STATE_TEXT = createEnum({
  UNCOMPUTED: [0, '未计算'],
  COMPUTING: [1, '计算中'],
  COMPLETED: [2, '计算完成'],
  FAIL: [3, '计算失败'],
})
export const STATUS = createEnum({
  UNRUNNING: [0, '禁用'],
  RUNING: [1, '启用'],
 
})
export const EXECUTE_MECHANISM = createEnum({
  SINGLE: [0, '单次执行'],
  DOUBLE: [1, '每周执行'],
 
})
// export const FORECAST_TYPE = createEnum({
//   week: [2, '周度'],
//   month: [3, '月度'],
 
// })
export const IS_PUBLIC = createEnum({
  PERSON: [0, '非公开'],
  PUBLIC: [1, '公开'],
 
})

