<template>
  <div class="system-management-company-wrap">
    <div class="search-container">
      <div class="search-form">
        <openSearchForm @search="handleSearch" :isPublic="1" />
      </div>
    </div>
    <div class="table-container">
      <gl-table
        :loading="tableLoading"
        :data-source="tableData"
        :columns="columns"
        :pagination="false"
        row-key="id"
      >
        <template v-slot:bodyCell="{ column, record }">
          <template v-if="column.dataIndex === 'action'">
            <a @click="detail(record)">查看详情</a>
          </template>
          <template v-if="column.dataIndex === 'successRate'">
            <span>{{ record.successRate ? record.successRate + '%' : '-' }}</span>
          </template>
          <template v-if="column.dataIndex === 'forecastType'">
            <span>{{ record.forecastType === 2 ? '周度' : '月度' }}</span>
          </template>
        </template>
      </gl-table>
    </div>
    <div class="pagination">
      <Pagination v-model:page="page" @page-change="handlePageChange" />
    </div>
    <PublicModelDetail
      v-if="detailVisible"
      v-model:visible="detailVisible"
      :configDetail="configDetail"
      :calculateLoading="calculateLoading"
    />
  </div>
</template>
<script setup lang="ts">
// import {} from './interface'
import { Pagination } from '@mysteel-standard/components'
import api from './api/index'
import openSearchForm from './components/open-search-form.vue'
import PublicModelDetail from './components/public-model-detail.vue'
import { useTableData } from '@mysteel-standard/hooks'

const columns = reactive([
  {
    title: '排名',
    dataIndex: 'num',
    ellipsis: true
  },
  {
    title: '准确率',
    dataIndex: 'successRate',
    ellipsis: true
  },
  {
    title: '配置名称',
    dataIndex: 'name',
    ellipsis: true
  },

  {
    title: '品种',
    dataIndex: 'parentBreedName',
    ellipsis: true
  },

  {
    title: '细分品种',
    dataIndex: 'breedName',
    ellipsis: true
  },

  {
    title: '区域',
    dataIndex: 'areaName',
    ellipsis: true
  },

  {
    title: '频度',
    dataIndex: 'forecastType',
    ellipsis: true
  },

  {
    title: '固定因子数',
    dataIndex: 'constantIndexNum',
    ellipsis: true
  },

  {
    title: '模型归属人',
    dataIndex: 'createUserName',
    ellipsis: true
  },

  {
    title: '操作',
    dataIndex: 'action'
  }
])
const detailVisible = ref(false)

const configDetail = reactive<any>({})
const { getList, handlePageChange, handleSearch, tableData, tableLoading, page } = useTableData({
  tableApi: api.selectConfigListByPage
})
const detail = async (record: any) => {
  const { res, err } = await api.configDetail({ configId: record.id })
  if (!err) {
    const { data } = res
    detailVisible.value = true
    Object.assign(configDetail, data)
    queryCalculateCompletes(record)
  }
}
const calculateLoading = ref(false)
const queryCalculateCompletes = async (record: any) => {
  const { res, err } = await api.queryCalculateComplete({ configId: record.id })
  if (!err) {
    calculateLoading.value = !res.data.complete
    // this.$store.dispatch('changeCalculateLoading', !res.data.complete)
  }
}
</script>

<style lang="scss" scoped>
@import './style/index.scss';
</style>
