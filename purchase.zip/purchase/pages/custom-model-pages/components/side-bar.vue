<template>
  <div class="side-bar">
    <gl-menu
      v-model:selectedKeys="selectedKeys"
      v-model:openKeys="openKeys"
      theme="dark"
      mode="inline"
    >
      <gl-sub-menu key="1">
        <template #title>自定义模型</template>
        <template v-for="item in leftNavList" :key="item.id">
          <gl-menu-item class="menu-item-default" @click="handleClick(item)">
            <span class="name">{{ item.moduleName }}</span>
          </gl-menu-item>
        </template>
      </gl-sub-menu>
    </gl-menu>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
interface Props {
  modelTreeid: number
}
const props = defineProps<Props>()
interface Emits {
  (e: 'childSec', item: any): void
}
const emits = defineEmits<Emits>()

const selectedKeys = ref<string[]>([])
const openKeys = ref<string[]>([])
const leftNavList: any = ref([
  {
    moduleName: '公开模型',
    id: '2'
  },
  {
    moduleName: '个人模型',
    id: '3'
  }
])

//菜单点击
const handleClick = (item: any) => {
  emits('childSec', item)
}
watch(
  () => props.modelTreeid,
  (val) => {
    if (val === 1) {
      selectedKeys.value = ['2']
    } else {
      selectedKeys.value = ['3']
    }
  },
  { deep: true, immediate: true }
)

onMounted(() => {
  openKeys.value = ['1']
  selectedKeys.value = [leftNavList.value[0].id]
})
</script>

<style lang="scss" scoped></style>
