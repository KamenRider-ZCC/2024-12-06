/// <reference types="vite/client" />
declare module '*.vue' {
  import { defineComponent } from 'vue'
  const Component: ReturnType<typeof defineComponent>
  export default Component
}

declare module 'gl-design-vue'
declare module '@mysteel-standard/components'
declare module '@mysteel-standard/hooks'
declare module 'lodash'
declare module 'moment'