<template>
  <div class="month-visit">
    <MSTitle title="本月访问次数" />
    <gl-radio-group class="type-radio" v-model:value="radioType" @change="handleChange">
      <gl-radio-button :value="0">本月访问</gl-radio-button>
      <gl-radio-button :value="1">累计访问</gl-radio-button>
    </gl-radio-group>
    <data-item
      v-if="type === 0"
      :data="{
        visit: monthVisitData.visitNumber,
        qoq: monthVisitData.qoq,
        yoy: monthVisitData.yoy
      }"
    />
    <div v-else class="total">
      访问量：<span>{{ monthVisitData.total }}</span>
    </div>
    <ms-chart v-if="radioType === 0" class="chart" :option="monthVisitData.barOption" autoresize />
    <ms-chart v-else class="chart" :option="monthVisitData.lineOption" autoresize />
  </div>
</template>
<script setup lang="ts">
import { MSTitle } from '@mysteel-standard/components'
import { MsChart } from '@mysteel-standard/components'
import DataItem from './data-item.vue'
import { computed } from 'vue'

interface Props {
  monthVisitData: any
  type: number
}
const props = defineProps<Props>()

interface Emits {
  (e: 'change-type', val: number): void
  (e: 'update:type', val: any): void
}
const emits = defineEmits<Emits>()

const radioType = computed({
  get() {
    return props.type
  },
  set(val: number) {
    emits('update:type', val)
  }
})

const handleChange = (e: any) => {
  emits('change-type', e.target.value)
}
</script>
<style lang="scss" scoped>
.type-radio {
  position: absolute;
  top: 7px;
  right: 12px;
}
.total {
  border-bottom: 1px solid #e8e8e8;
  height: 46px;
  padding: 10px 28px;
  display: flex;
  align-items: center;
  font-size: 14px;
  > span {
    font-size: 24px;
    line-height: 28px;
    font-weight: 600;
  }
}
</style>
