<template>
  <div class="login-table">
    <MSTitle title="登录详情" />
    <div class="table-container">
      <ms-table
        :data="tableData"
        :columns="columns"
        :scroll="{ y: 284 }"
        :pagination="false"
        :rowKey="(record: any) => record.id"
        @handleClick="handleClick"
      ></ms-table>
    </div>

    <user-detail
      v-model:visible="visible"
      title="人员使用情况"
      :tableData="detailData"
      :userName="userName"
      :tableLoading="detailLoading"
    />
  </div>
</template>
<script setup lang="ts">
import { MSTitle } from '@mysteel-standard/components'
import { MsTable } from '@mysteel-standard/components'
import { ref, computed } from 'vue'
import { uniq } from 'lodash'
import UserDetail from './user-detail.vue'
import api from '../../api'
import { Form } from '../types/interface'

interface Props {
  loginTableData: any
  searchForm: Form
}
const props = defineProps<Props>()

const tableData = computed(() => props.loginTableData.tableData)
const userFilters = computed(() => {
  const users = uniq(tableData.value.map((item: any) => item.userName)).filter((i: any) => !!i)
  return users.map((item: any) => {
    return {
      text: item,
      value: item
    }
  })
})
const departmentFilters = computed(() => {
  const departments = uniq(tableData.value.map((item: any) => item.userDepartment)).filter(
    (i: any) => !!i
  )
  return departments.map((item: any) => {
    return {
      text: item,
      value: item
    }
  })
})
const columns = computed(() => [
  {
    title: '登录时间',
    dataIndex: 'loginTime',
    sorter: (a: any, b: any) => Date.parse(a.loginTime) - Date.parse(b.loginTime),
    align: 'center'
  },
  {
    title: '登录人',
    dataIndex: 'userName',
    type: 'textButton',
    filters: userFilters.value,
    onFilter: (value: any, record: any) => record.userName === value,
    filterSearch: true,
    align: 'center'
  },
  {
    title: '部门',
    dataIndex: 'userDepartment',
    align: 'center',
    type: 'function',
    callback: (record: any) => {
      return record.userDepartment || '--'
    },
    filters: departmentFilters.value,
    onFilter: (value: any, record: any) => record.userDepartment === value,
    filterSearch: true
  },
  {
    title: 'IP',
    dataIndex: 'ipAddress',
    align: 'center',
    type: 'function',
    callback: (record: any) => {
      return record.ipAddress || '--'
    }
  },
  {
    title: 'IP所属地',
    dataIndex: 'loginAddress',
    align: 'center',
    type: 'function',
    callback: (record: any) => {
      return record.loginAddress || '--'
    }
  }
])

const visible = ref(false)
const userName = ref('')
const detailData = ref([])
const detailLoading = ref(false)

const handleClick = async (record: any) => {
  visible.value = true
  userName.value = record.userName
  const params = {
    userName: record.userName,
    loginLogId: record.id,
    dateFrom: props.searchForm.date[0],
    dateTo: props.searchForm.date[1]
  }
  detailLoading.value = true
  const { res, err } = await api.getUserUseDetail(params)
  detailLoading.value = false
  if (res && !err) {
    detailData.value = res.data
  } else {
    detailData.value = []
  }
}
</script>
<style lang="scss" scoped>
.table-container {
  padding: 12px;
  height: 100%;
}
</style>
