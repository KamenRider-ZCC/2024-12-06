<template>
  <div class="visit-sort">
    <MSTitle title="活跃时间分布" />
    <ms-chart class="chart" :option="onlineChartData.option" autoresize />
  </div>
</template>
<script setup lang="ts">
import { MSTitle } from '@mysteel-standard/components'
import { MsChart } from '@mysteel-standard/components'

interface Props {
  onlineChartData: any
}
const props = defineProps<Props>()
</script>
<style lang="scss" scoped></style>
