<template>
  <div class="user-visit">
    <MSTitle title="本月用户访问量" />
    <data-item
      :data="{
        visit: userVisitData.visitNumber,
        qoq: userVisitData.qoq,
        yoy: userVisitData.yoy
      }"
    />
    <ms-chart class="chart" :option="userVisitData.option" autoresize />
  </div>
</template>
<script setup lang="ts">
import { MSTitle } from '@mysteel-standard/components'
import { MsChart } from '@mysteel-standard/components'
import DataItem from './data-item.vue'

interface Props {
  userVisitData: any
}
const props = defineProps<Props>()
</script>
<style lang="scss" scoped></style>
