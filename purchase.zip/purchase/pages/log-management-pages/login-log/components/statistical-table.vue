<template>
  <div class="statistical-table">
    <MSTitle title="功能使用统计" />
    <div class="table-container">
      <ms-table
        :data="tableData"
        :columns="columns"
        :scroll="{ y: 284 }"
        :pagination="false"
        :rowKey="(record: any) => record.id"
        @handleClick="handleClick"
      ></ms-table>
    </div>

    <module-detail
      v-model:visible="visible"
      title="功能使用详情"
      :tableData="detailData"
      :tableLoading="detailLoading"
      :searchForm="searchForm"
      :moduleName="moduleName"
    />
  </div>
</template>
<script setup lang="ts">
import { MSTitle } from '@mysteel-standard/components'
import { MsTable } from '@mysteel-standard/components'
import { ref, computed } from 'vue'
import { uniq } from 'lodash'
import ModuleDetail from './module-detail.vue'
import api from '../../api'
import { Form } from '../types/interface'

interface Props {
  statisticalTableData: any
  searchForm: Form
}
const props = defineProps<Props>()

const tableData = computed(() => props.statisticalTableData.tableData)
const moduleNameFilters = computed(() => {
  const moduleNames = uniq(tableData.value.map((item: any) => item.moduleName)).filter(
    (i: any) => !!i
  )
  return moduleNames.map((item: any) => {
    return {
      text: item,
      value: item
    }
  })
})
const columns = computed(() => [
  {
    title: '排名',
    // dataIndex: 'sort',
    dataIndex: 'index',
    align: 'center',
    width: 80
  },
  {
    title: '功能模块',
    dataIndex: 'moduleName',
    type: 'textButton',
    filters: moduleNameFilters.value,
    onFilter: (value: any, record: any) => record.moduleName.startsWith(value),
    filterSearch: true,
    align: 'center',
    width: '50%'
  },
  {
    title: '使用账号',
    dataIndex: 'loginNum',
    sorter: (a: any, b: any) => a.loginNum - b.loginNum,
    align: 'center'
  },
  {
    title: '使用次数',
    dataIndex: 'useCount',
    sorter: (a: any, b: any) => a.useCount - b.useCount,
    align: 'center'
  }
])

const visible = ref(false)
const detailData = ref([])
const detailLoading = ref(false)
const moduleName = ref('')

const handleClick = async (record: any) => {
  visible.value = true
  moduleName.value = record.moduleName
  const params = {
    moduleName: record.moduleName
  }
  detailLoading.value = true
  const { res, err } = await api.getModuleUseDetail(params)
  detailLoading.value = false
  if (res && !err) {
    detailData.value = res.data
  } else {
    detailData.value = []
  }
}
</script>
<style lang="scss" scoped>
.table-container {
  padding: 12px;
  height: 100%;
}
</style>
