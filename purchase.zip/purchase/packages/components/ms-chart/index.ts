/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-15 19:40:04
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-06-19 11:21:50
 * @Description: echart图
 */
import ECharts from 'vue-echarts'
import { UniversalTransition, LabelLayout } from 'echarts/features'
import * as echarts from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import * as chinaJson from'./china.json'

import { BarChart, LineChart, RadarChart, PieChart, ScatterChart, GaugeChart,EffectScatterChart } from 'echarts/charts'


import {
  GridComponent,
  TooltipComponent,
  LegendComponent,
  TitleComponent,
  BrushComponent,
  VisualMapComponent,
  ToolboxComponent,
  DataZoomComponent,
  GraphicComponent,
  MarkLineComponent,
  MarkAreaComponent,
  DatasetComponent,
  TransformComponent,
  GeoComponent 
} from 'echarts/components'

echarts.use([
  CanvasRenderer,
  BarChart,
  LineChart,
  GridComponent,
  TooltipComponent,
  LegendComponent,
  TitleComponent,
  BrushComponent,
  VisualMapComponent,
  RadarChart,
  PieChart,
  ToolboxComponent,
  DataZoomComponent,
  GraphicComponent,
  MarkLineComponent,
  MarkAreaComponent,
  DatasetComponent,
  ScatterChart,
  UniversalTransition,
  LabelLayout,
  TransformComponent,
  GaugeChart,
  GeoComponent,
  EffectScatterChart
])
echarts.registerMap('china',chinaJson)
export const MsChart = ECharts
