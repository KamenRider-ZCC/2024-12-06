import XEUtils from 'xe-utils'
import { h, App } from 'vue'
import { Empty } from 'gl-design-vue'
import 'vxe-table/styles/index.scss'
const { PRESENTED_IMAGE_SIMPLE } = Empty
import {
  // 全局对象
  VXETable,

  // 表格功能
  // Footer,
  // Icon,
  // Filter,
  // Edit,
  // Menu,
  // Export,
  // Keyboard,
  // Validator,

  // 可选组件
  Column,
  // Colgroup,
  // Grid,
  Tooltip,
  // Toolbar,
  // Pager,
  // Form,
  // FormItem,
  // FormGather,
  // Checkbox,
  // CheckboxGroup,
  // Radio,
  // RadioGroup,
  // RadioButton,
  // Switch,
  // Input,
  // Select,
  // Optgroup,
  // Option,
  // Textarea,
  // Button,
  // Modal,
  // List,
  // Pulldown,

  // 表格
  Table
} from 'vxe-table'
import zhCN from 'vxe-table/es/locale/lang/zh-CN'
// 按需加载的方式默认是不带国际化的，自定义国际化需要自行解析占位符 '{0}'，例如：
VXETable.setup({
  i18n: (key, args) => XEUtils.toFormatString(XEUtils.get(zhCN, key), args),
  icon: {
    // table
    TABLE_SORT_ASC: 'vxe-icon-caret-up',
    TABLE_SORT_DESC: 'vxe-icon-caret-down',
    TABLE_FILTER_NONE: 'vxe-icon-funnel',
    TABLE_FILTER_MATCH: 'vxe-icon-funnel',
    TABLE_EDIT: 'vxe-icon-edit',
    TABLE_HELP: 'vxe-icon-question-circle-fill',
    TABLE_TREE_LOADED: 'vxe-icon-spinner roll',
    TABLE_TREE_OPEN: 'vxe-icon-caret-right rotate90',
    TABLE_TREE_CLOSE: 'vxe-icon-caret-right',
    TABLE_EXPAND_LOADED: 'vxe-icon-spinner roll',
    TABLE_EXPAND_OPEN: 'vxe-icon-arrow-right rotate90',
    TABLE_EXPAND_CLOSE: 'vxe-icon-arrow-right',
    TABLE_CHECKBOX_CHECKED: 'vxe-icon-checkbox-checked',
    TABLE_CHECKBOX_UNCHECKED: 'vxe-icon-checkbox-unchecked',
    TABLE_CHECKBOX_INDETERMINATE: 'vxe-icon-checkbox-indeterminate',
    TABLE_RADIO_CHECKED: 'vxe-icon-radio-checked',
    TABLE_RADIO_UNCHECKED: 'vxe-icon-radio-unchecked'
  }
})

// 创建一个空内容渲染
VXETable.renderer.add('NotData', {
  // 空内容模板
  renderEmpty(renderOpts, params) {
    return [h(Empty, { image: PRESENTED_IMAGE_SIMPLE })]
  }
})

export const VxeTable = (app: App) => {
  // 表格功能
  app
    // .use(Footer)
    // .use(Icon)
    // .use(Filter)
    // .use(Edit)
    // .use(Menu)
    // .use(Export)
    // .use(Keyboard)
    // .use(Validator)

    // 可选组件
    .use(Column)
    // .use(Colgroup)
    // .use(Grid)
    .use(Tooltip)
    // .use(Toolbar)
    // .use(Pager)
    // .use(Form)
    // .use(FormItem)
    // .use(FormGather)
    // .use(Checkbox)
    // .use(CheckboxGroup)
    // .use(Radio)
    // .use(RadioGroup)
    // .use(RadioButton)
    // .use(Switch)
    // .use(Input)
    // .use(Select)
    // .use(Optgroup)
    // .use(Option)
    // .use(Textarea)
    // .use(Button)
    // .use(Modal)
    // .use(List)
    // .use(Pulldown)

    // 安装表格
    .use(Table)
}
