<template>
  <div class="table_operation">
    <template v-if="operations.length <= count">
      <a v-for="(item, index) in operations" :key="index">
        <span v-if="item.label !== '删除'" @click="item.handle">{{ item.label }}</span>
        <gl-popconfirm v-else title="确定删除吗?" @confirm="item.handle">
          {{ item.label }}
        </gl-popconfirm>
      </a>
    </template>
    <template v-else>
      <a
        v-for="(item, index) in operations.slice(0, spliceCount)"
        :key="index"
        @click="item.handle"
      >
        {{ item.label }}
      </a>
      <gl-popover overlay-class-name="table_popover" trigger="hover" placement="bottom">
        <template #content>
          <div
            v-for="(item, index) in operations.slice(spliceCount)"
            :key="index"
            @click="item.handle"
          >
            <a>{{ item.label }}</a>
          </div>
        </template>
        <a>
          <!-- <img style="width: 12px; height: 12px" src="@/assets/images/svg/dot.svg" alt="" /> -->
        </a>
      </gl-popover>
    </template>
  </div>
</template>

<script setup lang="ts">
// import { useStore } from 'vuex'
interface Props {
  list: Array<object>
  count: number
}
const props = defineProps<Props>()
interface Emits {
  (e: 'delete', val: object): void
}
const emits = defineEmits<Emits>()
const spliceCount = computed(() => props.count - 1)

// const store = useStore()

const operations = computed(() => {
  // const { btnPermit } = store.state.menu
  // const oList = props.list.filter(
  //   (item: { permit: boolean }) => !item.permit || btnPermit.includes(item.permit)
  // )
  return props.list
})
//删除
const handleDelete = (id: number) => {
  const params = { id }
  emits('delete', params)
}
</script>
<style lang="scss">
.table_operation {
  display: flex;
  align-items: center;
}

.table_operation a {
  margin-right: 15px;
}
</style>
