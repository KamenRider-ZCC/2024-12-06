<template>
  <a v-if="value" class="blue" @click="handleClick(record)" :title="value">
    {{ value }}
  </a>
  <span v-else class="blue"> -- </span>
</template>

<script setup lang="ts">
interface Props {
  value: string | number
  record: Object
}
defineProps<Props>()
interface Emits {
  (e: 'handle-click', record: Object): void
}
const emits = defineEmits<Emits>()
const handleClick = (record: Object) => {
  emits('handle-click', record)
}
</script>

<style scoped></style>
