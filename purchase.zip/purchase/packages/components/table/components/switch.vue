<!--
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-31 10:01:36
 * @Description: 
-->
<template>
  <div class="switch-status" v-if="checkPermit(column.permit && [column.permit])">
    <gl-switch
      v-model:checked="switchValue"
      :checked-value="1"
      :un-checked-value="0"
      :disabled="(column.disabled && column.disabled(record)) || false"
      @change="handleSwitchChange(record)"
    />
    <span class="text">{{ switchValue ? '已开启' : '已禁用' }}</span>
  </div>
</template>

<script setup lang="ts">
import { checkPermit } from '@mysteel-standard/hooks'
import { computed } from 'vue'
interface Props {
  value: number
  record: Object
  column: { disabled?: Function; permit?: string }
}
const props = defineProps<Props>()
interface Emits {
  (e: 'update:value', val: number): void
  (e: 'switch-change', record: Object): void
}
const emits = defineEmits<Emits>()
const switchValue = computed({
  get() {
    return props.value
  },
  set(val: number) {
    emits('update:value', val)
  }
})
const handleSwitchChange = (record: Object) => {
  emits('switch-change', record)
}
</script>

<style scoped lang="scss">
.switch-status .text {
  margin-left: 5px;
}
</style>
