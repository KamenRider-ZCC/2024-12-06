<template>
  <div v-html="column.callback(record, column)"></div>
</template>
<script setup lang="ts">
interface Props {
  record: Object
  column: { callback: Function }
}
defineProps<Props>()
</script>

<style scoped></style>
