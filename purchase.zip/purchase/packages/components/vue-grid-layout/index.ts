/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-19 15:55:49
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-02 14:01:37
 * @Description:
 */
import gridLayout from 'vue-grid-layout'

export const VueGridLayout = gridLayout
