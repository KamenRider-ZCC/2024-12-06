export { default as MsMenu } from './index.vue'
