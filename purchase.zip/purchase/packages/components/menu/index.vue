<!--
 * @Autor: zhouwanwan
 * @Date: 2023-08-11 11:20:25
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-17 14:58:43
 * @Description: 带图标菜单
-->
<template>
  <gl-menu v-bind="$attrs" class="ms-menu">
    <gl-sub-menu v-for="item in menuData" :key="item.id" popupClassName="sub-menu-pop">
      <template #icon>
        <slot name="icon" :item="item"></slot>
      </template>
      <template #title>{{ item.name }}</template>
      <template v-if="item.children && item.children.length">
        <gl-menu-item v-for="child in item.children" :key="child.id">
          {{ child.name }}
        </gl-menu-item>
      </template>
    </gl-sub-menu>
  </gl-menu>
</template>
<script setup lang="ts">
interface Props {
  menuData: any[]
}
defineProps<Props>()
</script>
<style lang="scss">
.sub-menu-pop {
  .gl-menu:not(.gl-menu-horizontal) .gl-menu-item-selected {
    background: none !important;
  }
}
</style>
<style lang="scss" scoped>
@import './menu.scss';
</style>
