/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-15 21:13:40
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-06-15 21:13:58
 * @Description:
 */
export { default as ColorInput } from './index.vue'
