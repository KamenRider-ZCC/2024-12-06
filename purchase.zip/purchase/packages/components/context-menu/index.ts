/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-26 19:37:35
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-06-26 20:01:00
 * @Description: 右键菜单指令
 */
import Contextmenu from './menu/menu-content'

export default {
  install(app: any) {
    app.directive('contextmenu', Contextmenu)
  }
}
