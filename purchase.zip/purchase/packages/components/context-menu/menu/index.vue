/* @author: cyx14998 * @since: 2022-06-24 */
<template>
  <div>
    <div
      class="mask"
      @contextmenu.prevent="removeContextmenu()"
      @mousedown="removeContextmenu()"
    ></div>
    <div
      ref="contextmenu"
      class="contextmenu"
      :style="{
        left: style?.left + 'px',
        top: style?.top + 'px'
      }"
      @contextmenu.prevent
    >
      <MenuContent :menus="menus" :handle-click-menu-item="handleClickMenuItem" />
    </div>
  </div>
</template>

<script setup lang="ts">
import MenuContent from './menu-content.vue'

const props = defineProps({
  axis: {
    type: Object,
    required: true
  },
  el: {
    type: Object,
    required: true
  },
  menus: {
    type: Array,
    required: true
  },
  removeContextmenu: {
    type: Function,
    required: true
  }
})
const style = ref({
  left: -9999,
  top: -9999
})
const contextmenu = ref()
nextTick(() => {
  // 给个默认值，以防出现菜单不出现的情况
  const MENU_WIDTH = 170
  const MENU_HEIGHT = 30
  const DIVIDER_HEIGHT = 11
  const PADDING = 5

  const { x, y } = props.axis
  const menuCount = props.menus.filter((menu: any) => !(menu.divider || menu.hide)).length
  const dividerCount = props.menus.filter((menu: any) => menu.divider).length

  const menuWidth = contextmenu?.value?.clientWidth || MENU_WIDTH
  const menuHeight =
    contextmenu?.value?.clientHeight ||
    menuCount * MENU_HEIGHT + dividerCount * DIVIDER_HEIGHT + PADDING * 2

  const screenWidth = document.body.clientWidth
  const screenHeight = document.body.clientHeight

  style.value = {
    left: screenWidth <= x + menuWidth ? x - menuWidth : x,
    top: screenHeight <= y + menuHeight ? y - menuHeight : y
  }
})

const handleClickMenuItem = (item: any) => {
  if (item.disable) return
  if (item.children && !item.handler) return
  if (item.handler) item.handler(props.el)
  props.removeContextmenu()
}
</script>

<style lang="scss">
.mask {
  position: fixed;
  left: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  z-index: 9998;
}
.contextmenu {
  position: fixed;
  z-index: 9999;
  user-select: none;
}
</style>
