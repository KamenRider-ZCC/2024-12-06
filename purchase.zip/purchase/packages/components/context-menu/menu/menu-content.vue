<template>
  <ul class="menu-content">
    <template v-for="(menu, index) in menus">
      <li
        v-if="!menu.hide"
        :key="menu.text || index"
        class="menu-item"
        :class="{
          divider: menu.divider,
          disable: menu.disable,
          active: !menu.disable && menu.childShow
        }"
        @click.stop="handleClickMenuItem(menu)"
        @mouseenter="menuEnter(menu)"
        @mouseleave="menuLeave(menu)"
      >
        <div
          v-if="!menu.divider"
          class="menu-item-content"
          :class="{
            'has-children': menu.children,
            'has-handler': menu.handler
          }"
        >
          <span class="text">{{ menu.text }}</span>
          <span v-if="menu.subText && !menu.children" class="sub-text">{{ menu.subText }}</span>

          <menu-content
            v-if="menu.children && menu.children.length"
            class="sub-menu"
            :class="{ show: menu.childShow }"
            :menus="menu.children"
            :handle-click-menu-item="handleClickMenuItem"
          />
        </div>
      </li>
    </template>
  </ul>
</template>

<script setup lang="ts">
interface Props {
  menus: any[]
  handleClickMenuItem: any
}

const props = defineProps<Props>()

// 移入子菜单的延时时间
const moveDelay = 100

// 鼠标移入菜单
const menuEnter = (menu: {
  childShow: boolean
  setTimeoutC: string | number | NodeJS.Timeout | null | undefined
}) => {
  // 清除所有的移入状态
  props.menus.map((item: any) => {
    item.childShow = false
  })
  menu.childShow = true

  // 清除定时器
  if (menu.setTimeoutC) {
    clearTimeout(menu.setTimeoutC)
    menu.setTimeoutC = null
  }
}

// 鼠标移出菜单
const menuLeave = (menu: {
  children: string | any[]
  childShow: boolean
  setTimeoutC: string | number | NodeJS.Timeout | null | undefined
}) => {
  if (menu.children && menu.children.length) {
    if (!menu.childShow) return

    // 如果移入子菜单则给个延时效果
    menu.setTimeoutC = setTimeout(() => {
      menu.childShow = false
    }, moveDelay)
  } else {
    menu.childShow = false

    // 清除定时器
    if (menu.setTimeoutC) {
      clearTimeout(menu.setTimeoutC)
      menu.setTimeoutC = null
    }
  }
}
</script>

<style lang="scss" scoped>
$menuWidth: 170px;
$menuHeight: 30px;
$subMenuWidth: 120px;
$themeColor: #f5f5f5;
$textColor: #41464b;
$borderColor: #eee;
$lightGray: #f9f9f9;
$boxShadow: 3px 3px 3px rgba(0, 0, 0, 0.15);
$transitionDelay: 0.2s;
$transitionDelayFast: 0.1s;
$transitionDelaySlow: 0.3s;
$borderRadius: 2px;

.menu-content {
  // width: @menuWidth;
  border-radius: 2px;
  outline: none;
  padding: 4px 0;
  background: #fff;
  // border: 1px solid #dddddd;
  // box-shadow: @boxShadow;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  border-radius: 2px;
  list-style: none;
  margin: 0;
}
.menu-item {
  padding: 5px 12px;
  color: rgba(0, 0, 0, 0.85);
  font-size: 14px;
  transition: all $transitionDelayFast;
  white-space: nowrap;
  // height: @menuHeight;
  // line-height: @menuHeight;
  background-color: #fff;
  cursor: pointer;
  position: relative;

  &:not(.disable):hover > .menu-item-content > .sub-menu {
    display: block;
  }

  &:not(.disable):hover > .has-children.has-handler::after {
    transform: scale(1);
  }

  &.active {
    // color: #fff;
    background-color: $themeColor;

    .sub-menu {
      display: block;
    }

    // .menu-item-content {
    //   &.has-children::before {
    //     border-color: #fff #fff transparent transparent;
    //   }
    // }
  }

  &.divider {
    height: 1px;
    overflow: hidden;
    margin: 5px;
    background-color: #e5e5e5;
    line-height: 0;
    padding: 0;
    cursor: default;
  }

  &.disable {
    color: rgba(0, 0, 0, 0.25);
    cursor: not-allowed;
  }
}
.menu-item-content {
  display: flex;
  align-items: center;
  justify-content: space-between;

  &.has-children::before {
    content: '';
    display: inline-block;
    width: 8px;
    height: 8px;
    border-width: 1px;
    border-style: solid;
    border-color: #666 #666 transparent transparent;
    position: absolute;
    right: 16px;
    top: 50%;
    transform: translateY(-50%) rotate(45deg);
  }
  &.has-children.has-handler::after {
    content: '';
    display: inline-block;
    width: 1px;
    height: 24px;
    background-color: #f1f1f1;
    position: absolute;
    right: 18px;
    top: 3px;
    transform: scale(0);
    transition: transform $transitionDelay;
  }

  .sub-text {
    opacity: 0.6;
  }
  .sub-menu {
    // width: @subMenuWidth;
    position: absolute;
    display: none;
    left: calc(100% + 3px);
    top: 0;

    &.show {
      display: block;
    }
  }
}
</style>
