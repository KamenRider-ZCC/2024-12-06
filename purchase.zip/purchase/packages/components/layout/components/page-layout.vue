<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-12 11:40:45
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-15 14:08:55
 * @Description: 
-->
<template>
  <gl-layout>
    <slot name="side"></slot>
    <gl-layout-content>
      <div class="view-container">
        <router-view v-slot="{ Component, route }" style="height: 100%" v-if="keepAlive">
          <keep-alive>
            <component :is="Component" :key="route.fullPath"></component>
          </keep-alive>
        </router-view>
        <router-view v-slot="{ Component, route }" style="height: 100%" v-else>
          <component :is="Component" :key="route.fullPath"></component>
        </router-view>
      </div>
    </gl-layout-content>
  </gl-layout>
</template>
<script setup lang="ts">
interface Props {
  keepAlive?: boolean
}
withDefaults(defineProps<Props>(), {
  keepAlive: true
})
</script>
<style lang="scss" scoped>
.gl-layout {
  .view-container {
    height: calc(100vh - 94px);
  }
}
</style>
