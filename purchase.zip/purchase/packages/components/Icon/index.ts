export { default as Icon } from './index.vue'
