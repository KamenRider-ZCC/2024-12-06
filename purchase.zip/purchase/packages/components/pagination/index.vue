<template>
  <gl-pagination
    show-quick-jumper
    show-size-changer
    :page-size-options="pageSizes"
    :current="pageState.pageNum"
    :page-size="pageState.pageSize"
    :total="pageState.total"
    @change="handleCurrentChange"
  >
    <template #buildOptionText="props">
      <span>{{ props.value }}条/页</span>
    </template>
  </gl-pagination>
</template>
<script>
export default defineComponent({
  props: {
    page: {
      type: Object,
      default: () => ({ total: 0, pageNum: 1, pageSize: 10 })
    },
    pageSizes: {
      type: Array,
      default: () => ['10', '20', '50', '100']
    }
  },

  setup(props, { emit }) {
    const pageState = reactive(props.page)

    const handleCurrentChange = (page, pageSize) => {
      pageState.pageNum = page
      pageState.pageSize = pageSize
      emit('page-change', pageState)
    }

    return {
      pageState,
      handleCurrentChange
    }
  }
})
</script>
<style lang="scss" scoped>
:deep(.gl-pagination-options-quick-jumper) {
  margin-left: 40px;
}
</style>
