<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 09:43:58
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-11 15:23:16
 * @Description: 
-->
<template>
  <div :class="{ 'tree-node': true, disabled: disabledKey && !data[disabledKey] }">
    <div>
      <div v-if="!data.isLeaf" class="tree-icon">
        <img src="./assets/tree-folder.png" alt="" />
      </div>
      <div v-else class="tree-icon">
        <!-- 目录叶子节点-->
        <img v-if="isMenu" src="./assets/tree-folder.png" alt="" />
        <img
          v-else-if="data[folderLeafKey] === folderLeafValue"
          src="./assets/tree-folder.png"
          alt=""
        />
        <icon v-else :name="leafIcon" style="color: #1890ff" />
      </div>
      <div class="tree-label" v-if="data.isLeaf">
        <gl-tooltip
          placement="top"
          :title="data[labelKey]"
          trigger="hover"
          :destroy-tooltip-on-hide="true"
        >
          {{ data[labelKey] }}
        </gl-tooltip>
      </div>
      <div v-else class="tree-label">
        <span>{{ data[labelKey] }}</span>
      </div>
      <slot name="menu" v-bind="{ list, data }" />
    </div>
  </div>
</template>
<script setup lang="ts">
import Icon from '../Icon/index.vue'
import { NodeType, NodeMenuType } from './interface'
interface Props {
  list?: NodeMenuType[]
  data: NodeType
  leafIcon: string
  isMenu: boolean
  disabledKey?: string
  labelKey: string
  folderLeafKey: string
  folderLeafValue: any
}
defineProps<Props>()
</script>
<style lang="scss" scoped>
@import './tree-node.scss';
</style>
