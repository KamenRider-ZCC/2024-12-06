<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 09:43:58
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-17 11:42:05
 * @Description: 
-->
<template>
  <div class="tree-node">
    <div>
      <div v-if="!data.isLeaf && data.level === 1" class="tree-icon">
        <icon :name="`icon-${iconName}`" color="#7A7A7A" />
      </div>

      <div class="tree-label" v-if="data.isLeaf">
        <gl-tooltip placement="topLeft" :title="data.label" trigger="hover">
          {{ data.label }}
        </gl-tooltip>
      </div>
      <div class="tree-label" v-else>
        <span>{{ data.label }}</span>
      </div>
      <slot name="menu" v-bind="{ list, data }" />
    </div>
  </div>
</template>
<script setup lang="ts">
import Icon from '../../Icon/index.vue'
import { NodeType, NodeMenuType, NodeIconType } from '../interface'
interface Props {
  list?: NodeMenuType[]
  data: NodeType
  leafIcon?: string
}
const props = defineProps<Props>()
const iconName = ref<string>(NodeIconType[props.data.label])
</script>
<style lang="scss" scoped>
@import '../tree-node.scss';
</style>
