<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-13 11:49:39
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-03 08:43:17
 * @Description: 
-->
<template>
  <div class="tree-node">
    <div>
      <div class="tree-icon">
        <img
          v-if="data.isStop && data.isStop !== 0"
          :src="
            data.isStop === 1
              ? getImgUrl('stop-red.png')
              : data.isStop === 2
              ? getImgUrl('stop-yellow.png')
              : ''
          "
          :title="
            data.isStop === 1
              ? '该指标已停更'
              : data.isStop === 2
              ? '该指标已被替换，详情请见指标说明'
              : ''
          "
        />
        <icon v-else-if="!data.isStop && data.isLeaf && leafIcon" :name="leafIcon" size="17" />
        <img v-else-if="!data.isLeaf" src="../assets/tree-folder.png" alt="" />
      </div>
      <div v-if="data.isLeaf">
        <gl-tooltip placement="topLeft" :title="data.label" trigger="hover">
          {{ data.label }}
        </gl-tooltip>
      </div>
      <div v-else>
        <span>{{ data.label }}</span>
      </div>
      <slot name="menu" v-bind="{ list, data }" />
    </div>
  </div>
</template>

<script setup lang="ts">
// import Icon from '.././Icon/index.vue'
import { NodeType, NodeMenuType } from '../interface'
interface Props {
  list: NodeMenuType[]
  data: NodeType
  leafIcon?: string
}
withDefaults(defineProps<Props>(), { leafIcon: 'icon-file' })
const getImgUrl = (src: string) => {
  return require('@/assets/' + src)
}
</script>

<style scoped lang="scss">
@import '../tree-node.scss';
</style>
