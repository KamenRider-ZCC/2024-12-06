<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-12 09:08:55
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-17 11:45:00
 * @Description: 
-->
<template>
  <div class="ms-tree">
    <gl-tree v-bind="$attrs">
      <template #title="{ ...nodeProps }">
        <div class="ms-tree-node">
          <tree-node
            v-if="!defaultSlots"
            :data="{ ...nodeProps }"
            :list="nodeMenus"
            :leafIcon="leafIcon"
            :isMenu="isMenu"
            :disabledKey="disabledKey"
            :labelKey="labelKey"
            :folderLeafKey="folderLeafKey"
            :folderLeafValue="folderLeafValue"
            @dblclick="dbClick({ ...nodeProps })"
          >
            <template #menu>
              <node-menu
                v-if="nodeMenus && nodeMenus.length && !nodeProps.hideMenus"
                :list="nodeMenus"
                :data="{ ...nodeProps }"
              />
            </template>
          </tree-node>
          <slot v-else :data="{ ...nodeProps }" />
        </div>
      </template>
    </gl-tree>
  </div>
</template>

<script lang="ts">
export default {
  inheritAttrs: false
}
</script>
<script setup lang="ts">
import TreeNode from './tree-node.vue'
import NodeMenu from './node-menu/index.vue'
import { useSlots } from 'vue'
import { NodeType, NodeMenuType } from './interface'
interface Props {
  nodeMenus?: NodeMenuType[]
  leafIcon?: string
  isMenu?: boolean //是否是目录树
  disabledKey?: string //禁用字段
  labelKey?: string //树节点文本字段  默认label
  folderLeafKey?: string //目录叶子节点字段 默认type
  folderLeafValue?: any //目录叶子节点判断值 默认1
}
withDefaults(defineProps<Props>(), {
  leafIcon: 'icon-file',
  isMenu: false,
  labelKey: 'label',
  folderLeafKey: 'type',
  folderLeafValue: 1
})
interface Emits {
  (e: 'db-click', data: NodeType): void
}
const emits = defineEmits<Emits>()
const slots = useSlots()
const defaultSlots = slots.default
const dbClick = (node: any) => {
  emits('db-click', node)
}
</script>

<style lang="scss" scoped>
.ms-tree {
  :deep(.gl-tree) {
    .gl-tree-treenode {
      position: relative;
      padding: 0;
      width: 100%;
    }
    .gl-tree-title {
      display: inline-block;
      width: 100%;
    }
    .gl-tree-drag-icon {
      display: none;
    }
    .gl-tree-switcher {
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }
    .gl-tree-node-content-wrapper {
      // width: 100%;
      width: 0;
      // position: unset;
      border-radius: 0;
      margin-left: -20px;
      padding-left: 16px;
      &.gl-tree-node-selected {
        background: #e5eff8;
        color: #023985;
      }
    }
    // .gl-tree-treenode {
    //   &.gl-tree-treenode-selected {
    //     background: #eaf2ff;
    //   }
    // }
  }
  &-node {
    height: 42px;
    line-height: 42px;
  }
}
</style>
