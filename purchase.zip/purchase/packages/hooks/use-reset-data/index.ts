import { cloneDeep } from 'lodash-es'
export const useResetData = (data: {}) => {
  const getIniData = () => cloneDeep(data)

  const dataState = reactive(getIniData())

  const resetDataState = () => {
    // 先清空当前数据
    Object.keys(dataState).forEach((key) => {
      delete dataState[key]
    })
    return Object.assign(dataState, getIniData())
  }

  return { dataState, resetDataState }
}
