//菜单权限
export const useMenuAuthority = ({
  menuApi,
  modelApi,
  industryChainApi,
  modelInputApi,
  mySteelApi,
  varietyResearchApi,
  companyDataBaseApi,
  addModifyForm
}: {
  menuApi: Function
  modelApi: Function
  industryChainApi: Function
  modelInputApi: Function
  mySteelApi: Function
  varietyResearchApi: Function
  companyDataBaseApi: Function
  addModifyForm: any
}) => {
  interface MenuAuthority {
    children: MenuAuthority[] //子菜单列表	array	菜单视图对象
    createId: string //创建人id	string
    creatorTime: string //创建时间	string(date-time)
    hasChild: number //是否有子菜单 0:不包含1:包含	integer(int32)
    id: number //菜单主键id	integer(int64)
    isDelete: number //是否删除 0 否 1 是	integer(int32)
    menuLevel: number //菜单等级 节点：1:一级 2：二级 3：三级	integer(int32)
    menuLogo: string //菜单logo	string
    menuName: string //菜单名称	string
    menuSort: number //菜单排序，越小越靠前	integer(int32)
    menuType: number //菜单类型 0：主菜单 1：子菜单-左侧树形菜单 2：子菜单-新窗口菜单 3:二级主菜单	integer(int32)
    menuUrl: string //菜单地址url	string
    parentId: number //父级菜单、顶级为0	integer(int64)
    parentName: string //父节点名称	string
    state: number //菜单状态 1：启用 0：禁用	integer(int32)
    updateId: string //修改人ID	string
    updateName: string //修改人名称	string
    updateTime: string //修改时间

    moduleName: String //模型名称
  }
  const formState = reactive({
    layout: 'horizontal'
  })
  const formItemLayout = computed(() => {
    const { layout } = formState
    return layout === 'horizontal'
      ? {
          labelCol: { span: 24 },
          wrapperCol: { span: 24 }
        }
      : {}
  })
  //树
  const menuField = reactive({
    children: 'children',
    title: 'name',
    key: 'id'
  })

  const menuTreeData = ref<MenuAuthority[]>([])
  const modelTreeData = ref<MenuAuthority[]>([])
  const industryChainTreeData = ref<MenuAuthority[]>([])
  const modelInputTreeData = ref<MenuAuthority[]>([])
  const mySteelTreeData = ref<MenuAuthority[]>([])
  const varietyResearchTreeData = ref<MenuAuthority[]>([])
  const companyDataBaseTreeData = ref<MenuAuthority[]>([])

  const tempMenuNode = ref([])
  const tempModelNode = ref([])
  const tempIndustryChainNode = ref([])
  const tempModelInputNode = ref([])
  const tempMySteelNode = ref([])
  const tempVarietyResearchNode = ref([])
  const tempCompanyDataBaseNode = ref([])

  const isCheckedAll = ref<boolean>(false)
  const allCheckMenuFlag = ref<boolean>(false)
  const allCheckModelFlag = ref<boolean>(false)
  const allCheckModelInputFlag = ref<boolean>(false)
  const allCheckIndustryChainFlag = ref<boolean>(false)
  const allCheckMySteelFlag = ref<boolean>(false)
  const allCheckVarietyResearchFlag = ref<boolean>(false) //品种研究全选
  const allCheckCompanyDataBaseFlag = ref<boolean>(false)

  const hiddenPermIds = ref([])
  const getMenuTree = async () => {
    const { res, err } = await menuApi()

    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        menuTreeData.value = [...data]
        requestList(data, tempMenuNode.value)
      }
    }
  }
  const getMySteelTree = async () => {
    const { res, err } = await mySteelApi()

    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        mySteelTreeData.value = [...data]
        requestList(data, tempMySteelNode.value)
      }
    }
  }
  const getModelTree = async () => {
    const { res, err } = await modelApi()

    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        modelTreeData.value = [...data]
        requestList(data, tempModelNode.value)
      }
    }
  }
  const getIndustryChainTree = async () => {
    const { res, err } = await industryChainApi()

    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        industryChainTreeData.value = [...data]
        requestList(data, tempIndustryChainNode.value)
      }
    }
  }
  const getModelInputTree = async () => {
    const { res, err } = await modelInputApi()

    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        modelInputTreeData.value = [...data]
        requestList(data, tempModelInputNode.value)
      }
    }
  }
  const getVarietyResearchTree = async () => {
    const { res, err } = await varietyResearchApi()
    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        varietyResearchTreeData.value = [...data]
        requestList(data, tempVarietyResearchNode.value)
      }
    }
  }
  const getCompanyDataBaseTree = async () => {
    const { res, err } = await companyDataBaseApi()
    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        companyDataBaseTreeData.value = [...data]
        requestList(data, tempCompanyDataBaseNode.value)
      }
    }
  }
  const requestList = (data: any, test: any) => {
    //存放所有子节点
    data &&
      data.map((item: any) => {
        if (!item.isLeaf && item.children.length > 0) {
          requestList(item.children, test)
        } else {
          test.push(item.id)
        }
        return null
      })
    return test
  }
  const getList = (res: any, inList: any, halfList: any) => {
    for (const item of res) {
      if (item.children != null && item.children.length > 0) {
        getList(item.children, inList, halfList)
        halfList.push(item.id)
      } else {
        inList.push(item.id)
        if (item.isHidden) {
          hiddenPermIds.value.push(item.id)
        }
      }
    }
  }

  //全选
  const allCheck = (key: string, isAllChecked?: Boolean) => {
    switch (key) {
      case 'Menu': {
        if (!isAllChecked) {
          allCheckMenuFlag.value = !allCheckMenuFlag.value
        }

        const inList: Array<string> = []
        const halfList: Array<string> = []
        if (allCheckMenuFlag.value) {
          getList(menuTreeData.value, inList, halfList)
        }
        addModifyForm.value.menuIds = inList
        addModifyForm.value.halfMenuIds = halfList
        break
      }
      case 'MySteel': {
        if (!isAllChecked) {
          allCheckMySteelFlag.value = !allCheckMySteelFlag.value
        }

        const inList5: Array<string> = []
        const halfList5: Array<string> = []
        if (allCheckMySteelFlag.value) {
          getList(mySteelTreeData.value, inList5, halfList5)
        }
        addModifyForm.value.mysteelDbPermIds = inList5
        addModifyForm.value.halfMysteelDbPermIds = halfList5
        break
      }
      case 'Model': {
        if (!isAllChecked) {
          allCheckModelFlag.value = !allCheckModelFlag.value
        }
        const inList1: Array<string> = []
        const halfList1: Array<string> = []
        if (allCheckModelFlag.value) {
          getList(modelTreeData.value, inList1, halfList1)
        }

        addModifyForm.value.moduleViewPermIds = inList1
        addModifyForm.value.halfModuleViewPermIds = halfList1
        break
      }
      case 'IndustryChain': {
        if (!isAllChecked) {
          allCheckIndustryChainFlag.value = !allCheckIndustryChainFlag.value
        }
        const inList2: Array<string> = []
        const halfList2: Array<string> = []
        if (allCheckIndustryChainFlag.value) {
          getList(industryChainTreeData.value, inList2, halfList2)
        }

        addModifyForm.value.industryChainPermIds = inList2
        addModifyForm.value.halfIndustryChainPermIds = halfList2

        break
      }
      case 'ModelInput': {
        if (!isAllChecked) {
          allCheckModelInputFlag.value = !allCheckModelInputFlag.value
        }
        const inList3: Array<string> = []
        const halfList3: Array<string> = []
        if (allCheckModelInputFlag.value) {
          getList(modelInputTreeData.value, inList3, halfList3)
        }

        addModifyForm.value.moduleFillPermIds = inList3
        addModifyForm.value.halfModuleFillPermIds = halfList3

        break
      }
      case 'VarietyResearch': {
        //品种研究
        if (!isAllChecked) {
          allCheckVarietyResearchFlag.value = !allCheckVarietyResearchFlag.value
        }
        const inList3: Array<string> = []
        const halfList3: Array<string> = []
        if (allCheckVarietyResearchFlag.value) {
          getList(varietyResearchTreeData.value, inList3, halfList3)
        }

        addModifyForm.value.varietyResearchPermIds = inList3
        addModifyForm.value.halfVarietyResearchPermIds = halfList3

        break
      }
      case 'CompanyDataBase': {
        hiddenPermIds.value = []
        if (!isAllChecked) {
          allCheckCompanyDataBaseFlag.value = !allCheckCompanyDataBaseFlag.value
        }
        const inList4: Array<string> = []
        const halfList4: Array<string> = []
        if (allCheckCompanyDataBaseFlag.value) {
          getList(companyDataBaseTreeData.value, inList4, halfList4)
        }
        addModifyForm.value.enterpriseDbPermIds = inList4
        addModifyForm.value.halfEnterpriseDbPermIds = halfList4
        addModifyForm.value.hiddenPermIds = hiddenPermIds.value
        break
      }
    }
  }
  //一键勾选
  const selectAllTree = () => {
    allCheckMenuFlag.value = isCheckedAll.value && menuTreeData.value.length > 0 ? true : false
    allCheckModelFlag.value = isCheckedAll.value && modelTreeData.value.length > 0 ? true : false
    allCheckIndustryChainFlag.value =
      isCheckedAll.value && industryChainTreeData.value.length > 0 ? true : false
    allCheckModelInputFlag.value =
      isCheckedAll.value && modelInputTreeData.value.length > 0 ? true : false
    allCheckMySteelFlag.value =
      isCheckedAll.value && mySteelTreeData.value.length > 0 ? true : false
    //品种研究
    allCheckVarietyResearchFlag.value =
      isCheckedAll.value && varietyResearchTreeData.value.length > 0 ? true : false

    allCheckCompanyDataBaseFlag.value =
      isCheckedAll.value && companyDataBaseTreeData.value.length > 0 ? true : false
    allCheck('Menu', true)
    allCheck('Model', true)
    allCheck('ModelInput', true)
    allCheck('IndustryChain', true)
    allCheck('MySteel', true)
    allCheck('VarietyResearch', true) //品种研究
    allCheck('CompanyDataBase', true)
  }
  const uniqueTree = (uniqueArr: any, Arr: any, halfData: any) => {
    const uniqueChild = []
    for (const k in uniqueArr) {
      if (Arr.indexOf(uniqueArr[k]) !== -1) {
        uniqueChild.push(uniqueArr[k])
      } else {
        if (halfData.indexOf(uniqueArr[k]) === -1) {
          halfData.push(uniqueArr[k])
        }
      }
    }

    return uniqueChild
  }
  const treeFilter = (treeIds: any, tempIds: any, halfData: any) => {
    const uniqueChild = uniqueTree(treeIds, tempIds, halfData)
    treeIds.length = 0
    treeIds.push(...uniqueChild)
  }

  //子权限是否全选
  const ifCheck = (e: any, halfKey: string, tempIdsData: any, checkIdKey: string) => {
    if (checkIdKey === 'enterpriseDbPermIds') {
      const { checkedNodes } = e
      hiddenPermIds.value = checkedNodes
        .filter((item: any) => item.isHidden)
        .map((item: any) => item.id)
      addModifyForm.value.hiddenPermIds = hiddenPermIds.value
    }

    addModifyForm.value[halfKey] = e.halfCheckedKeys
    treeFilter(addModifyForm.value[checkIdKey], tempIdsData, addModifyForm.value[halfKey])
  }
  const resetAllCheck = () => {
    isCheckedAll.value = false
    allCheckMenuFlag.value = false
    allCheckModelFlag.value = false
    allCheckIndustryChainFlag.value = false
    allCheckModelInputFlag.value = false
    allCheckMySteelFlag.value = false
    allCheckVarietyResearchFlag.value = false //品种研究权全选
    allCheckCompanyDataBaseFlag.value = false
  }
  const getTree = async () => {
    getMenuTree()
    getModelTree()
    getIndustryChainTree()
    getModelInputTree()
    getMySteelTree()
    getVarietyResearchTree()
    getCompanyDataBaseTree()
  }
  return {
    formState,
    formItemLayout,
    menuTreeData,
    modelTreeData,
    modelInputTreeData,
    industryChainTreeData,
    companyDataBaseTreeData,
    mySteelTreeData,
    varietyResearchTreeData, //品种研究
    menuField,
    getTree,
    tempMenuNode,
    tempModelNode,
    tempIndustryChainNode,
    tempModelInputNode,
    tempMySteelNode,
    tempVarietyResearchNode, //品种研究
    tempCompanyDataBaseNode,
    ifCheck,
    allCheck,
    isCheckedAll,
    allCheckMenuFlag,
    allCheckModelFlag,
    allCheckIndustryChainFlag,
    allCheckModelInputFlag,
    allCheckMySteelFlag,
    allCheckVarietyResearchFlag,
    allCheckCompanyDataBaseFlag,
    selectAllTree,
    resetAllCheck,
    hiddenPermIds
  }
}
