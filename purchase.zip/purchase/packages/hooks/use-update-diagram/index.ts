import useSequenceTable from './use-sequence-table'
import api from './api'
import { ExtractParam, CurEl } from './types/interface'
import { cloneDeep } from 'lodash-es'
import { calendar } from '@mysteel-standard/utils'
export const useUpdateDiagramTable = (spinning: Ref) => {
  const indexCodeMap = new Map()
  // 序列表更新
  const { updateSequenceTable } = useSequenceTable()
  const updateTableData = async (curEl: CurEl, tableData: any[], extractParam: ExtractParam) => {
    // 排序表不更新
    if (curEl) {
      if (!extractParam.indexCodes) {
        return
      }
      const rows = tableData && tableData.length
      const params = {
        // indexCodes: extractParam.indexCodes,
        // deriveIndexObjs: extractParam.deriveIndexObjs,
        // beginTime: extractParam.beginTime,
        // endTime: extractParam.endTime,
        // timeCount: extractParam.timeCount,
        // timeType: extractParam.timeType,
        // dateType: extractParam.dateType || 0,
        rows,
        // dataDate: extractParam.dataDate,
        ...extractParam
      }
      // 获取最新数据
      spinning.value = true
      const { res, err } = await api.diagramMultiData(params)
      spinning.value = false
      if (!err && res) {
        const { datas } = res.data
        datas.forEach((item: { dataVOS: any[]; indexCode: string }) => {
          const dataValues: string[] = []
          const dateList: string[] = []
          item.dataVOS.forEach((ele: { dataValue: string; dataDate: any }) => {
            dataValues.push(ele.dataValue)
            dateList.push(ele.dataDate)
          })
          indexCodeMap.set(item.indexCode, {
            data: dataValues.slice(-rows),
            dateList: dateList.slice(-rows)
          })
        })
        curEl.contentOption.indexOptionsTable.forEach(
          (item: { indexCode: string; data: string[]; dateList: string[] }) => {
            const itemData = indexCodeMap.get(item.indexCode)
            if (itemData) {
              item.data = itemData.data
              item.dateList = itemData.dateList
            }
          }
        )

        let newExtractData
        if (curEl.id === 'free-table') {
          newExtractData = setTable(curEl, tableData)
        } else {
          newExtractData = setTable(curEl, tableData)
        }
        return newExtractData
      }
    }
  }
  // 更新自由表
  const setTable = async (curEl: CurEl, tableData: any[]) => {
    const len = tableData.length
    const paramsList = []
    for (let rowIndex = 0; rowIndex < len; rowIndex++) {
      for (let colIndex = 0; colIndex < tableData[rowIndex].length; colIndex++) {
        const cell = tableData[rowIndex][colIndex]
        if (cell.indexItem && cell.indexItem.indexCode) {
          const { indexCode } = cell.indexItem
          const indexItemData = indexCodeMap.get(indexCode)
          cell.indexItem.data = indexItemData ? indexItemData.data : []
          cell.indexItem.dateList = indexItemData ? indexItemData.dateList : []
          if (cell.indexItem.calculation && cell.indexItem.calculation.name) {
            const position = `${rowIndex},${colIndex}`
            const params = {
              ...cell.indexItem.calculationParams,
              position,
              rows: len
            }
            // 判断是否需要公式计算
            paramsList.push(params)
          } else {
            const dataValue = cell.isTimeFilter
              ? cell.indexItem.dateList || []
              : cell.indexItem.data || []
            cell.text = dataValue[dataValue.length - 1] || '--'
          }
        }
      }
    }
    if (paramsList.length) {
      const params = paramsList.filter((item) => !!item)
      const results = await api.getTableIndexData(params)
      setCalculationData(results.res, tableData, curEl)
    }
    // 序列表
    setSequenceTable(curEl, tableData)
    return tableData
  }

  const setSequenceTable = (curEl: CurEl, tableData: any[]) => {
    if (curEl.id !== 'sequence-table') return
    const len = tableData.length
    for (let rowIndex = 0; rowIndex < len; rowIndex++) {
      for (let colIndex = 0; colIndex < tableData[rowIndex].length; colIndex++) {
        const { indexItem } = tableData[rowIndex][colIndex]
        if (indexItem && indexItem.dateList) {
          const params = {
            matrixData: tableData,
            indexData: tableData[rowIndex][colIndex].indexItem,
            selectedCells: [rowIndex, colIndex],
            isTimeFilter: tableData[rowIndex][colIndex].isTimeFilter
          }
          updateSequenceTable(curEl, params)
        }
      }
    }
  }

  const setCalculationData = (results: { data: any[] }, tableData: any[], curEl: CurEl) => {
    if (!results.data || !results.data.length) return
    results.data.forEach((res: { position: { split: (arg0: string) => [any, any] } }) => {
      const [rowIndex, colIndex] = res.position.split(',')
      const cell = tableData[rowIndex][colIndex]
      setCalculationItem(res, cell)
      if (curEl.id === 'sequence-table') {
        const param = {
          matrixData: tableData,
          indexData: cloneDeep(cell.indexItem),
          selectedCells: [rowIndex, colIndex],
          isTimeFilter: cell.isTimeFilter
        }
        updateSequenceTable(curEl, param)
      }
    })
  }

  const setCalculationItem = (res: any, cell: any) => {
    let deriveValue = []
    deriveValue = res.indexValues.map((item: any) => item)
    cell.indexItem.calculation.value =
      deriveValue.map((item: { dataValue: any }) => item.dataValue) || []
    cell.indexItem.calculation.dateList = deriveValue.map((item: { date: any }) => item.date) || []
    setTableText(cell, deriveValue)
  }

  const setTableText = (cell: any, value: any) => {
    const data = value
    const lastData = data[data.length - 1]
    const evaluation = cell.isTimeFilter ? lastData.date : lastData.dataValue
    cell.text = evaluation || '--'
  }

  // // 格式化时间
  // const formatMatrixDataTime = (matrixData, curEl) => {
  //   matrixData.forEach((row, x) => {
  //     row.forEach((col, y) => {
  //       const selectIndexItem = col.indexItem
  //       const isTimeFilter = col.isTimeFilter
  //       if (!selectIndexItem || !selectIndexItem.indexCode || !isTimeFilter) {
  //         return
  //       }
  //       insertItemIndex(matrixData, col.indexItem, [x, y], {
  //         isTimeFilter,
  //         timeFormat: curEl.options.contentOption.tableLayout.timeFormat
  //       })
  //       // 序列表
  //       const param = {
  //         matrixData,
  //         indexData: col.indexItem,
  //         selectedCells: [x, y],
  //         isTimeFilter
  //       }
  //       updateSequenceTable(curEl, param)
  //     })
  //   })
  // }

  // const initScala = matrixData => {
  //   matrixData.forEach(row => {
  //     // console.log(row)
  //     row.forEach(rowCol => {
  //       if (!rowCol.isTimeFilter && rowCol.text && rowCol.text !== '--') {
  //         // 转为百分比
  //         if (rowCol.text.endsWith('%')) {
  //           const text = percentage2number(rowCol.text)
  //           const divide = math.evaluate(`${text} / 100`)
  //           rowCol.text = rowCol.percent ? rowCol.text : divide.toString()
  //         } else if (isDecimal(rowCol.text)) {
  //           const multiply = math.evaluate(`${rowCol.text} * 100`)
  //           rowCol.text = rowCol.percent ? multiply + '%' : rowCol.text
  //         }
  //       }

  //       if (
  //         !rowCol.isTimeFilter &&
  //         rowCol.scala !== null &&
  //         rowCol.scala !== '' &&
  //         rowCol.scala >= 0 &&
  //         rowCol.text &&
  //         rowCol.text !== '--'
  //       ) {
  //         // 如果是同环比计算，百分号%结尾，取消小数位设置
  //         if (isDecimal(rowCol.text) || rowCol.text.endsWith('%')) {
  //           const text = rowCol.dataValue
  //             ? percentage2number(rowCol.dataValue)
  //             : percentage2number(rowCol.text)
  //           const per = rowCol.text.endsWith('%') ? '%' : ''
  //           rowCol.text = Number(text).toFixed(rowCol.scala) + per
  //         }
  //       }
  //     })
  //   })
  // }
  return {
    updateTableData,
    // formatMatrixDataTime,
    // initScala,
    setCalculationData,
    setSequenceTable
  }
}

export const useUpdateDiagramChart = (state: any, spinning: Ref) => {
  //多个指标数据查询折线柱状图
  const updateChartTableData = async () => {
    spinning.value = true
    const { res, err } = await api.diagramMultiData({ ...state.extractParam })
    spinning.value = false
    if (!err && res) {
      const { datas } = res.data
      const result: any[] = []
      const temp = cloneDeep(state.curEl)
      //回显老数据
      let oldIndexOptions: any = []
      if (state.curEl.id === 'bar-line') {
        oldIndexOptions = state.curEl.contentOption.indexOptionsBarLine
      } else {
        oldIndexOptions = state.curEl.contentOption.indexOptionsTable
      }
      datas.forEach((item: any, i: number) => {
        const oldData = oldIndexOptions.filter(
          (el: { indexCode: string }) => el.indexCode === item.indexCode
        )
        const indexItem = {
          ...oldData[0],
          data: item.dataVOS.map((ele: any) => ele.dataValue),
          dateList: item.dataVOS.map((ele: any) => ele.dataDate)
        }
        result.push(indexItem)
      })
      if (state.curEl.id === 'bar-line') {
        temp.contentOption.indexOptionsBarLine = result
      } else if (state.curEl.id === 'sequence-table' || state.curEl.id === 'free-table') {
        temp.contentOption.indexOptionsTable = result
      }
      state.curEl = temp
    }
  }

  //多个指标数据查询饼图
  const updatePiePlotData = async () => {
    spinning.value = true
    const { res, err } = await api.diagramMultiNewestData(state.extractParam)
    spinning.value = false
    if (!err && res) {
      const { newestDataVOS } = res.data
      const result: any[] = []
      const temp = cloneDeep(state.curEl)
      //回显老数据
      let oldIndexOptions: any = []
      if (state.curEl.id === 'chart-pie') {
        oldIndexOptions = state.curEl.contentOption.indexOptionsPie
      } else if (state.curEl.id === 'scatter-plot') {
        oldIndexOptions = state.curEl.contentOption.indexOptionsScatter
      }
      newestDataVOS.forEach((item: any, i: number) => {
        const oldData = oldIndexOptions.filter(
          (el: { indexCode: string }) => el.indexCode === item.indexCode
        )
        const indexItem = {
          ...oldData[0],
          data: item.dataValue
        }
        result.push(indexItem)
      })

      if (state.curEl.id === 'chart-pie') {
        temp.contentOption.indexOptionsPie = result
      } else if (state.curEl.id === 'scatter-plot') {
        temp.contentOption.indexOptionsScatter = result
      }
      state.curEl = temp
    }
  }

  //多个指标数据查询雷达图
  const updateRadarData = async () => {
    spinning.value = true
    const { res, err } = await api.diagramMultiDataRadar(state.extractParam)
    spinning.value = false
    if (!err && res) {
      const { datas, dateList, qoQDate, yoYDate } = res.data
      //防止curEl监听多次执行
      const temp = cloneDeep(state.curEl)
      const { autoChecked, updateRuleType } = temp.contentOption.legendLayoutRadar.legend
      temp.contentOption.originData = datas
      temp.contentOption.dateList = dateList
      temp.contentOption.data = datas.map((v: { dataVOS: any[] }) =>
        v.dataVOS.map((y: { dataValue: any }) => y.dataValue)
      )
      const obj: any = {
        newDate: dateList[dateList.length - 1],
        qoQDate,
        yoYDate
      }
      if (autoChecked) {
        for (const key in obj) {
          temp.contentOption.legendLayoutRadar.legend[key] = obj[key]
        }
      }
      const typeArr = updateRuleType.split(',')
      const valueArr = typeArr.map((item: string) => obj[item] || '')
      temp.contentOption.radarSettings.forEach((item: { xAxisValue: string }, index: string) => {
        item.xAxisValue = valueArr[index]
      })

      state.curEl = temp
    }
  }

  //季节性分析接口
  const updateSeasonChart = async (data: any, indexDataSeason: any, extractParam?: any) => {
    const rangeDate = state.curEl.contentOption.xAxis.rangeDate
    let deriveIndexes = [`{seasonalanalysis,$${data.indexCode}}`]
    if (data.isDerive) {
      deriveIndexes = [`{seasonalanalysis,${data.indexCode}}`]
    }
    const params: any = {
      deriveIndexes,
      beginTime: rangeDate.beginTime,
      endTime: rangeDate.endTime,
      indexCode: data.indexCode,
      frequency: data.frequency,
      ...extractParam
    }
    if (rangeDate.intervalType === 'last') {
      params.intervalType = rangeDate.intervalType || 'last'
      params.timeCount = rangeDate.timeCount || 1
      params.timeType = rangeDate.timeType || '观察值'
    } else {
      delete params.intervalType
      delete params.timeCount
      delete params.timeType
    }
    spinning.value = true
    const { res, err } = await api.diagramGroupYearData(params)
    spinning.value = false
    if (!err && res) {
      //防止curEl监听多次执行
      const temp = cloneDeep(state.curEl)
      const dateType = temp.contentOption.xAxis.rangeDate.dateType
      const { datas, dateList } =
        dateType === 1 ? calendar.lunarSeasonAnalysis(res.data, res.data.frequency) : res.data
      const result: Array<any> = []
      const seasonOptions: any = temp.contentOption.seasonOptions
      datas.forEach((item: any) => {
        const indexItem = {
          data: item.dataVOS.map((y: { dataValue: string }) => y.dataValue),
          dateList,
          legendName: item.year
        }
        result.push(indexItem)
      })
      temp.contentOption.seasonOptions = seasonOptions
      state.curEl = temp
      indexDataSeason.value = result
    }
  }

  return {
    updateChartTableData,
    updatePiePlotData,
    updateRadarData,
    updateSeasonChart
  }
}
