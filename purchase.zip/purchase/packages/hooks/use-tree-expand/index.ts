/*
 * @Autor: zhouwanwan
 * @Date: 2023-08-09 20:51:34
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-07 10:05:01
 * @Description:
 */
export const useTreeExpand = () => {
  const expandedKeys = ref<number[]>([0])
  const getItem = (data: any) => {
    let ids: any[] = []
    data.forEach((item: any) => {
      ids.push(item.id)
      if (item.children) {
        ids = ids.concat(getItem(item.children))
      }
    })
    return ids
  }

  const nodeExpand = (node: any) => {
    const { expanded, id, children } = node
    if (!expanded) {
      expandedKeys.value = [...expandedKeys.value, id]
    } else {
      let childrenIds: number[] = []
      if (children) {
        childrenIds = getItem(node.children)
      }
      expandedKeys.value = expandedKeys.value.filter(
        (item) => item !== id && !childrenIds.includes(item)
      )
    }
    expandedKeys.value = [...expandedKeys.value]
  }
  //树展开收起
  const treeExpand = (keys: any[], { node }: { [propsName: string]: any }) => {
    nodeExpand(node)
  }
  return {
    expandedKeys,
    treeExpand,
    nodeExpand,
    getItem
  }
}
