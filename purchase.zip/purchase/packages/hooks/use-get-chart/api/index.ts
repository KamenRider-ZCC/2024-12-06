import request from '@mysteel-standard/apis'
const apiMap = {
  // 查询图表
  queryChartInfo: {
    method: 'post',
    url: '/database/chart/info'
  }
}
export default request(apiMap)
