/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-25 10:05:26
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-20 11:46:25
 * @Description:获取图表数据
 */
import api from './api/index'
import { useUpdateDiagramTable, useUpdateDiagramChart } from '../use-update-diagram'
import { cloneDeep } from 'lodash-es'
import { ref, reactive, toRefs } from 'vue'
export const useGetChart = () => {
  const loading = ref<boolean>(false)
  const state: any = reactive({
    curEl: {},
    extractParam: {}
  })
  const { curEl }: any = toRefs(state)
  const tableData = ref<any[]>([])
  const { updateTableData } = useUpdateDiagramTable(loading)
  // 季节性
  const seasonChecked = ref(false)
  const indexDataSeason = ref([])
  const { updateChartTableData, updatePiePlotData, updateRadarData, updateSeasonChart } =
    useUpdateDiagramChart(state, loading)
  const initChart = async (chartId: number) => {
    // console.log('initChart', chartId)
    loading.value = true
    const { res, err } = await api.queryChartInfo({ chartId })
    loading.value = false
    if (!err && res) {
      const { data } = res
      if (data) {
        const { curEl, extractParam } = JSON.parse(data.config)
        state.curEl = curEl
        state.extractParam = { ...extractParam, ...state.extractParam }
        const { contentOption } = curEl
        seasonChecked.value = contentOption.seasonChecked
        //更新图
        if (state.curEl.id === 'bar-line') {
          if (seasonChecked.value) {
            const indexData = state.curEl.contentOption.indexOptionsBarLine.filter(
              (item: any) => item.indexCode === state.curEl.contentOption.seasonIndexCode
            )[0]
            updateSeasonChart(indexData, indexDataSeason, state.extractParam)
          } else {
            updateChartTableData({})
          }
        } else if (state.curEl.id === 'sequence-table' || state.curEl.id === 'free-table') {
          await updateChartTableData()
        } else if (state.curEl.id === 'chart-pie' || state.curEl.id === 'scatter-plot') {
          updatePiePlotData()
        } else if (state.curEl.id === 'chart-radar') {
          updateRadarData()
        }
        //表格更新
        if (curEl.id === 'free-table' || curEl.id === 'sequence-table') {
          const newTableData = await updateTableData(
            state.curEl,
            curEl.tableData,
            state.extractParam
          )
          tableData.value = cloneDeep(newTableData)
        }
      }
    }
  }
  return {
    loading,
    seasonChecked,
    indexDataSeason,
    tableData,
    curEl,
    initChart,
    state
  }
}
