/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-21 17:31:24
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-19 09:25:41
 * @Description:
 */
import { createPinia } from 'pinia'
import useGlobal from './modules/global'
import useChartEdit from './modules/chart-edit'
import useBoardJump from './modules/board-jump'
import useEditorMenu from './modules/editor-menu'
import useCollection from './modules/collection'
import useInformation from './modules/information'
import useRichText from './modules/rich-text'
import editorProjectConfig from './composables/data-model'
import componentPropsConfig from './composables/data-tools'

const pinia = createPinia()

export {
  pinia,
  useGlobal,
  useChartEdit,
  useBoardJump,
  useEditorMenu,
  useCollection,
  useInformation,
  useRichText,
  editorProjectConfig,
  componentPropsConfig
}
