import { defineStore } from 'pinia'
const useCollection = defineStore('collectParam', {
  state: () => ({
    tapList: [],
    subMenuParams: ''
  
  }),
  actions: {
    invokePushItems(items) {
      this.tapList.push(items)
      for (let i = 0; i < this.tapList.length; i++) {
        this.tapList[i].checked = false
      }
      this.tapList[this.tapList.length - 1].checked = true
    },
    invokeSpliceItems(items) {
      const allMenu = document.querySelectorAll("li[class*='left']")
      for (let m = 0; m < allMenu.length; m++) {
        allMenu[m].classList.remove('is-active')
      }
      for (let i = 0; i < this.tapList.length; i++) {
        if (this.tapList[i].menuName === items.menuName) {
          this.tapList.splice(i, 1)
        }
      }
      // console.log(this.tapList[this.tapList.length-1])
      if (this.tapList.length - 1 >= 0) {
        const id = this.tapList[this.tapList.length - 1].id
        if (document.querySelector('.left' + id)) {
          document.querySelector('.left' + id).classList.add('is-active')
        }
        this.tapList[this.tapList.length - 1].checked = true
      }
    },
    invokeChangeItems(items) {
      for (let i = 0; i < this.tapList.length; i++) {
        if (this.tapList[i] === items) {
          this.tapList[i].checked = true
        } else {
          this.tapList[i].checked = false
        }
      }
    },
    invokeUpdateItems(items) {
      for (let i = 0; i < this.tapList.length; i++) {
        if (this.tapList[i].path === items.path) {
          if (
            typeof this.tapList[i].query.params === 'string' &&
            typeof this.tapList[i].query.params
          ) {
            this.tapList[i].query.params = JSON.parse(
              this.tapList[i].query.params
            )
          }
          this.tapList[i].query.params.folderId = items.query.params.folderId
        }
      }
    }
  },
  getters: {
    getTapList(state) {
      return this.tapList
    }
  },
 
})
export  default useCollection