import { defineStore } from 'pinia'
const useGlobal = defineStore('global', {
  state: () => ({
    cVal1: '90%', // 置信区间 1
    cVal2: '90%', // 置信区间 2
  }),
  actions: {
    // 初始化置信区间select值
    initPrediction() {
      this.cVal1 = '90%'
      this.cVal2 = '90%'
    },
  },
  
})
export default useGlobal