import { defineStore } from 'pinia'
const useBoardJump = defineStore('jumpParam', {
  state: () => ({
    jumpParamData: {},
  
  }),
  actions: {
    setData(data: any) {
      this.jumpParamData = data
    },
  },
  
})
export  default useBoardJump