import componentPropsConfig from './data-tools'
import dayjs from 'dayjs'
const { getComponentAttrs } = componentPropsConfig
export default {
  name: '',
  width: 794,
  height: 800,
  header: (title) =>
    Object.assign({
      title: {
        elName: 'text',
        commonStyle: {},
        propsValue: { text: `<p>${title}</p>` },
        attrs: [{}, ...getComponentAttrs('text')]
      },
      date: {
        elName: 'date',
        // 颜色需要填6位，不能填3位，否则<input type="color" /> 不能识别
        commonStyle: { fontSize: 14, color: '#FFFFFF' },
        propsValue: { date: dayjs(), format: 'YYYY年MM月DD日 星期' },
        attrs: [{}, ...getComponentAttrs('date')]
      }
    }),
  gap: 16,
  margin: 10,
  padding: 16,
  scale: 1
}
