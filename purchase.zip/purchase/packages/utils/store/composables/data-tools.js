const fontLayout = [
  {
    label: '字体',
    component: 'DFont',
    isCommon: true,
    evalValue: 'font-family',
    layout: ''
  },
  {
    label: '字号',
    component: 'fontsize',
    isCommon: true,
    evalValue: 'fontSize',
    layout: ''
  },
  {
    label: '字体颜色',
    component: 'color',
    isCommon: true,
    evalValue: 'color',
    layout: ''
  }
]

const _attrs = [
  {
    label: '图表配置',
    element: ['chart'],
    formList: [
      {
        label: '开始时间',
        component: 'DDate',
        evalValue: 'beginTime',
        layout: ''
      },
      {
        label: '结束时间',
        component: 'DDate',
        evalValue: 'endTime',
        layout: ''
      }
    ]
  },
  {
    label: '样式配置',
    element: ['date'],
    formList: [
      ...fontLayout,
      {
        label: '时间格式',
        component: 'format',
        evalValue: 'format',
        layout: ''
      },
      {
        label: '日期选择',
        component: 'date',
        evalValue: 'date',
        layout: ''
      }
    ]
  },
  {
    label: '样式配置',
    element: ['default-index-text'],
    formList: [...fontLayout]
  },
  {
    label: '图片设置',
    element: ['image'],
    formList: [
      // {
      //   label: '宽高大小',
      //   component: 'ImageSize',
      //   isCommon: false,
      //   evalValue: 'image',
      //   layout: ''
      // },
      {
        label: '图片设置',
        component: 'image',
        isCommon: false,
        evalValue: 'image',
        layout: ''
      }
    ]
  },
  {
    label: '文本编辑',
    element: ['text'],
    class: 'richtext',
    formList: [
      {
        label: '',
        component: 'richtext',
        isCommon: false,
        evalValue: 'text',
        layout: 'richtext'
      }
    ]
  },
  {
    label: '指标配置',
    element: ['index-text'],
    class: 'richtext',
    formList: [
      {
        label: '',
        component: 'IndexText',
        isCommon: false,
        evalValue: 'text',
        layout: 'richtext'
      }
    ]
  },
  {
    label: '音频设置',
    element: ['audio'],
    formList: [
      {
        label: '音频设置',
        component: 'DAudio',
        isCommon: false,
        evalValue: 'text',
        layout: ''
      }
    ]
  },
  {
    label: '样式配置',
    element: ['table'],
    class: 'richtext',
    formList: [
      {
        label: '',
        component: 'DTable',
        isCommon: false,
        evalValue: 'data',
        layout: 'richtext'
      }
    ]
  }
]

const getComponentAttrs = (elName, elAttrs, pptAttrs) => {
  const elementAttrs = elAttrs || _attrs
  const _el_attrs = elementAttrs.filter((item) => item.element && item.element.includes(elName))
  // console.log(_el_attrs)
  return pptAttrs ? [...pptAttrs, ..._el_attrs] : _el_attrs || []
}

export default {
  getComponentAttrs
}
