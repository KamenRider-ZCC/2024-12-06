/*
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-06-17 16:22:31
 * @Description:
 */
import mitt from 'mitt'
export const bus = mitt()
