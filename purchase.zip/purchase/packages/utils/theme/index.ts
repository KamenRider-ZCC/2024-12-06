const blueTheme = {
  chart: {
    backgroundColor: '#072e80',
    textColor: '#fff',
    axisLabelColor: '#16AAFF',
    axisLineColor: '#133A8C',
    legendTextColor: '#fff',
    seriesTextColor: '#fff',
    seriesBarColor: '#32C5FF',
    dataZoom: {
      backgroundColor: '#021848',
      borderColor: '#0A2E7A',
      fillerColor: '#0B2A6C',
      handleStyle: {
        color: '#0F41A9',
        borderColor: '#0F41A9'
      }
    },
    gauge: {
      baseColor: '#01BAFF',
      lightBlue: '#0DC3FF',
      skyBlue: '#1C72FF',
      meiRed: '#E23E65'
    },
    areaStyle: {
      color: '#00A8FF'
    },
    colorSet: [
      '#F42743',
      '#3F92F3',
      '#F69333',
      '#2CAA5F',
      '#999999',
      '#333333',
      '#FED700',
      '#6C41FF',
      '#FA93A1',
      '#9FC9F9',
      '#FBC999',
      '#96D5AF',
      '#DDDDDD',
      '#666666',
      '#FFEB7F',
      '#B6A0FF'
    ]
  },
  table: {
    fontColor: '#FFFFFF',
    headerBgColor: '#043281',
    borderColor: '#043281',
    bodyBgColor: '#001C58'
  }
}

export const _blueTheme = {
  backgroundColor: blueTheme.chart.backgroundColor,
  title: {
    textStyle: {
      color: blueTheme.chart.textColor
    }
  },
  legend: {
    textStyle: {
      color: blueTheme.chart.legendTextColor
    }
  },
  xAxis: {
    axisLabel: {
      color: blueTheme.chart.axisLabelColor
    },
    axisLine: {
      lineStyle: {
        color: blueTheme.chart.axisLineColor
      }
    }
  },
  yAxis: [
    {
      nameTextStyle: {
        color: blueTheme.chart.axisLabelColor
      },
      axisLabel: {
        color: blueTheme.chart.axisLabelColor
      },
      axisLine: {
        lineStyle: {
          color: blueTheme.chart.axisLineColor
        }
      },
      splitLine: {
        lineStyle: {
          color: blueTheme.chart.axisLineColor
        }
      }
    },
    {
      nameTextStyle: {
        color: blueTheme.chart.axisLabelColor
      },
      axisLabel: {
        color: blueTheme.chart.axisLabelColor
      },
      axisLine: {
        lineStyle: {
          color: blueTheme.chart.axisLineColor
        }
      },
      splitLine: {
        lineStyle: {
          color: blueTheme.chart.axisLineColor
        }
      }
    },
    {
      nameTextStyle: {
        color: blueTheme.chart.axisLabelColor
      },
      axisLabel: {
        color: blueTheme.chart.axisLabelColor
      },
      axisLine: {
        lineStyle: {
          color: blueTheme.chart.axisLineColor
        }
      },
      splitLine: {
        lineStyle: {
          color: blueTheme.chart.axisLineColor
        }
      }
    },
    {
      nameTextStyle: {
        color: blueTheme.chart.axisLabelColor
      },
      axisLabel: {
        color: blueTheme.chart.axisLabelColor
      },
      axisLine: {
        lineStyle: {
          color: blueTheme.chart.axisLineColor
        }
      },
      splitLine: {
        lineStyle: {
          color: blueTheme.chart.axisLineColor
        }
      }
    },
  ],
  dataZoom: [
    {
      backgroundColor: blueTheme.chart.dataZoom.backgroundColor,
      fillerColor: blueTheme.chart.dataZoom.fillerColor,
      borderColor: blueTheme.chart.dataZoom.borderColor,
      textStyle: {
        color: blueTheme.chart.textColor
      },
      handleStyle: {
        color: blueTheme.chart.dataZoom.handleStyle.color,
        borderColor: blueTheme.chart.dataZoom.handleStyle.color
      }
    },
    {
      backgroundColor: blueTheme.chart.dataZoom.backgroundColor,
      fillerColor: blueTheme.chart.dataZoom.fillerColor,
      borderColor: blueTheme.chart.dataZoom.borderColor,
      textStyle: {
        color: blueTheme.chart.textColor
      },
      handleStyle: {
        color: blueTheme.chart.dataZoom.handleStyle.color,
        borderColor: blueTheme.chart.dataZoom.handleStyle.color
      }
    },
    {
      backgroundColor: blueTheme.chart.dataZoom.backgroundColor,
      fillerColor: blueTheme.chart.dataZoom.fillerColor,
      borderColor: blueTheme.chart.dataZoom.borderColor,
      textStyle: {
        color: blueTheme.chart.textColor
      },
      handleStyle: {
        color: blueTheme.chart.dataZoom.handleStyle.color,
        borderColor: blueTheme.chart.dataZoom.handleStyle.color
      }
    }
  ],
  geo: {
    itemStyle: {
      normal: {
        areaColor: blueTheme.chart.backgroundColor
      },
      emphasis: {
        areaColor: blueTheme.chart.backgroundColor
      }
    }
  },
  series: [
    {
      title: {
        color: blueTheme.chart.seriesTextColor
      },
      label: {
        color: blueTheme.chart.textColor,
        normal: {
          textStyle: {
            color: blueTheme.chart.textColor
          }
        }
      },
      itemStyle: {
        color: blueTheme.chart.seriesBarColor
      }
    }
  ]
}

export const deepClone = (initObj, finalObj) => {
  const obj = finalObj || {}
  for (const i in initObj) {
    const prop = initObj[i] // 避免相互引用对象导致死循环，如initObj.a = initObj的情况
    if (prop === obj) {
      continue
    }
    if (typeof prop === 'object') {
      deepClone(prop, obj[i])
    } else {
      if (!obj[i]) continue
      obj[i] = prop
    }
  }
  return obj
}