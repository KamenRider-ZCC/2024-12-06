export const getLocalStorage = (name: string) => {
  const store = window.localStorage.getItem(name)
  return store
}
export const setLocalStorage = (key: string, value: any) => {
  window.localStorage.setItem(key, value)
}
export const removeLocalStorage = (name: string) => {
  window.localStorage.removeItem(name)
}
