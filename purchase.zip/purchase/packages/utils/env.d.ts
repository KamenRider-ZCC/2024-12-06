/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-21 17:31:24
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-19 10:15:07
 * @Description:
 */
/// <reference types="vite/client" />
declare module '*.vue' {
  import { defineComponent } from 'vue'
  const Component: ReturnType<typeof defineComponent>
  export default Component
}
declare module 'gl-design-vue'
declare module 'mitt'
declare module 'lodash-es'
declare module 'prosemirror'
