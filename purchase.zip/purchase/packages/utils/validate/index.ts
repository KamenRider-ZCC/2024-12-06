/*
 * @Autor: zhouwanwan
 * @Date: 2023-10-18 17:13:28
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-11 15:26:07
 * @Description:
 */
/**
 * @description: 邮箱校验
 * @param {*} telephone
 */
export const isEmail = (_rule: any, str: string) => {
  const reg = /\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/
  if (str && !reg.test(str)) {
    return Promise.reject(new Error('请输入有效的邮箱地址'))
  } else {
    return Promise.resolve()
  }
}
/**
 * @description: 手机号校验
 * @param {*} telephone
 */
export const isMobile = (_rule: any, telephone: string) => {
  const reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/
  if (telephone && !reg.test(telephone)) {
    return Promise.reject(new Error('请输入有效的手机号'))
  } else {
    return Promise.resolve()
  }
}

//特殊字符
export const isSpecialChar = (_rule: any, value: string) => {
  const reg =
    /[`~!@#$%^&*\-+=<>?:"{}|,/;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”【】、；‘’，。、]/
  if (value && reg.test(value)) {
    return Promise.reject(new Error('请输入字母、数字、中文或下划线'))
  } else {
    return Promise.resolve()
  }
}

//密码
export const isPassword = (_rule: any, value: string) => {
  const reg = /[\u4e00-\u9fa5]/g
  if (value && reg.test(value)) {
    return Promise.reject(new Error('请输入字母、数字、和特殊字符'))
  } else {
    return Promise.resolve()
  }
}

//特殊字符且无中文字符
export const isSpecialCharAndChar = (_rule: any, value: string) => {
  const reg =
    /[~!@#$%^&*()\-+=<>?:"{}|,./;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”【】、；‘’，。、]/

  const reg2 = /[\u4e00-\u9fa5]/g
  if ((value && reg.test(value)) || reg2.test(value)) {
    return Promise.reject(new Error('请输入字母、数字或下划线'))
  } else {
    return Promise.resolve()
  }
}

/**
 * @description: 是否是数字
 * @param {*} val
 */
export const isIntNum = (val: any) => {
  if (val == '' || isNaN(val)) {
    return false
  } else {
    return true
  }
}
export const passwordValidate = (_rule: any, value: string) => {
  // const reg = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)[A-Za-z\d]{10,20}$/
  const reg = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)[A-Za-z\d!@#$%^&*]{10,20}$/
  if (value === '') {
    return Promise.reject(new Error('请输入密码'))
  }
  if (value && reg.test(value)) {
    return Promise.resolve()
  } else {
    return Promise.reject(new Error('密码长度为10-20位，且必须包含数字、大小写字母'))
  }
}
