/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-28 09:27:21
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-11 09:58:16
 * @Description:
 */
// import { createApp } from 'vue'
// import Loading from '@/components/loading.vue'
const updateElVisible = (el: HTMLElement, value: string[]) => {
  const all_permission = '*'
  const menuPermissions = window.localStorage.getItem('menuPermissions')
  const permissions = menuPermissions && JSON.parse(menuPermissions)
  const hasPermissions = permissions.some((permission: string) => {
    return all_permission === permission || value.includes(permission)
  })
  if (!hasPermissions) {
    el.parentElement?.removeChild(el)
  }
}
export const permissionDirective = {
  mounted(el: HTMLElement, binding) {
    updateElVisible(el, binding.value)
  },
  beforeUpdate(el: HTMLElement, binding) {
    updateElVisible(el, binding.value)
  }
}
// export const loadingDirective = {
//   mounted(el: HTMLElement, binding: any) {
//     // 在vue 中创建子类
//     const app = createApp(Loading)
//     const instance = app.mount(document.createElement('div'))
//     el.instance = instance
//     if (binding.value) el.appendChild(el.instance.$el)
//   },
//   updated(el: HTMLElement, binding: any) {
//     // loading 节点
//     if (binding.value !== binding.oldValue) {
//       binding.value ? el.appendChild(el.instance.$el) : el.removeChild(el.instance.$el)
//     }
//   }
// }
