export { default as ChartTree } from './index.vue'
