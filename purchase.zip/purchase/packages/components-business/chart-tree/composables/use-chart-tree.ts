import api from '../api/index'
import { TabItem, TreeDataItem } from '../types/interface'
import { message, Modal } from 'gl-design-vue'
import { cloneDeep } from 'lodash-es'
import { checkPermit } from '@mysteel-standard/hooks'

export default (props: { tabItem: TabItem }, emits: Function) => {
  interface State {
    treeData: TreeDataItem[]
    expandedKeys: number[]
    selectedKeys: number[]
    replaceFields: { children: string; title: string; key: string }
    selectItem: { [key: string]: any }
    folderVisible: boolean
    isEdit: boolean
    folderForm: { [key: string]: string }
    rules: { [key: string]: any }
    activeKey: number
    loading: boolean
  }
  const state = reactive<State>({
    treeData: [{ label: '公司图表库', id: 0, isLeaf: false, children: [] }],
    expandedKeys: [],
    selectedKeys: [],
    replaceFields: { children: 'children', title: 'label', key: 'id' },
    selectItem: {},
    folderVisible: false,
    isEdit: false,
    folderForm: {
      folder: ''
    },
    rules: {
      folder: [{ required: true, message: '请输入文件夹名称', trigger: 'blur' }]
    },
    activeKey: 0,
    loading: false
  })

  watch(
    () => state.loading,
    (val) => {
      emits('update-loading', val)
    }
  )

  const formRef = ref<any>(null)
  // 初次加载/切换
  const getTree = async (
    parent: TreeDataItem[] = [{ label: '公司图表库', id: 0, isLeaf: false, children: [] }]
  ) => {
    const data = await queryCatalogueList()
    parent[0].children = data
    state.treeData = parent
    state.selectedKeys = [0]
    state.expandedKeys = [0]
    state.activeKey = 0
    state.selectItem = {
      ...parent[0],
      tabName: props.tabItem.label,
      tabValue: props.tabItem.value
    }
    emits('get-catalogue-item', state.selectItem)
  }
  // 查询接口
  const queryCatalogueList = async () => {
    const params = {
      type: props.tabItem.value
    }
    state.loading = true
    const { res, err } = await api.queryChartsCatalogueList(params)
    state.loading = false
    if (err) {
      message.error(err.message)
      return
    }
    if (!err && res) {
      return res.data
    }
  }

  // 点击节点
  const selectClick = (
    selectedKeys: number[],
    { node }: { node: { expanded: boolean; isLeaf: boolean; key: number } }
  ) => {
    state.selectItem = {
      tabName: props.tabItem.label,
      tabValue: props.tabItem.value
    }
    if (selectedKeys && selectedKeys.length) {
      const selectNode: any = getNode(state.treeData, selectedKeys[0])
      state.selectItem = {
        ...selectNode,
        tabName: props.tabItem.label,
        tabValue: props.tabItem.value
      }
      emits('get-catalogue-item', state.selectItem)
    } else {
      emits('get-catalogue-item', state.selectItem)
    }

    const { expanded, isLeaf, key } = node
    if (!isLeaf) {
      if (!expanded) {
        state.expandedKeys = [...state.expandedKeys, ...selectedKeys]
      } else {
        const expandedIndex = state.expandedKeys.indexOf(key)
        state.expandedKeys.splice(expandedIndex, 1)
      }
    }
    state.expandedKeys = [...state.expandedKeys]
  }
  // 根据id获取节点
  const getNode = (data: TreeDataItem[], id: number) => {
    let result = undefined
    data.some((item) => {
      if (item.id === id) {
        result = cloneDeep(item)
        return true
      }
      if (item.children && item.children.length) {
        const node = getNode(item.children, id)
        if (node) {
          result = node
          return true
        }
      }
    })
    return result
  }

  interface Params {
    id: number
    pid: number
    type: number
    sort: number | null
  }
  // 拖动
  const handleDropTree = async (info: any) => {
    const { node, dragNode, dropPosition } = info
    const dropKey = node.key // 目标节点
    const dragKey = dragNode.key //被拖动节点
    const dropPosArray = node.pos.split('-')
    const dropPos = dropPosition - Number(dropPosArray[dropPosArray.length - 1])

    let dropType
    let sort
    let pid = node.pid

    if (dropPos === 0) {
      // console.log('下面作为他子集')
      pid = dropKey
      if (!node.dataRef.isEnd) {
        dropType = 1
        if (node.children) {
          //有子节点
          sort = node.children[0].sort - 1
        } else {
          sort = 0
        }
      }
    }
    // 1是移动到和他平级在他下面
    if (dropPos === 1) {
      sort = node.sort + 1
      dropType = 2
    }
    //-1是移动到和他平级在他上面
    if (dropPos === -1) {
      sort = node.sort - 1
      dropType = 1
    }
    const params = {
      id: dragKey,
      pid,
      sort,
      dropType,
      type: props.tabItem.value
    }

    state.loading = true
    const { res, err } = await api.queryCatalogueMove(params)
    state.loading = false
    if (res && !err) {
      message.success('拖拽成功！')
      const data = await queryCatalogueList()
      state.treeData[0].children = data
    }
  }

  const handleEdit = (item: any, data: any) => {
    state.activeKey = data.id
    switch (item.label) {
      case '新建文件夹':
        state.isEdit = false
        state.folderForm.folder = ''
        break
      case '编辑文件夹':
        state.isEdit = true
        state.folderForm.folder = data.label
        break
    }
    state.folderVisible = true
  }
  const handleDel = (item: any, data: any) => {
    Modal.confirm({
      title: '确认删除此目录?',
      centered: true,
      async onOk() {
        const params = {
          type: props.tabItem.value,
          catalogueId: data.id
        }
        state.loading = true
        const { res, err } = await api.queryCatalogueDelete(params)
        state.loading = false
        if (res && !err) {
          message.success(res.message || '删除成功！')
          const data = await queryCatalogueList()
          state.treeData[0].children = data
        }
      }
    })
  }
  const getItem = (data: any) => {
    let ids: any[] = []
    data.forEach((item: any) => {
      ids.push(item.id)
      if (item.children) {
        ids = ids.concat(getItem(item.children))
      }
    })
    return ids
  }
  // 收起全部
  const allCollapse = (item: { label: string }, data: any) => {
    if (data.level === 1) {
      state.expandedKeys = []
    } else {
      let childrenIds: number[] = []
      if (data.children) {
        childrenIds = getItem(data.children)
      }
      if (data.isLeaf && data.isEnd) {
        childrenIds.push(data.pid)
      }
      state.expandedKeys = state.expandedKeys.filter(
        (item) => item !== data.id && !childrenIds.includes(item)
      )
    }
  }
  const operationMenu: { [key: string]: Function } = {
    新建文件夹: handleEdit,
    编辑文件夹: handleEdit,
    删除文件夹: handleDel,
    全部收起: allCollapse
  }
  const menuClick = (item: any, data: any) => {
    operationMenu[item.label](item, data)
  }
  const treeMenu = [
    {
      label: '新建文件夹',
      condition: () => props.tabItem.value === 2 || checkPermit(['sjzx:tbk:gstbkmlxjwjj']),
      handle: menuClick
    },
    {
      label: '编辑文件夹',
      condition: (data: { id: string | number }) =>
        data.id !== 0 && (props.tabItem.value === 2 || checkPermit(['sjzx:tbk:gstbkmlbjwjj'])),
      handle: menuClick
    },
    {
      label: '删除文件夹',
      condition: (data: { id: string | number }) =>
        data.id !== 0 && (props.tabItem.value === 2 || checkPermit(['sjzx:tbk:gstbkmlscwjj'])),
      handle: menuClick
    },
    {
      label: '全部收起',
      condition: (data: { id: string | number }) => data.id !== 0,
      handle: menuClick
    }
  ]
  // 确认新增/编辑文件夹
  const confirmFolderBtn = () => {
    formRef.value.validateFields().then(() => {
      if (!state.isEdit) {
        confirmAdd()
      } else {
        confirmRename()
      }
    })
  }
  // 新增接口
  const confirmAdd = async () => {
    const params = {
      label: state.folderForm.folder,
      pid: state.activeKey,
      type: props.tabItem.value
    }
    state.loading = true
    const { res, err } = await api.queryCatalogueAdd(params)
    state.loading = false
    if (!err && res) {
      message.success(res.message)
      cancelBtn()
      const data = await queryCatalogueList()
      state.treeData[0].children = data
    }
  }
  // 重命名接口
  const confirmRename = async () => {
    const params = {
      label: state.folderForm.folder,
      catalogueId: state.activeKey
    }
    state.loading = true
    const { res, err } = await api.queryCatalogueRename(params)
    state.loading = false
    if (!err && res) {
      message.success(res.message)
      cancelBtn()
      const data = await queryCatalogueList()
      state.treeData[0].children = data
    }
  }
  // 关闭弹窗
  const cancelBtn = () => {
    if (formRef.value) formRef.value.resetFields()
    Object.assign(state, {
      folderVisible: false
    })
  }
  return {
    treeMenu,
    ...toRefs(state),
    selectClick,
    handleDropTree,
    getTree,
    cancelBtn,
    confirmFolderBtn,
    formRef
  }
}
