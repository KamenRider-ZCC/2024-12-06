export interface TabItem {
  label: string
  value: number
}

export interface TreeDataItem {
  label: string
  id: string | number
  isLeaf: boolean
  children?: TreeDataItem[]
  hasCharts?: number
  isEnd?: number
  pid?: number
  sort?: number
  type?: number
  userId?: number
}