<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-16 13:53:54
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-15 14:25:56
 * @Description: 日期高级设置弹窗
-->
<template>
  <gl-modal
    :title="dateSetTitle"
    width="700px"
    :visible="visible"
    @cancel="closeCalendarSetting()"
    @ok="saveCalendarSetting()"
  >
    <gl-form :model="dateSetFormData">
      <gl-form-item label="日期类型">
        <gl-radio-group v-model:value="dateSetFormData.dateType">
          <gl-radio :value="0">公历</gl-radio>
          <gl-radio :value="1">农历</gl-radio>
        </gl-radio-group>
      </gl-form-item>
      <gl-form-item label="日期区间">
        <gl-radio-group v-model:value="dateSetFormData.intervalType" class="date-rang-group">
          <gl-radio :style="radioStyle" :value="0">全部</gl-radio>
          <div style="line-height: 30px; height: 30px; margin-bottom: 30px">
            <gl-radio :value="1">
              <gl-space>
                <span>最后</span>
                <gl-input-number v-model:value="dateSetFormData.timeCount" :min="1" />
                <span>个</span>
              </gl-space>
            </gl-radio>
            <gl-select
              v-model:value="dateSetFormData.timeType"
              style="width: 100px; display: inline-block"
              :options="options"
              @change="dateSetFormData.intervalType = 1"
            />
          </div>
          <gl-radio :style="radioStyle" :value="2">
            <gl-space>
              <span>开始时间</span>
              <gl-date-picker
                v-model:value="dateSetFormData.beginTime"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                dropdown-class-name="calendar-lunar"
                placeholder="年~月~日"
                @change="dateSetFormData.intervalType = 2"
                :disabledDate="disabledDate"
              >
                <template #dateRender="{ current }">
                  <div class="ant-calendar-date">
                    <p>{{ current.date() }}</p>
                    <p v-if="dateSetFormData.dateType === 1">
                      {{ solar2lunar(current) }}
                    </p>
                  </div>
                </template>
              </gl-date-picker>

              <span>结束时间</span>
              <gl-date-picker
                v-model:value="dateSetFormData.endTime"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                dropdown-class-name="calendar-lunar"
                placeholder="年~月~日"
                @change="dateSetFormData.intervalType = 2"
                :disabledDate="disabledDate"
              >
                <template #dateRender="{ current }">
                  <div class="ant-calendar-date">
                    <p>{{ current.date() }}</p>
                    <p v-if="dateSetFormData.dateType === 1">
                      {{ solar2lunar(current) }}
                    </p>
                  </div>
                </template>
              </gl-date-picker>
            </gl-space>
          </gl-radio>
        </gl-radio-group>
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>
<script setup lang="ts">
import { calendar } from '@mysteel-standard/utils'
interface DateSetFormType {
  date?: any[]
  dateType: number //时间类型 0:公立 1:农历
  beginTime?: string
  endTime?: string
  frequency?: string //指标的频度类型（日度， 周度，月度）
  intervalType?: number //日期区间：0、全部日期，1、最后观察值，2、日期选择
  timeCount: number | null //时间计数：（后多少日、周、月、年）
  timeType: string | null //时间描述类型字符串（日， 周，月，年）
  dateSetTitle?: string
}
interface Props {
  dateSetForm: DateSetFormType
  dateSetVisible: boolean
  dateSetTitle?: string
  disabledDate?: Function
}
const props = withDefaults(defineProps<Props>(), {
  dateSetVisible: false,
  dateSetTitle: '日期设置',
  disabledDate: () => false
})
interface Emits {
  (e: 'update:dateSetVisible', val: boolean): void
  (e: 'set-date-ok', form: DateSetFormType): void
}
const emits = defineEmits<Emits>()
const dateSetFormData = computed<DateSetFormType>(() => props.dateSetForm)
const visible = computed({
  get() {
    return props.dateSetVisible
  },
  set(val: boolean) {
    emits('update:dateSetVisible', val)
  }
})
const radioStyle = reactive({
  display: 'flex',
  height: '30px',
  lineHeight: '30px',
  marginBottom: '30px'
})
const options = [
  { label: '观察值', value: '观察值' },
  { label: '日', value: '日' },
  { label: '周', value: '周' },
  { label: '月', value: '月' },
  { label: '年', value: '年' }
]
// 公历转农历-moment
const solar2lunar = (current: { year: () => any; month: () => number; date: () => any }) => {
  const lunar = calendar.solar2lunar(current.year(), current.month() + 1, current.date())
  return lunar.IDayCn // festival
}

const closeModal = () => {
  visible.value = false
}
//取消设置
const closeCalendarSetting = () => {
  closeModal()
}
// 保存设置
const saveCalendarSetting = () => {
  const { intervalType } = dateSetFormData.value
  if (intervalType === 0 || intervalType === 1) {
    dateSetFormData.value.beginTime = ''
    dateSetFormData.value.endTime = ''
  }
  if (intervalType !== 1) {
    dateSetFormData.value.timeCount = null
    dateSetFormData.value.timeType = null
  }
  emits('set-date-ok', dateSetFormData.value)
  closeModal()
}
</script>
<style scoped lang="scss">
.gl-radio-group.date-rang-group {
  flex-direction: column;
}
</style>
