<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-10-17 11:02:21
 * @Description: 富文本
-->
<template>
  <gl-modal
    :visible="visible"
    :title="title"
    centered
    :width="760"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <div class="font">
      <div class="combination">
        <gl-select
          v-model:value="state.collection.fontFamily"
          placeholder="请选择字体"
          class="wid-160"
          @change="change($event, 'fontFamily')"
        >
          <gl-select-option v-for="item in fontFamilyList" :key="item" :value="item">{{
            item
          }}</gl-select-option>
        </gl-select>
        <gl-input-number
          v-model:value="state.collection.fontSize"
          class="font-size"
          :min="12"
          :step="1"
          :precision="0"
          placeholder="请字号"
          @change="change($event, 'fontSize')"
        />
        <ul class="font-style">
          <div class="left">
            <li
              :class="`font-style-item font-weight ${
                state.collection.fontWeight === 'bold' ? 'active' : ''
              }`"
              @click="handleChange('bold', 'fontWeight')"
            >
              <icon name="icon-bold" class="icon" />
            </li>
            <li
              :class="`font-style-item italic ${
                state.collection.fontStyle === 'italic' ? 'active' : ''
              }`"
              @click="handleChange('italic', 'fontStyle')"
            >
              <icon name="icon-italic" class="icon" />
            </li>
            <li
              :class="`font-style-item underline ${
                state.collection.textDecoration === 'underline' ? 'active' : ''
              }`"
              @click="handleChange('underline', 'textDecoration')"
            >
              <icon name="icon-underline" class="icon" />
            </li>
          </div>
          <div v-show="type" class="right">
            <li
              :class="`font-style-item align-left ${
                state.collection.textAlign === 'left' ? 'active' : ''
              }`"
              @click="handleChange('left', 'textAlign')"
            >
              <icon name="icon-align_left" class="icon" />
            </li>
            <li
              :class="`font-style-item align-center ${
                state.collection.textAlign === 'center' ? 'active' : ''
              }`"
              @click="handleChange('center', 'textAlign')"
            >
              <icon name="icon-align_center" class="icon" />
            </li>
            <li
              :class="`font-style-item align-right ${
                state.collection.textAlign === 'right' ? 'active' : ''
              }`"
              @click="handleChange('right', 'textAlign')"
            >
              <icon name="icon-align_right" class="icon" />
            </li>
          </div>
        </ul>
      </div>
      <div class="text-area">
        <gl-textarea v-model:value="state.collection.name" :style="collectionStyle" />
      </div>
    </div>
  </gl-modal>
</template>
<script lang="ts" setup>
import { Icon } from '@mysteel-standard/components'
const FONT_FAMILY_LIST = ['微软雅黑', '楷体', '宋体', '黑体', '思源黑体CN', 'Tw Cen MT']
const DEFAULT_VALUE: any = {
  fontFamily: '楷体',
  fontWeight: 'normal',
  fontStyle: 'normal',
  textDecoration: 'none',
  textAlign: 'left',
  fontSize: 12
}

//props
interface Props {
  visible: boolean
  title: string
  font: object
  type?: boolean
}
const props = withDefaults(defineProps<Props>(), {
  visible: false,
  title: '编辑文本',
  type: true
})
//emits
interface Emits {
  (e: 'update:font', val: any): void
  (e: 'update:visible', val: any): void
}
const emits = defineEmits<Emits>()

const fontFamilyList = ref(FONT_FAMILY_LIST)
const state: { collection: any } = reactive({ collection: {} })

const collectionStyle = computed(() => ({
  ...state.collection,
  fontSize: `${state.collection.fontSize}px`
}))

const change = (e: string, key: string) => {
  state.collection = {
    ...state.collection,
    [key]: e
  }
}
const handleChange = (val: string, key: string) => {
  state.collection = {
    ...state.collection,
    [key]: state.collection[key] === val ? DEFAULT_VALUE[key] || '' : val
  }
}
const handleOk = () => {
  emits('update:font', {
    ...state.collection
  })
  emits('update:visible', false)
}
const handleCancel = () => {
  emits('update:visible', false)
}

watch(
  () => props.font,
  (newVal) => {
    state.collection = Object.assign(
      {},
      {
        ...DEFAULT_VALUE,
        ...newVal
      }
    )
  },
  //深度监听
  { deep: true, immediate: true }
)
</script>
<style lang="scss" scoped>
.font {
  .combination {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .font-size {
      width: 150px;
    }
    .font-style {
      display: flex;
      justify-content: space-between;
      width: 330px;
      &-item {
        float: left;
        width: 50px;
        height: 32px;
        line-height: 32px;
        text-align: center;
        cursor: pointer;
        border: 1px solid #dddddd;
        &:first-child {
          border-radius: 2px 0px 0px 2px;
        }
        &:last-child {
          border-radius: 0px 2px 2px 0px;
        }

        &:not(:first-child) {
          border-left: none;
        }

        &.active {
          background-color: #e5eff8;
          border-color: #80add5;
          border: 1px solid #80add5;
          .icon {
            color: #005bac;
          }
        }
      }
    }
  }
  :deep(.text-area) {
    margin-top: 15px;
    textarea.ant-input {
      min-height: 200px;
    }
  }
}
</style>
