/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-20 14:10:43
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-06-20 14:11:12
 * @Description:
 */
export { default as RichEditor } from './index.vue'
