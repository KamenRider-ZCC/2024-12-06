<template>
  <div
    ref="textareaRef"
    class="custom-textarea"
    :contentEditTable="contentEditTable"
    @focus="handleFocus"
    @blur="handleBlur"
    @input="($event:any) => handleInput()"
    v-html="text"
  ></div>
</template>
<script lang="ts" setup>
import { pasteCustomClipboardString, pasteExcelClipboardString } from '@mysteel-standard/utils'

//props
interface Props {
  value: string
  contentEditTable?: boolean | string
}
const props = withDefaults(defineProps<Props>(), {
  value: '',
  contentEditTable: false
})
//emits
interface Emits {
  (e: 'update-value', val: any): void
  (e: 'insert-excel-data', val: any): void
}
const emits = defineEmits<Emits>()

const textareaRef = ref()
const text = ref('')
const isFocus = ref(false)

// 自定义v-modal，同步数据
// 当文本框聚焦时，不执行数据同步
watch(
  () => props.value,
  () => {
    if (isFocus.value) return
    text.value = props.value
    if (textareaRef.value) textareaRef.value.innerHTML = props.value
  },
  { immediate: true }
)

const handleInput = () => {
  if (!textareaRef.value) return
  const text = textareaRef.value.innerHTML
  emits('update-value', text)
}

// 聚焦时更新焦点标记，并监听粘贴事件
const handleFocus = () => {
  isFocus.value = true
  if (!textareaRef.value) return
  textareaRef.value.onpaste = (e: any) => {
    e.preventDefault()
    if (!e.clipboardData) return

    const clipboardDataFirstItem = e.clipboardData.items[0]

    if (
      clipboardDataFirstItem &&
      clipboardDataFirstItem.kind === 'string' &&
      clipboardDataFirstItem.type === 'text/plain'
    ) {
      clipboardDataFirstItem.getAsString((text: string) => {
        const clipboardData = pasteCustomClipboardString(text)
        if (typeof clipboardData === 'object') return

        const excelData = pasteExcelClipboardString(text)
        if (excelData) {
          emits('insert-excel-data', excelData)
          if (textareaRef.value) {
            const [innerHTML] = excelData[0]
            textareaRef.value.innerHTML = innerHTML
          }
          return
        }

        emits('update-value', text)
        document.execCommand('insertText', false, text)
      })
    }
  }
}

// 失焦时更新焦点标记，清除粘贴事件监听
const handleBlur = () => {
  isFocus.value = false
  if (textareaRef.value) textareaRef.value.onpaste = null
}

// 清除粘贴事件监听
onUnmounted(() => {
  if (textareaRef.value) textareaRef.value.onpaste = null
})
</script>
<style lang="scss" scoped>
.custom-textarea {
  border: 0;
  outline: 0;
  cursor: pointer;
}
</style>
