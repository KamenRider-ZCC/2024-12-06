/*
 * @Autor: zouchuanfeng
 * @Date: 2023-09-18 16:43:52
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 16:40:03
 * @Description:
 */
/*
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-04 14:44:38
 * @Description:表格初始化
 */
import { bus } from '@mysteel-standard/utils'
export default () => {
  const INIT_ITEM = (bgColor: string) => ({
    editable: false,
    rowSpan: 1,
    colSpan: 1,
    text: '',
    itemStyle: {
      fontFamily: '微软雅黑',
      color: '#000000',
      fontSize: 14,
      fontWeight: 'normal',
      fontStyle: 'normal',
      textDecoration: 'none',
      textAlign: 'center',
      whiteSpace: 'normal',
      lineHeight: 14,
      backgroundColor: bgColor
    },
    indexItem: {
      checked: false,
      disabled: false,
      data: [],
      legendName: '指标名称',
      indexCode: '',
      calculation: {},
      calculationParam: {}
    },
    filters: [],
    isTimeFilter: false
  })

  return {
    INIT_ITEM
  }
}
