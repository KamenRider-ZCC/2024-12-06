/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-26 14:51:30
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-01 16:03:54
 * @Description: 指标计算
 */

export default () => {
  //指标计算
  const indicatorsVisible: Ref = ref(false)
  const indicatorsType: Ref = ref(2)
  const indexItem: Ref = ref({})

  const formFrequency = ref({
    changeType: 0,
    changeOption: 'yoy',
    seqPeriod: undefined,
    type: 1,
    period: 3,
    checked: true
  })

  const handleDerive = (type: number) => {
    if (type === 2) {
      Object.assign(formFrequency.value, {
        changeType: 0,
        changeOption: 'yoy',
        seqPeriod: undefined
      })
      return
    }
    if (type === 4) {
      Object.assign(formFrequency.value, {
        type: 1,
        period: 3,
        checked: true
      })
    }
  }

  return {
    formFrequency,
    indicatorsVisible,
    indicatorsType,
    indexItem,
    handleDerive
  }
}
