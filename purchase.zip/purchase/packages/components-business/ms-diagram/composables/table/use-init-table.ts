/*
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-10-17 16:40:33
 * @Description:表格初始化
 */
import { bus } from '@mysteel-standard/utils'
export default () => {
  const selectedCells: Ref = ref([])
  const matrixData: any = reactive([])
  const formState = reactive({
    row: '',
    col: ''
  })
  const addTableVisible = ref(false)
  const INIT_ITEM = (bgColor: string) => ({
    editable: false,
    rowSpan: 1,
    colSpan: 1,
    text: '',
    itemStyle: {
      fontFamily: '微软雅黑',
      color: '#000000',
      fontSize: 14,
      fontWeight: 'normal',
      fontStyle: 'normal',
      textDecoration: 'none',
      textAlign: 'center',
      whiteSpace: 'normal',
      lineHeight: 14,
      backgroundColor: bgColor
    },
    indexItem: {
      checked: false,
      disabled: false,
      data: [],
      legendName: '指标名称',
      indexCode: '',
      calculation: {}
    },
    filters: [],
    isTimeFilter: false
  })

  //打开表格
  const openTable = () => {
    addTableVisible.value = true
    formState.row = ''
    formState.col = ''
  }

  // table画布宽度
  const colTotalWidth = ref(0)
  // 默认边框及样式
  const outline = reactive({
    color: '#eeece1',
    style: 'solid',
    width: 1
  })

  const formatTableData = (row: any, col: any, isMatrix: boolean) => {
    for (let i = 0; i < row; i++) {
      const arr: any = []
      for (let j = 0; j < col; j++) {
        let p
        if (i == 0) {
          p = INIT_ITEM('#F4F4F4')
        } else {
          p = INIT_ITEM('')
        }
        arr.push(p)
      }
      if (!isMatrix) matrixData.push(arr)
    }
  }

  const initTable = () => {
    matrixData.splice(0, matrixData.length)
    formatTableData(formState.row, formState.col, false)
  }

  const submit = (formInfo: any) => {
    Object.assign(formState, formInfo)
    initTable()
    bus.emit('update-table-data', matrixData)
  }

  return {
    openTable,
    matrixData,
    selectedCells,
    colTotalWidth,
    outline,
    formState,
    addTableVisible,
    submit,
    INIT_ITEM
  }
}
