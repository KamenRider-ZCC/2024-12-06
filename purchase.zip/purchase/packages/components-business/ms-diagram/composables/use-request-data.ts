import { COLORS, INIT_OBJ, LAYOUT_TYPE } from '../constants/index'
import { getRandomColor } from '@mysteel-standard/utils'
import { generateImage } from '@mysteel-standard/utils'
import api from '../api/index'
import { message } from 'gl-design-vue'
import Vrouter from '@/router'
import { Modal } from 'gl-design-vue'
import { createVNode } from 'vue'
import { CheckCircleTwoTone } from '@ant-design/icons-vue'
import { calendar } from '@mysteel-standard/utils'
import { cloneDeep } from 'lodash-es'
import { ref, Ref } from 'vue'
export default ({
  state,
  props,
  spinning,
  seasonChecked,
  indexDataSeason,
  isEmpty,
  emits
}: {
  state: any
  props: any
  spinning: Ref
  seasonChecked: Ref
  indexDataSeason: any
  isEmpty: Ref
  emits: any
}) => {
  // 控制监听多次触发 请求快慢导致数据错位
  let requestLock = false
  let intervalId: any = null
  //获取参数
  const queryChart = () => {
    if (!requestLock) {
      getRequest()
    } else {
      if (intervalId) {
        clearInterval(intervalId)
      }
      intervalId = setInterval(() => {
        !requestLock && getRequest()
      }, 1000)
    }
  }

  const getRequest = () => {
    requestLock = true
    clearInterval(intervalId)
    if (state.curEl.id === 'bar-line') {
      if (seasonChecked.value) {
        const indexData = state.curEl.contentOption.indexOptionsBarLine.filter(
          (item: any) => item.indexCode === state.curEl.contentOption.seasonIndexCode
        )[0]
        getSeasonChart(indexData, indexDataSeason)
      } else {
        getChartTableData({})
      }
    } else if (
      state.curEl.id === 'sequence-table' ||
      state.curEl.id === 'free-table' ||
      state.curEl.id === 'template-table'
    ) {
      getChartTableData()
    } else if (state.curEl.id === 'chart-pie' || state.curEl.id === 'scatter-plot') {
      getPiePlotData()
    } else if (state.curEl.id === 'chart-radar') {
      getRadarData()
    }
  }

  //多个指标数据查询折线柱状图
  const getChartTableData = async (rangeDate = {}) => {
    spinning.value = true
    const { res, err } = await api.diagramMultiData({ ...state.extractParam, ...rangeDate })
    spinning.value = false
    if (!err && res) {
      const { datas } = res.data
      const result: any[] = []
      const dataValueList: any = []
      //防止curEl监听多次执行
      const temp = cloneDeep(state.curEl)
      const sourceNameArr = (datas || [])
        .filter((item: { sourceName: string }) => item.sourceName)
        .map((v: { sourceName: string }) => v.sourceName)
      const sourceNameStr = `数据来源：${[...new Set(sourceNameArr)].join('、')}`
      //回显老数据
      let oldIndexOptions: any = []
      if (state.curEl.id === 'bar-line') {
        oldIndexOptions = state.curEl.contentOption.indexOptionsBarLine
      } else {
        oldIndexOptions = state.curEl.contentOption.indexOptionsTable
      }
      datas.forEach((item: any, i: number) => {
        const oldData = oldIndexOptions.filter(
          (el: { indexCode: string }) => el.indexCode === item.indexCode
        )
        const indexItem = {
          ...INIT_OBJ[state.curEl.id],
          itemColor: COLORS[i] || getRandomColor(),
          legendName: item.indexShortName || item.indexName,
          indexName: item.indexName,
          indexCode: item.indexCode,
          frequency: item.frequency,
          isDerive: item.isDerive,
          decimalPlaces: item.decimalPlaces,
          ...oldData[0],
          data: item.dataVOS.map((ele: any) => ele.dataValue),
          dateList: item.dataVOS.map((ele: any) => ele.dataDate)
        }
        dataValueList.push(...indexItem.data)
        result.push(indexItem)
      })
      //判断是否有新下标
      if (
        temp.contentOption[LAYOUT_TYPE[state.curEl.id]].titleFont.footerTitle.name === '数据来源：'
      ) {
        temp.contentOption[LAYOUT_TYPE[state.curEl.id]].titleFont.footerTitle.name = sourceNameStr
      }
      if (state.curEl.id === 'bar-line') {
        //获取Y轴最小值
        const min = dataValueList
          .map((item: any) => Number(item))
          .filter((item: number) => !isNaN(item))
        temp.contentOption.yAxis[0].min =
          Math.min(...min) > 0
            ? Math.trunc(Math.min(...min) * 0.9)
            : Math.trunc(Math.min(...min) * 1.1)
        temp.contentOption.indexOptionsBarLine = result
      } else if (
        state.curEl.id === 'sequence-table' ||
        state.curEl.id === 'free-table' ||
        state.curEl.id === 'template-table'
      ) {
        temp.contentOption.indexOptionsTable = result
      }
      state.curEl = temp
    }
    requestLock = false
  }
  //多个指标数据查询饼图
  const getPiePlotData = async () => {
    spinning.value = true
    const { res, err } = await api.diagramMultiNewestData(state.extractParam)
    spinning.value = false
    if (!err && res) {
      const { newestDataVOS } = res.data
      const result: any[] = []
      //防止curEl监听多次执行
      const temp = cloneDeep(state.curEl)
      const sourceNameArr = (newestDataVOS || [])
        .filter((item: { sourceName: any }) => item.sourceName)
        .map((v: { sourceName: any }) => v.sourceName)
      const sourceNameStr = `数据来源：${[...new Set(sourceNameArr)].join('、')}`
      //回显老数据
      let oldIndexOptions: any = []
      if (state.curEl.id === 'chart-pie') {
        oldIndexOptions = state.curEl.contentOption.indexOptionsPie
      } else if (state.curEl.id === 'scatter-plot') {
        oldIndexOptions = state.curEl.contentOption.indexOptionsScatter
      }
      newestDataVOS.forEach((item: any, i: number) => {
        const oldData = oldIndexOptions.filter(
          (el: { indexCode: string }) => el.indexCode === item.indexCode
        )
        const indexItem = {
          ...INIT_OBJ[state.curEl.id],
          itemColor: COLORS[i] || getRandomColor(),
          legendName: item.indexShortName || item.indexName,
          indexCode: item.indexCode,
          ...oldData[0],
          data: item.dataValue
        }
        result.push(indexItem)
      })

      if (state.curEl.id === 'chart-pie') {
        temp.contentOption.indexOptionsPie = result
      } else if (state.curEl.id === 'scatter-plot') {
        temp.contentOption.indexOptionsScatter = result
      }
      //判断是否有新下标
      if (
        temp.contentOption[LAYOUT_TYPE[state.curEl.id]].titleFont.footerTitle.name === '数据来源：'
      ) {
        temp.contentOption[LAYOUT_TYPE[state.curEl.id]].titleFont.footerTitle.name = sourceNameStr
      }
      state.curEl = temp
    }
    requestLock = false
  }

  //多个指标数据查询雷达图
  const getRadarData = async () => {
    spinning.value = true
    const { res, err } = await api.diagramMultiDataRadar(state.extractParam)
    spinning.value = false
    if (!err && res) {
      const { datas, dateList, qoQDate, yoYDate } = res.data
      //防止curEl监听多次执行
      const temp = cloneDeep(state.curEl)
      const sourceNameArr = (datas || [])
        .filter((item: { sourceName: any }) => item.sourceName)
        .map((v: { sourceName: any }) => v.sourceName)
      const sourceNameStr = `数据来源：${[...new Set(sourceNameArr)].join('、')}`
      //判断是否有新下标
      if (
        temp.contentOption[LAYOUT_TYPE[state.curEl.id]].titleFont.footerTitle.name === '数据来源：'
      ) {
        temp.contentOption[LAYOUT_TYPE[state.curEl.id]].titleFont.footerTitle.name = sourceNameStr
      }
      temp.contentOption.data = datas.map((v: { dataVOS: any[] }) =>
        v.dataVOS.map((y: { dataValue: any }) => y.dataValue)
      )
      temp.contentOption.originData = datas
      temp.contentOption.dateList = dateList
      //回显老数据
      const oldIndexOptions = state.curEl.contentOption.indexOptionsRadar
      const oldRadarSettings = state.curEl.contentOption.radarSettings
      temp.contentOption.indexOptionsRadar = {
        ...INIT_OBJ[state.curEl.id],
        list: datas.map((i: { indexName: string; indexCode: string; indexShortName: string }) => {
          const oldData = oldIndexOptions.list.filter(
            (el: { indexCode: string }) => el.indexCode === i.indexCode
          )
          return {
            checked: true,
            indicatorName: i.indexShortName || i.indexName,
            indexCode: i.indexCode,
            ...oldData
          }
        })
      }
      temp.contentOption.legendLayoutRadar.legend.dates = [dateList[dateList.length - 1]]
      if (!temp.contentOption.legendLayoutRadar.legend?.updateRuleType) {
        temp.contentOption.legendLayoutRadar.legend.updateRuleType = 'newDate'
      }
      // 如果是自动更新
      const obj: any = {
        newDate: dateList[dateList.length - 1],
        qoQDate,
        yoYDate
      }
      for (const key in obj) {
        temp.contentOption.legendLayoutRadar.legend[key] = obj[key]
      }
      if (temp.contentOption.legendLayoutRadar.legend.autoChecked) {
        const typeArr = temp.contentOption.legendLayoutRadar.legend.updateRuleType.split(',')
        const valueArr = typeArr.map((item: string) => obj[item] || '')
        temp.contentOption.legendLayoutRadar.legend.dates = [...new Set(valueArr)]
        temp.contentOption.radarSettings.forEach((item: { xAxisValue: string }, index: number) => {
          item.xAxisValue = valueArr[index]
        })
      } else {
        temp.contentOption.radarSettings = temp.contentOption.legendLayoutRadar.legend.dates.map(
          (v: any, i: number) => {
            const oldData = oldRadarSettings.filter(
              (el: { xAxisValue: string }) => el.xAxisValue === v.xAxisValue
            )
            return {
              checked: true,
              xAxisValue: v,
              lineStyleType: 'solid',
              lineStyleWidth: 1,
              itemColor: COLORS[i] || getRandomColor(),
              dataFormat: 'slash',
              dataFrequency: 'YMD',
              ...oldData[0]
            }
          }
        )
      }
      state.curEl = temp
    }
    requestLock = false
  }

  //季节性分析接口
  const getSeasonChart = async (data: any, indexDataSeason: any) => {
    const rangeDate = state.curEl.contentOption.xAxis.rangeDate
    let deriveIndexes = [`{seasonalanalysis,$${data.indexCode}}`]
    if (data.isDerive) {
      deriveIndexes = [`{seasonalanalysis,${data.indexCode}}`]
    }
    const params: any = {
      deriveIndexes,
      beginTime: rangeDate.beginTime,
      endTime: rangeDate.endTime,
      indexCode: data.indexCode,
      frequency: data.frequency
    }
    if (rangeDate.intervalType === 'last') {
      params.intervalType = rangeDate.intervalType || 'last'
      params.timeCount = rangeDate.timeCount || 1
      params.timeType = rangeDate.timeType || '观察值'
    } else {
      delete params.intervalType
      delete params.timeCount
      delete params.timeType
    }
    spinning.value = true
    const { res, err } = await api.diagramGroupYearData(params)
    spinning.value = false
    if (!err && res) {
      //防止curEl监听多次执行
      const temp = cloneDeep(state.curEl)
      const dateType = temp.contentOption.xAxis.rangeDate.dateType
      const { datas, dateList } =
        dateType === 1 ? calendar.lunarSeasonAnalysis(res.data, res.data.frequency) : res.data
      const result: Array<any> = []
      let seasonOptions: any = {}
      if (JSON.stringify(temp.contentOption.seasonOptions) !== '{}') {
        seasonOptions = temp.contentOption.seasonOptions
      }
      const dataValueList: any = []
      datas.forEach((item: any, i: number) => {
        const indexItem = {
          itemColor: COLORS[i] || getRandomColor(),
          data: item.dataVOS.map((y: { dataValue: string }) => y.dataValue),
          dateList,
          legendName: item.year,
          frequency: item.frequency
        }
        dataValueList.push(...indexItem.data)
        result.push(indexItem)
        // 不存在的年份设置默认值
        if (!(item.year in temp.contentOption.seasonOptions)) {
          seasonOptions[item.year] = {
            checked: true,
            name: item.year,
            itemColor: indexItem.itemColor,
            lineStyleWidth: 1,
            lineStyleType: 'solid'
          }
        }
      })
      temp.contentOption.seasonOptions = seasonOptions
      //获取Y轴最小值
      const min = dataValueList
        .map((item: any) => Number(item))
        .filter((item: number) => !isNaN(item))
      temp.contentOption.yAxis[0].min =
        Math.min(...min) > 0
          ? Math.trunc(Math.min(...min) * 0.9)
          : Math.trunc(Math.min(...min) * 1.1)
      state.curEl = temp
      indexDataSeason.value = result
    }
    requestLock = false
  }

  //图表收藏
  const collectVisible: Ref = ref(false)

  //另存为
  const saveDiagram = (chartTitle: string) => {
    if (isEmpty.value) return
    if (state.curEl.id === 'sequence-table' || state.curEl.id === 'free-table') {
      if (state.curEl.tableData.length == 0) {
        message.warning('请先编辑表格')
        return
      }
    }
    state.folderForm.name = chartTitle
    collectVisible.value = true
  }

  //保存
  const updateDiagram = (type: number) => {
    if (isEmpty.value || props.chartId === 0) return
    if (state.curEl.id === 'sequence-table' || state.curEl.id === 'free-table') {
      if (state.curEl.tableData.length == 0) {
        message.warning('请先编辑表格')
        return
      }
    }
    addAndUpdateDiagram({ type })
  }

  //新增和修改
  const addAndUpdateDiagram = async ({ type, catalogueId, saveSpinning }: any) => {
    if (saveSpinning) {
      saveSpinning.value = true
    }
    const copyCurEl = cloneDeep(state.curEl)
    //去除config中data和datalist
    if (state.curEl.id === 'sequence-table' || state.curEl.id === 'free-table') {
      copyCurEl.contentOption.indexOptionsTable = copyCurEl.contentOption.indexOptionsTable.map(
        (item: any) => {
          return Object.assign(item, { data: [], dateList: [] })
        }
      )
    }
    if (state.curEl.id === 'bar-line') {
      copyCurEl.contentOption.indexOptionsBarLine = copyCurEl.contentOption.indexOptionsBarLine.map(
        (item: any) => {
          return Object.assign(item, { data: [], dateList: [] })
        }
      )
    }
    if (state.curEl.id === 'chart-radar') {
      copyCurEl.contentOption.data = []
      copyCurEl.contentOption.dateList = []
    }
    state.config = {
      extractParam: state.extractParam,
      curEl: copyCurEl,
      userId: JSON.parse(localStorage.getItem('userInfo') as string).id
    }
    if (
      state.curEl.id === 'bar-line' ||
      state.curEl.id === 'chart-pie' ||
      state.curEl.id === 'chart-radar' ||
      state.curEl.id === 'scatter-plot'
    ) {
      const chartDom = document.querySelector('.chart-container')
      const snapshot = await generateImage(chartDom)
      state.folderForm.imageUrl = snapshot
    } else {
      const tableDom = document.querySelector('.plus-table')
      const snapshot = await generateImage(tableDom)
      state.folderForm.imageUrl = snapshot
    }
    const params = {
      componentName: state.curEl.componentName,
      indexCodes: state.extractParam.indexCodes,
      type: 1,
      config: JSON.stringify(state.config),
      imageUrl: state.folderForm.imageUrl
    }
    const router = Vrouter
    //新增修改 type=0新增
    if (type === 0) {
      Object.assign(params, {
        label: state.folderForm.label,
        name: state.folderForm.name,
        catalogueId: catalogueId
      })
      const { res, err } = await api.addChart(params)
      saveSpinning.value = false
      if (!err && res) {
        message.success(res.message)
        collectVisible.value = false
        if (state.folderForm.checked) {
          router.push({
            path: '/home/chartCenter/chartManage',
            query: { tabIndex: 2 }
          })
        }
        //重置
        state.folderForm = {
          name: '',
          imageUrl: '',
          label: '',
          checked: false
        }
      }
    } else {
      Object.assign(params, {
        chartId: props.chartId
      })
      spinning.value = true
      const { err, res } = await api.updateChart(params)
      spinning.value = false
      if (!err && res) {
        if (type === 1) {
          //保存成功后提示框
          Modal.confirm({
            centered: true,
            title: '保存成功',
            icon: createVNode(CheckCircleTwoTone),
            content: '当前图表已保存成功',
            okText: '返回图表库',
            cancelText: '继续编辑',
            onOk: () => {
              router.push({
                path: '/home/chartCenter/chartManage',
                query: { tabIndex: 2 }
              })
            },
            onCancel() {
              return
            }
          })
        } else {
          message.success('保存成功！')
          emits('sure-save-chart')
        }
      }
    }
  }

  return {
    queryChart,
    getChartTableData,
    getRadarData,
    getSeasonChart,
    addAndUpdateDiagram,
    saveDiagram,
    updateDiagram,
    collectVisible
  }
}
