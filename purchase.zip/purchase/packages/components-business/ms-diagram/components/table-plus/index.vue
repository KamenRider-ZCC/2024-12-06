<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-21 11:41:16
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-11 11:12:17
 * @LastEditTime: 2023-09-19 16:58:48
 * @Description: 表格
-->
<template>
  <div v-if="!showTable" class="plus-table">
    <div class="plus-table-btn" @click="openTable">
      <icon size="55px" name="icon-add" />
    </div>
    <span class="plus-table-dsc">新建空白表格</span>
  </div>
  <div v-else class="plus-table table-content">
    <div style="position: relative" class="editor-table-content">
      <div ref="tableRef">
        <edit-table
          :data="matrixData"
          :outline="outline"
          @mousedown.stop
          @change="(data) => updateTableCells(data, matrixData)"
          @change-selected-cells="(cells) => updateSelectedCells(cells)"
          @calculation-fn="calculationFn"
        ></edit-table>
      </div>
    </div>
  </div>
  <!-- 新增表格弹窗 -->
  <add-table-modal
    v-model:addTableVisible="addTableVisible"
    :formState="formState"
    @submit="submit"
  ></add-table-modal>

  <calculation-modal
    v-model:indicatorsVisible="indicatorsVisible"
    :indicatorsType="indicatorsType"
    :extract-param="extractParam"
    :indexItem="indexItem"
    :cur-el="curEl"
    :formFrequency="formFrequency"
    :selectedCells="selectedCells"
    :matrixData="matrixData"
  ></calculation-modal>
  <filter-edit-dialog
    v-if="filterVisible"
    v-model:visible="filterVisible"
    title="添加数据筛选器"
    @ok-cb="addFilters"
  />
</template>

<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { message } from 'gl-design-vue'
import EditTable from '../../../edit-table/index.vue'
import FilterEditDialog from '../content-option/table/filter-com/filter-edit-dialog.vue'
import { cloneDeep } from 'lodash-es'
import { bus } from '@mysteel-standard/utils'
import AddTableModal from './add-table-modal.vue'
import CalculationModal from './calculation-modal.vue'
import useCalculation from '../../composables/table/use-calculation'
import useInitTable from '../../composables/table/use-init-table'
import useEditTable from '../../composables/table/use-edit-table'
import useSequenceTable from '../../composables/table/use-sequence-table'
import { Ref, ref, computed, onMounted, onUnmounted } from 'vue'
//props
interface Props {
  curEl: any
  extractParam: any
}
const props = withDefaults(defineProps<Props>(), {
  curEl: () => ({}),
  extractParam: () => ({})
})

const tableRef: Ref = ref(null)
const filterVisible = ref(false)

const showTable = computed(() => {
  return props.curEl.tableData.length > 0
})

//表格新增初始化
const { openTable, selectedCells, addTableVisible, formState, matrixData, outline, submit } =
  useInitTable()

//指数计算
const { formFrequency, indicatorsVisible, indicatorsType, indexItem, handleDerive } =
  useCalculation()

//表格功能
const {
  addFilters,
  addTimeFilter,
  updateTableCells,
  transformTable,
  updateLayoutTable,
  changeTableData,
  changeTableFilters,
  changeTableStyle
} = useEditTable()

//序列表更新
const { updateSequenceTable } = useSequenceTable()
//指标计算方法、筛选、排序
const calculationFn = (item: {}, type: number | null) => {
  if (type === 2 || type === 4) {
    indicatorsVisible.value = true
    indicatorsType.value = type
    indexItem.value = item
    handleDerive(type)
  } else if (type === 6) {
    if (selectedCells.value.length === 1) {
      const [x, y] = selectedCells.value[0].split('_')
      const filters = [...matrixData[x][y].filters]
      if (filters && filters.length) {
        message.error('只能添加一个筛选器')
        return
      }
    }
    filterVisible.value = true
  } else if (type === 7 || type === 8) {
    const [x, y] = selectedCells.value[0].split('_')
    matrixData.sort(
      (
        a: { [x: string]: { text: string | number } },
        b: { [x: string]: { text: string | number } }
      ) => (type === 8 ? +a[y].text - +b[y].text : +b[y].text - +a[y].text)
    )
  } else if (type === 9) {
    addTimeFilter(true, props.curEl.contentOption)
  } else if (type === 10) {
    addTimeFilter(false, props.curEl.contentOption)
  }
}
// 选择单元格事件回调
const updateSelectedCells = (cells: any) => {
  selectedCells.value = cloneDeep(cells)
  if (selectedCells.value.length === 1) {
    const rowIndex = selectedCells.value[0].split('_')[0]
    const colIndex = selectedCells.value[0].split('_')[1]
    const cellItem = matrixData[rowIndex][colIndex]
    updateLayoutTable({
      indexItem: cloneDeep(cellItem.indexItem),
      itemStyle: cloneDeep(cellItem.itemStyle),
      filters: cloneDeep(cellItem.filters),
      isTimeFilter: cloneDeep(cellItem.isTimeFilter),
      contentOption: props.curEl.contentOption
    })
  }
}
const resetBus = () => {
  bus.off('change-transpose')
  bus.off('change-table-data')
  bus.off('change-table-filters')
  bus.off('change-table-timeFilter')
  bus.off('change-table-style')
  bus.off('handle-edit-col-calculate')
}
onUnmounted(() => {
  resetBus()
})

onMounted(() => {
  resetBus()
  //转置
  bus.on('change-transpose', () => {
    transformTable(matrixData)
    bus.emit('update-table-data', matrixData)
  })
  //修改表格中的数据内容
  bus.on('change-table-data', (indexData: any) => {
    const { isTimeFilter } = props.curEl.contentOption
    changeTableData({ indexData, matrixData, selectedCells, isTimeFilter }, true)
    if (props.curEl.id === 'sequence-table' && indexData !== null) {
      selectedCells.value.forEach((selectedCell: string) => {
        // 判断选择格是否带指标
        const rowIndex = selectedCell.split('_')[0]
        const colIndex = selectedCell.split('_')[1]
        const cellData = matrixData[rowIndex][colIndex]
        if (cellData.indexItem && cellData.indexItem.indexCode !== '') {
          const param = {
            matrixData,
            indexData,
            selectedCells: selectedCell.split('_'),
            isTimeFilter
          }
          updateSequenceTable(props.curEl, param)
        }
      })
    }
    bus.emit('update-table-data', matrixData)
  })

  //修改表格中数据筛选器
  bus.on('change-table-filters', (filters: any) => {
    changeTableFilters({ filters, matrixData, selectedCells })
    bus.emit('update-table-data', matrixData)
    bus.emit('update-content-option', { filters })
  })

  //修改表格中时间筛选器
  bus.on('change-table-timeFilter', (isTimeFilter: any) => {
    const indexData = props.curEl.contentOption.indexOptionsTable?.filter(
      (item: { checked: boolean }) => item.checked
    )[0]
    changeTableData({ indexData, matrixData, selectedCells, isTimeFilter }, false)
    if (props.curEl.id === 'sequence-table') {
      //判断包含指标的单元格才进行时间筛选器的遍历
      selectedCells.value.forEach((cell: string) => {
        const rowIndex = cell.split('_')[0]
        const colIndex = cell.split('_')[1]
        const cellData = matrixData[rowIndex][colIndex]
        if (cellData.indexItem && cellData.indexItem.indexCode !== '') {
          const param = {
            matrixData,
            indexData,
            selectedCells: cell.split('_'),
            isTimeFilter
          }
          updateSequenceTable(props.curEl, param)
        }
      })
    }
    bus.emit('update-table-data', matrixData)
  })

  //修改表格中样式
  bus.on('change-table-style', (itemStyle: any) => {
    changeTableStyle({ itemStyle, matrixData, selectedCells })
    bus.emit('update-table-data', matrixData)
  })
  //回显表格数据
  bus.on('echo-table-data', (tableData: any) => {
    if (JSON.stringify(matrixData) === JSON.stringify(tableData)) return
    matrixData.length = 0
    selectedCells.value = []
    matrixData.push(...tableData)
  })
})
</script>
<style lang="scss" scoped>
.plus-table {
  text-align: center;
  width: 100%;
  min-height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  border-radius: 2px;

  &.table-content {
    border: none;
    overflow: auto;
  }
  .editor-table-content {
    width: 100%;
  }
  &-btn {
    width: 120px;
    height: 120px;
    line-height: 100px;
    text-align: center;
    font-size: 60px;
    background: #fafafa;
    border-radius: 50%;
    margin-bottom: 20px;
    cursor: pointer;
  }

  &-dsc {
    font-size: 16px;
    color: #5d5d5d;
  }
}
</style>
