<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-13 17:17:01
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-18 11:16:15
 * @Description: 图表类型切换
-->
<template>
  <div class="diagram-tabs">
    <div>
      <div class="title">图表</div>
      <div class="tabs">
        <div v-for="item in diagramIconList[0]" :key="item.id" @click="handleClick(item.id)">
          <div
            :class="`tab-item ${id === item.id ? 'active' : ''} ${isEmpty ? 'btn-disabled' : ''}`"
            v-if="checkPermit([item.permit])"
          >
            <icon :name="`icon-${item.id}`" :size="'20'" />
          </div>
        </div>
      </div>
    </div>
    <div>
      <div class="title">表格</div>
      <div class="tabs">
        <div v-for="item in diagramIconList[1]" :key="item.id" @click="handleClick(item.id)">
          <div
            :class="`tab-item ${id === item.id ? 'active' : ''} ${isEmpty ? 'btn-disabled' : ''}`"
            v-if="checkPermit([item.permit])"
          >
            <icon :name="`icon-${item.id}`" :size="'20'" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { Icon } from '@mysteel-standard/components'
import { DIAGRAM_ICON_LIST } from '../../constants'
import { message } from 'gl-design-vue'
import { ExtractParam } from '../../types/interface'
import { checkPermit } from '@mysteel-standard/hooks'
//props
interface Props {
  id: string
  extractParam: ExtractParam
  isEmpty: boolean
}
const props = defineProps<Props>()
//emits
interface Emits {
  (e: 'change-component', val: string): void
}
const emits = defineEmits<Emits>()

const diagramIconList = DIAGRAM_ICON_LIST
const activeId = ref('')

//判断平度
const isIdenticalFrequencyFn = (data: any[]) => {
  const obj: any = {}
  data?.forEach((item: { frequency: string }) => {
    obj[String(item.frequency)] = 1
  })
  return Object.keys(obj).length <= 1
}

const handleClick = (id: string) => {
  if (activeId.value == id) return
  const isIdenticalFrequency = isIdenticalFrequencyFn(props.extractParam.indexData)
  if (id === 'chart-radar' && !isIdenticalFrequency) {
    message.warning('请使用相同频度指标')
    return
  }
  activeId.value = id
  emits('change-component', id)
}
</script>
<style lang="scss" scoped>
.diagram-tabs {
  height: 100%;
  width: 104px;

  .title {
    padding: 8px;
    height: 20px;
    font-size: 14px;
    font-family:
      PingFangSC-Medium,
      PingFang SC;
    font-weight: bold;
    color: #333333;
    line-height: 20px;
  }
  .tabs {
    display: flex;
    flex-wrap: wrap;
    margin-top: 8px;
    .tab-item {
      margin: 4px;
      width: 40px;
      height: 40px;
      border-radius: 3px;
      border: 1px solid #e8e8e8;
      cursor: pointer;
      padding: 9px;
      &.active {
        color: #0149aa;
        border: 1px solid #0149aa;
        background: #edf4ff;
      }
    }
  }
}
.btn-disabled {
  pointer-events: none;
  color: #797979;
}
</style>
