/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-13 17:24:35
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-03 16:13:20
 * @Description: 右侧属性组件入口文件
 */

import Chart from './chart.vue'
import Table from './table.vue'
import indexOptionsBarLine from './content-option/bar-line/index-options-chart.vue'
import LegendLayout from './content-option/bar-line/legend-layout.vue'
import xAxis from './content-option/bar-line/xAxis.vue'
import yAxis from './content-option/bar-line/yAxis.vue'
import IndexOptionsPie from './content-option/chart-pie/index-options-pie.vue'
import LegendLayoutPie from './content-option/chart-pie/legend-layout-pie.vue'
import PieLabel from './content-option/chart-pie/pie-label.vue'
import PieSettings from './content-option/chart-pie/pie-settings.vue'
import IndexOptionsScatter from './content-option/scatter-plot/index-options-scatter.vue'
import LegendLayoutScatter from './content-option/scatter-plot/legend-layout-scatter.vue'
import ScatterXAxis from './content-option/scatter-plot/scatter-xAxis.vue'
import ScatterYAxis from './content-option/scatter-plot/scatter-yAxis.vue'
import IndexOptionsRadar from './content-option/chart-radar/index-options-radar.vue'
import LegendLayoutRadar from './content-option/chart-radar/legend-layout-radar.vue'
import RadarAxisLine from './content-option/chart-radar/radar-axis-line.vue'
import RadarSettings from './content-option/chart-radar/radar-settings.vue'
import IndexOptionsTable from './content-option/table/index-options-table.vue'
import LayoutTable from './content-option/table/layout-table.vue'

export default {
  chart: Chart,
  table: Table,
  indexOptionsBarLine: indexOptionsBarLine,
  legendLayout: LegendLayout,
  xAxis: xAxis,
  yAxis: yAxis,
  indexOptionsPie: IndexOptionsPie,
  legendLayoutPie: LegendLayoutPie,
  pieLabel: PieLabel,
  pieSettings: PieSettings,
  indexOptionsScatter: IndexOptionsScatter,
  legendLayoutScatter: LegendLayoutScatter,
  scatterXAxis: ScatterXAxis,
  scatterYAxis: ScatterYAxis,
  indexOptionsRadar: IndexOptionsRadar,
  legendLayoutRadar: LegendLayoutRadar,
  radarAxisLine: RadarAxisLine,
  radarSettings: RadarSettings,
  indexOptionsTable: IndexOptionsTable,
  layoutTable: LayoutTable
}
