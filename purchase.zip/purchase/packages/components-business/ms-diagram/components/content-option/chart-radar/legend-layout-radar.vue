<template>
  <div class="legend-layout-radar">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 19 }"
      label-align="left"
    >
      <gl-form-item label="标题" label-align="right" :wrapper-col="{ span: 18 }">
        <gl-switch
          v-model:checked="form.titleFont.headerTitle.show"
          class="f-r"
          size="small"
        ></gl-switch>
      </gl-form-item>
      <gl-form-item label="页脚" label-align="right" :wrapper-col="{ span: 18 }">
        <gl-switch
          v-model:checked="form.titleFont.footerTitle.show"
          class="f-r"
          size="small"
        ></gl-switch>
      </gl-form-item>
      <gl-collapse
        accordion
        expand-icon-position="left"
        :bordered="false"
        v-model:activeKey="collapseKey"
      >
        <template #expandIcon="{ isActive }">
          <caret-right-outlined :rotate="isActive ? 90 : 0" />
        </template>
        <gl-collapse-panel key="legend" header="图例">
          <gl-form-item label="自动更新">
            <gl-switch
              v-model:checked="form.legend.autoChecked"
              size="small"
              class="f-r"
              @change="handleChange"
            />
          </gl-form-item>
          <gl-form-item label="更新规则">
            <gl-select
              v-model:value="form.legend.updateRuleType"
              :disabled="!form.legend.autoChecked"
              @change="handleChangeType"
            >
              <gl-select-option v-for="item in RADAR_OPTIONS" :key="item.label" :value="item.value">
                {{ item.label }}
              </gl-select-option>
            </gl-select>
          </gl-form-item>
          <gl-form-item label="数据范围">
            <gl-select
              v-model:value="form.legend.dates"
              class="wid-240"
              mode="multiple"
              placeholder="请添加日期"
              :show-arrow="true"
              :max-tag-count="1"
              :get-popup-container="(triggerNode: any) => triggerNode.parentNode"
              :disabled="form.legend.autoChecked"
              @deselect="handleDeselect"
            >
              <template #dropdownRender>
                <gl-tag
                  v-for="(i, index) in form.legend.dates"
                  :key="i"
                  class="select-tag"
                  :closable="form.legend.dates.length > 1"
                  @close.prevent="
                    () => {
                      handleRemoveDate(i, index)
                    }
                  "
                  >{{ i }}</gl-tag
                >
              </template>
              <template #suffixIcon>
                <span @click="handleDateAdd">
                  <plus-outlined />
                </span>
              </template>
            </gl-select>
          </gl-form-item>
          <gl-form-item label="字体">
            <font-collection v-model:font="form.legend.textStyle" :show-color="false" />
          </gl-form-item>
          <gl-form-item label="位置">
            <position-radio v-model:value="form.legend.position" />
          </gl-form-item>
        </gl-collapse-panel>
      </gl-collapse>
    </gl-form>
    <gl-modal
      :visible="dateDialogData.isShow"
      width="450px"
      title="添加日期"
      @cancel="dateDialogData.isShow = false"
      @ok="handleConfirm"
    >
      <div v-for="(i, index) in dateDialogData.dates" :key="index" class="date-picker-wrapper">
        <gl-date-picker
          v-model:value="i.value"
          style="width: 380px"
          :disabledDate="disabledDate"
          placeholder="请添加日期"
          value-format="YYYY-MM-DD"
        />
        <span
          class="delete-button"
          :class="{ active: !!i.value }"
          @click="!!i.value && dateDialogData.dates.splice(index, 1)"
        >
          <delete-outlined />
        </span>
      </div>

      <gl-button class="add-button" type="primary" @click="handleAddDate">
        <template #icon>
          <plus-outlined />
        </template>
        新增
      </gl-button>
    </gl-modal>
  </div>
</template>

<script lang="ts" setup>
import { CaretRightOutlined, PlusOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import { getRandomColor, bus } from '@mysteel-standard/utils'
import FontCollection from '../font-collection.vue'
import PositionRadio from '../position-radio.vue'
import { RADAR_OPTIONS } from '../../../constants'
import dayjs from 'dayjs'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()
//emits
interface Emits {
  (e: 'change-radar', val: Object): void
}
const emits = defineEmits<Emits>()

const collapseKey = ref('legend')

const dateDialogData = reactive({
  isShow: false,
  dates: [{ value: null }]
})

const form = computed({
  get() {
    return props.contentOption.legendLayoutRadar
  },
  set(val) {
    bus.emit('update-content-option', {
      legendLayoutRadar: val,
      radarSettings: newRadarSettings.value
    })
  }
})

const newRadarSettings = computed(() => {
  const { radarSettings: oldRadarSettings, colors } = props.contentOption
  return dateDialogData.dates.map((v, k) => {
    const defaultValue = {
      checked: true,
      xAxisValue: v.value,
      lineStyleType: 'solid',
      lineStyleWidth: 2,
      itemColor: colors[k] || getRandomColor(),
      dataFormat: 'slash',
      dataFrequency: 'YMD'
    }
    const oldValue = oldRadarSettings.find(
      (v1: { xAxisValue: string }) => v1.xAxisValue === v.value
    )
    if (oldValue) {
      oldValue.itemColor = colors[k] || getRandomColor()
    }
    return oldValue || defaultValue
  })
})
const disabledDate = (current: string) => {
  const dateList = props.contentOption.dateList || []
  if (dateList.length > 0) {
    const date = dayjs(current).format('YYYY-MM-DD')
    if (dateList.indexOf(date) === -1) {
      return true
    }
    return false
  }
  return true
}

const handleRemoveDate = (i: any, index: number) => {
  const { length } = form.value.legend.dates
  if (length > 1) {
    const copy = JSON.parse(JSON.stringify(form.value.legend.dates))
    copy.splice(index, 1)
    form.value.legend.dates = copy
    dateDialogData.dates = form.value.legend.dates.map((value: string) => ({ value }))
    bus.emit('update-content-option', {
      legendLayoutRadar: form.value,
      radarSettings: newRadarSettings.value
    })
  }
}

const handleChange = () => {
  emits('change-radar', form.value.legend.autoChecked)
}

const handleChangeType = (val: string) => {
  const typeArr = val.split(',')
  const valueArr = typeArr.map((item: string | number) => form.value.legend[item] || '')
  form.value.legend.dates = [...new Set(valueArr)]
  dateDialogData.dates = form.value.legend.dates.map((value: any) => ({ value }))
  bus.emit('update-content-option', {
    legendLayoutRadar: form.value,
    radarSettings: newRadarSettings.value
  })
}

const handleDateAdd = () => {
  if (form.value.legend.autoChecked) return
  dateDialogData.isShow = true
  dateDialogData.dates = form.value.legend.dates.map((v: any) => ({ value: v }))
}

const handleAddDate = () => {
  if (dateDialogData.dates.length < 12) {
    dateDialogData.dates.push({ value: null })
  }
}
const handleConfirm = () => {
  const d = dateDialogData.dates
    .filter((v) => v.value)
    .map((v) => dayjs(v.value).format('YYYY-MM-DD'))
  const setD = [...new Set(d)]
  if (setD.length > 0) {
    form.value.legend.dates = [...new Set(d)]
    dateDialogData.isShow = false
    dateDialogData.dates = form.value.legend.dates.map((value: string) => ({ value }))
    bus.emit('update-content-option', {
      legendLayoutRadar: form.value,
      radarSettings: newRadarSettings.value
    })
  }
}
const handleDeselect = () => {
  dateDialogData.dates = form.value.legend.dates.map((value: any) => ({ value }))
  bus.emit('update-content-option', {
    legendLayoutRadar: form.value,
    radarSettings: newRadarSettings.value
  })
}
</script>
<style lang="scss" scoped>
.date-picker-wrapper {
  display: flex;

  align-items: center;
  width: 100%;
  margin-bottom: 10px;
}
.add-button {
  width: 380px;
}
.delete-button {
  margin-left: 10px;
  width: 12px;
  &.active {
    color: #005bac;
  }
}

.select-tag {
  display: block;
  margin: 5px;
  color: #005bac;
  width: 100px;
  border-radius: 1px;
  height: 25px;
  line-height: 25px;
  background: #e5eff8;
  :deep(.ant-tag-close-icon) {
    color: #005bac;
    margin-left: 10px;
  }
}
</style>
