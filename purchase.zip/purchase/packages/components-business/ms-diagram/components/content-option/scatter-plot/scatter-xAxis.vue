<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-08 18:22:42
 * @Description: 指标chart配置
-->
<template>
  <div class="scatter-x-axis">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 18 }"
      label-align="left"
    >
      <gl-form-item label="单位">
        <gl-input
          v-model:value="form.name"
          :maxlength="50"
          class="wid-240"
          placeholder="请输入单位"
        />
      </gl-form-item>
      <gl-form-item label="字体">
        <font-collection v-model:font="form.nameTextStyle" />
      </gl-form-item>
      <gl-form-item label="线型">
        <gl-select
          v-model:value="form.axisLine.lineStyle.type"
          class="wid-240"
          placeholder="请选择线型"
        >
          <gl-select-option v-for="item in BORDER_TYPE" :key="item.value" :value="item.value">{{
            item.label
          }}</gl-select-option>
        </gl-select>
      </gl-form-item>
      <gl-form-item label="宽度">
        <gl-input-number
          v-model:value="form.axisLine.lineStyle.width"
          :min="0"
          placeholder="请输入宽度"
          class="wid-240"
        />
      </gl-form-item>
      <gl-form-item label="颜色">
        <color-input v-model:value="form.axisLine.lineStyle.color" class="wid-240" />
      </gl-form-item>
      <gl-form-item label="最小值">
        <gl-input-number
          v-model:value="form.min"
          :max="limit.min"
          placeholder="请输入最小值"
          class="wid-240"
        />
      </gl-form-item>

      <gl-form-item label="最大值">
        <gl-input-number
          v-model:value="form.max"
          :min="limit.max"
          placeholder="请输入最大值"
          class="wid-240"
        />
      </gl-form-item>
      <gl-form-item label="数据步长">
        <gl-input-number
          v-model:value="form.interval"
          :min="0"
          :max="limit.xMaxInterval"
          placeholder="最小单位"
          class="wid-240"
        />
      </gl-form-item>
    </gl-form>
  </div>
</template>
<script setup lang="ts">
import { BORDER_TYPE } from '../../../constants'
import { ColorInput } from '@mysteel-standard/components'
import { bus } from '@mysteel-standard/utils'
import FontCollection from '../font-collection.vue'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const form = computed(() => props.contentOption.scatterXAxis)

const limit = computed(() => {
  const { indexOptionsScatter } = props.contentOption
  const datas = indexOptionsScatter
    .filter((y: { checked: boolean }) => y.checked)
    .map((item: { relatedIndexCode: any; axis: string; data: any }) => {
      let relateData = 0
      if (item.relatedIndexCode) {
        relateData =
          indexOptionsScatter.filter(
            (query: { indexCode: string }) => query.indexCode === item.relatedIndexCode
          )[0]?.data || 0
      }
      const curData = item.axis === 'x' ? item.data : relateData
      return curData
    })
  const maxData = Math.max(...datas) || 0
  const minData = Math.min(...datas) || 0
  const xMaxInterval = Math.abs(maxData) + Math.abs(minData)
  return {
    max: maxData,
    min: minData,
    xMaxInterval
  }
})

onMounted(() => {
  bus.on('resetValue', () => {
    form.value.min = ''
    form.value.max = ''
    form.value.interval = ''
    limit.value.max = 0
    limit.value.min = 0
    limit.value.xMaxInterval = 0
  })
})
</script>
<style lang="scss" scoped>
.scatter-x-axis {
  padding-left: 20px;
}
</style>
