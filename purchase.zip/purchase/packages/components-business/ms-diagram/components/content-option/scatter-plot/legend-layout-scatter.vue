<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-03 16:22:07
 * @Description: 指标chart配置
-->
<template>
  <div class="legend-layout-scatter">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 19 }"
      label-align="left"
    >
      <gl-form-item label="标题" label-align="right" :wrapper-col="{ span: 18 }">
        <gl-switch
          v-model:checked="form.titleFont.headerTitle.show"
          class="f-r"
          size="small"
        ></gl-switch>
      </gl-form-item>
      <gl-form-item label="页脚" label-align="right" :wrapper-col="{ span: 18 }">
        <gl-switch
          v-model:checked="form.titleFont.footerTitle.show"
          class="f-r"
          size="small"
        ></gl-switch>
      </gl-form-item>
      <gl-collapse
        accordion
        expand-icon-position="left"
        :bordered="false"
        v-model:activeKey="collapseKey"
      >
        <template #expandIcon="{ isActive }">
          <caret-right-outlined :rotate="isActive ? 90 : 0" />
        </template>
        <gl-collapse-panel key="splitLine" header="网格线">
          <gl-form-item label="横向网格线" :label-col="{ span: 6 }" :wrapper-col="{ span: 18 }">
            <gl-switch v-model:checked="form.ySplitLine.show" class="f-r" size="small"></gl-switch>
          </gl-form-item>
          <gl-form-item label="线型">
            <gl-select
              v-model:value="form.ySplitLine.lineStyle.type"
              class="wid-240"
              placeholder="请选择线型"
            >
              <gl-select-option v-for="item in BORDER_TYPE" :key="item.value" :value="item.value">{{
                item.label
              }}</gl-select-option>
            </gl-select>
          </gl-form-item>
          <gl-form-item label="宽度">
            <gl-input-number
              v-model:value="form.ySplitLine.lineStyle.width"
              :min="1"
              :step="1"
              :precision="0"
              placeholder="请输入宽度"
              class="wid-240"
            />
          </gl-form-item>
          <gl-form-item label="颜色">
            <color-input v-model:value="form.ySplitLine.lineStyle.color" class="wid-240" />
          </gl-form-item>

          <gl-form-item label="纵向网格线" :label-col="{ span: 6 }">
            <gl-switch v-model:checked="form.xSplitLine.show" class="f-r" size="small"></gl-switch>
          </gl-form-item>
          <gl-form-item label="线型">
            <gl-select
              v-model:value="form.xSplitLine.lineStyle.type"
              class="wid-240"
              placeholder="请选择线型"
            >
              <gl-select-option v-for="item in BORDER_TYPE" :key="item.value" :value="item.value">{{
                item.label
              }}</gl-select-option>
            </gl-select>
          </gl-form-item>
          <gl-form-item label="宽度">
            <gl-input-number
              v-model:value="form.xSplitLine.lineStyle.width"
              :min="1"
              :step="1"
              :precision="0"
              placeholder="请输入宽度"
              class="wid-240"
            />
          </gl-form-item>
          <gl-form-item label="颜色">
            <color-input v-model:value="form.xSplitLine.lineStyle.color" class="wid-240" />
          </gl-form-item>
        </gl-collapse-panel>
      </gl-collapse>
    </gl-form>
  </div>
</template>
<script setup lang="ts">
import { BORDER_TYPE } from '../../../constants'
import { ColorInput } from '@mysteel-standard/components'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

//选中指标
const collapseKey = ref('splitLine')

const form = computed(() => props.contentOption.legendLayoutScatter)
</script>
<style lang="scss" scoped></style>
