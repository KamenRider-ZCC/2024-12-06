<!--
 * @Author: Wong Tsong
 * @LastEditTime: 2023-06-16 11:50:29
 * @Description: 
-->
<template>
  <ul class="position-radio">
    <li
      v-for="item in posArr"
      :key="item"
      :class="['radio-item', item, active === item ? 'active' : '']"
      @click="handleClick(item)"
    >
      <icon :name="`icon-${item}`" class="icon" />
    </li>
  </ul>
</template>

<script lang="ts" setup>
import { Icon } from '@mysteel-standard/components'
interface Props {
  value: string
}

const props = withDefaults(defineProps<Props>(), {
  value: ''
})

interface Emits {
  (e: 'update:value', val: Object): void
}
const emits = defineEmits<Emits>()

const posArr = ['top', 'left', 'bottom', 'right']

const active = computed(() => {
  return props.value
})

const handleClick = (item: string) => {
  emits('update:value', item)
}
</script>

<style lang="scss" scoped>
.position-radio {
  display: flex;
  .radio-item {
    width: 32px;
    height: 32px;
    line-height: 32px;
    text-align: center;
    border: 1px solid #dddddd;
    &:first-child {
      border-radius: 2px 0px 0px 2px;
    }
    &:last-child {
      border-radius: 0px 2px 2px 0px;
    }

    &:not(:first-child) {
      border-left: none;
    }

    &.active {
      background-color: #e5eff8;
      border-color: #80add5;
      border: 1px solid #80add5;
      .icon {
        color: #005bac;
      }
    }
  }
}
</style>
