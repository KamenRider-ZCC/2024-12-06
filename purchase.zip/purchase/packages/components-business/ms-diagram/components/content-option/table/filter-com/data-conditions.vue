<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-04 19:32:12
 * @Description: 数据条件
-->
<template>
  <div class="data-conditions">
    <header class="header">
      <span>数据条件</span>
      <div class="hander">
        <icon class="icon add" name="icon-add" @click="handleAdd" />
        <icon v-if="groupTabs.length > 1" class="icon" name="icon-minus" @click="handleDelete" />
      </div>
    </header>
    <gl-tabs v-model:activeKey="tabKey" class="tabs" @change="changeTab">
      <gl-tab-pane v-for="(item, index) in groupTabs" :key="index" :tab="item.label">
        <div class="conditons">
          <number-filter v-model:filterData="item.condition.start" class="number-filter" />
          <span class="mid">~</span>
          <number-filter v-model:filterData="item.condition.end" class="number-filter" />
        </div>
        <div class="choose font-choose">
          <gl-switch v-model:checked="item.fontColor.checked" size="small"></gl-switch>
          <span class="des">字体颜色</span>
          <color-input v-model:value="item.fontColor.color" class="wid-240" />
        </div>
        <div class="choose bg-choose">
          <gl-switch v-model:checked="item.backgroundColor.checked" size="small"></gl-switch>
          <span class="des">背景颜色</span>
          <color-input v-model:value="item.backgroundColor.color" class="wid-240" />
        </div>
      </gl-tab-pane>
    </gl-tabs>
  </div>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import NumberFilter from './number-filter.vue'
import { ColorInput } from '@mysteel-standard/components'
//props
interface Props {
  filterCollection: Array<any>
}
const props = withDefaults(defineProps<Props>(), {
  filterCollection: () => []
})
//emits
interface Emits {
  (e: 'update:filterCollection', val: any): void
}
const emits = defineEmits<Emits>()

const tabKey = ref(0)
const changeTab = (newTab: number) => {
  tabKey.value = newTab
}
const groupTabs = computed({
  get() {
    return props.filterCollection
  },
  set(val) {
    emits('update:filterCollection', val)
  }
})
const handleAdd = () => {
  const item = {
    label: `样式${groupTabs.value.length + 1}`,
    condition: {
      start: { value: 0, relation: 'gt' },
      end: { value: 0, relation: 'lt' }
    },
    fontColor: {
      checked: true,
      color: '#DDDDDD'
    },
    backgroundColor: {
      checked: true,
      color: '#DDDDDD'
    }
  }
  groupTabs.value.push(item)
  groupTabs.value.map((col, index) => {
    col.label = `样式${index + 1}`
  })
}
const handleDelete = () => {
  groupTabs.value.splice(tabKey.value, 1)
  tabKey.value = 0
}
</script>
<style lang="scss" scoped>
.data-conditions {
  .ant-tabs-tab {
    font-size: 14px;
  }
  .header {
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    .add {
      margin-right: 20px;
    }
  }
  .tabs {
    padding: 20px;
    margin-top: 10px;
    border-radius: 2px;
    border: 1px solid #dddddd;
    .conditons,
    .choose {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
      .number-filter {
        width: 120px;
      }
      .mid {
        margin: 0 20px;
      }
      .des {
        margin: 0 20px 0 8px;
      }
    }
  }
}
</style>
