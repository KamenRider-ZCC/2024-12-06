<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-01 15:57:01
 * @Description: 筛选器弹窗
-->
<template>
  <gl-modal :title="title" :visible="visible" @ok="confirmFiter" @cancel="cancelFiter">
    <gl-form ref="filterRule" :model="filterForm" autocomplete="off" label-align="left">
      <gl-form-item
        label="数据筛选器名称"
        name="filterName"
        :rules="[{ required: true, message: '请输入数据筛选器名称', trigger: 'blur' }]"
      >
        <gl-input
          v-model:value="filterForm.filterName"
          class="wid-240"
          placeholder="请输入数据筛选器名称"
        />
      </gl-form-item>
      <gl-form-item label="" name="filterCollection">
        <data-conditions v-model:filterCollection="filterForm.filterCollection" />
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>
<script setup lang="ts">
import { cloneDeep } from 'lodash-es'
import DataConditions from './data-conditions.vue'
//props
interface Props {
  title: string
  visible: boolean
  record?: any
}
const props = withDefaults(defineProps<Props>(), {
  title: '',
  visible: false,
  record: () => ({
    filterName: '',
    filterCollection: [
      {
        label: '样式1',
        condition: {
          start: { value: 0, relation: 'gt' },
          end: { value: 0, relation: 'lt' }
        },
        fontColor: {
          checked: true,
          color: '#DDDDDD'
        },
        backgroundColor: {
          checked: true,
          color: '#DDDDDD'
        }
      }
    ]
  })
})
//emits
interface Emits {
  (e: 'update:visible', val: boolean): void
  (e: 'ok-cb', val: Object): void
}
const emits = defineEmits<Emits>()

const filterRule: Ref = ref(null)
const filterForm = reactive({
  filterName: '',
  filterCollection: []
})

watchEffect(() => {
  filterForm.filterName = props.record.filterName
  filterForm.filterCollection = props.record.filterCollection
})

const confirmFiter = () => {
  filterRule.value.validate().then(async () => {
    emits('update:visible', false)
    emits('ok-cb', cloneDeep(filterForm))
    filterRule.value && filterRule.value.resetFields()
  })
}
const cancelFiter = () => {
  emits('update:visible', false)
  filterRule.value && filterRule.value.resetFields()
}
</script>
<style lang="scss" scoped></style>
