<!--
 * @Author: your Name
 * @LastEditTime: 2023-07-04 19:45:55
 * @Description: 
-->
<template>
  <span class="filter-container">
    <span class="condition">
      <slot></slot>
    </span>

    <gl-dropdown overlay-class-name="filter-overlay" :trigger="['click']">
      <template #overlay>
        <gl-menu>
          <gl-menu-item
            v-for="item in LOGIC_MAP"
            :key="item.value"
            :class="`${relation === item.value ? 'active' : ''}`"
            @click="handleChoose(item.value)"
          >
            <a href="javascript:;" v-html="item.label"></a>
          </gl-menu-item>
        </gl-menu>
      </template>
      <a class="ant-gl-dropdown-link" @click="(e:any) => e.preventDefault()">
        <span class="label-con" v-html="transfromRelation"></span>
        <caret-down-outlined style="font-size: 8px" />
      </a>
    </gl-dropdown>
  </span>
</template>

<script setup lang="ts">
import { CaretDownOutlined } from '@ant-design/icons-vue'
//props
interface Props {
  relation: string
}
const props = withDefaults(defineProps<Props>(), {
  relation: 'e'
})
//emits
interface Emits {
  (e: 'change', val: any): void
}
const emits = defineEmits<Emits>()

const LOGIC_MAP = [
  { value: 'lt', label: '&lt;' },
  { value: 'lte', label: '&lt;=' },
  { value: 'e', label: '=' },
  { value: 'gt', label: '&gt;' },
  { value: 'gte', label: '&gt;=' }
]

const transfromRelation = computed(() => {
  const relationItem = LOGIC_MAP.find((item) => item.value === props.relation)
  return relationItem?.label || ''
})

const handleChoose = (value: string) => {
  emits('change', value)
}
</script>

<style lang="scss" scoped>
.filter-container {
  display: flex;
  align-items: center;

  .condition {
    flex: 1;
    margin-top: -1px;
  }
  .ant-gl-dropdown-link {
    height: 32px;
    width: 32px;
    margin-top: -1px;
    line-height: 32px;
    text-align: center;
    color: #000000;
    border: 1px solid#dddddd;
    border-left: none;
    border-radius: 0 2px 2px 0;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
</style>

<style lang="scss">
.filter-overlay {
  .ant-gl-dropdown-menu {
    &-item:hover,
    &-submenu-title:hover {
      color: #005bac;
      background-color: #e5eff8;
    }

    &-item,
    &-item a {
      color: #005bac;
    }

    &-item.active {
      background-color: #e5eff8;
    }
    &-submenu-arrow-icon {
      color: #005bac;
    }
  }
}
</style>
