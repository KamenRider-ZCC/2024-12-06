<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-07-06 20:14:43
 * @Description: 表格指标属性 
-->
<template>
  <div class="table-options">
    <ul class="table-options-ul">
      <li
        v-for="(item, index) in indexList"
        :key="index"
        class="table-options-ul_item"
        :class="item.checked ? 'active' : ''"
        @click="handleItem(item)"
      >
        {{ item.legendName }}
      </li>
    </ul>
    <data-select :content-option="contentOption" />
  </div>
</template>

<script setup lang="ts">
import DataSelect from './filter-com/data-select.vue'
import { bus } from '@mysteel-standard/utils'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const indexList = computed(() => props.contentOption.indexOptionsTable)

const handleItem = (item: { checked: boolean }) => {
  indexList.value.forEach((val: { checked: boolean; calculation: {} }) => {
    val.checked = false
    val.calculation = {}
  })
  item.checked = true
  bus.emit('change-table-data', item)
}
</script>
<style scoped lang="scss">
.table-options {
  display: flex;
  flex-direction: column;
  height: 100%;

  .table-layout-operation {
    flex: 1;
    overflow-y: auto;
  }

  &-ul {
    padding: 10px 0;
    flex: 1;
    overflow-y: auto;

    &_item {
      padding: 0 10px;
      width: 100%;
      height: 40px;
      line-height: 40px;
      border-radius: 6px;
      font-size: 14px;
      overflow: hidden;
      text-overflow: ellipsis;
      cursor: pointer;

      &.active {
        background: #e5eff8;
        color: #005bac;
      }
    }
  }
}
</style>
