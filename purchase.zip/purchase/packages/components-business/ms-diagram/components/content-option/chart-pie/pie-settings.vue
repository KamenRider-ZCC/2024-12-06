<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-03 09:19:02
 * @Description: 指标chart配置
-->
<template>
  <div class="pie-settings">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 19 }"
      label-align="left"
    >
      <gl-form-item label="内圈半径">
        <gl-input-number
          v-model:value="form.radiusIn"
          :min="0"
          :precision="0"
          placeholder="请输入内圈半径"
          class="wid-240"
        />
      </gl-form-item>
      <gl-form-item label="外圈半径">
        <gl-input-number
          v-model:value="form.radiusOut"
          :min="0"
          :precision="0"
          placeholder="请输入外圈半径"
          class="wid-240"
        />
      </gl-form-item>
      <gl-form-item label="旋转">
        <gl-input-number
          v-model:value="form.startAngle"
          :min="0"
          :precision="0"
          placeholder="请输入角度"
          class="wid-240"
        />
      </gl-form-item>
    </gl-form>
  </div>
</template>
<script lang="ts" setup>
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const form = computed(() => props.contentOption.pieSettings)
</script>
<style lang="scss" scoped>
.pie-settings {
  padding-left: 20px;
}
</style>
