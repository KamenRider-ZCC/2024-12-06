<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-03 09:18:51
 * @Description: 指标chart配置
-->
<template>
  <div class="pie-label">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 19 }"
      label-align="left"
    >
      <gl-form-item label="显示内容">
        <gl-select
          v-model:value="form.formatter"
          class="wid-240"
          mode="multiple"
          show-arrow
          placeholder="请选择显示内容"
        >
          <gl-select-option
            v-for="item in multipleLabelArr"
            :key="item.format"
            :value="item.format"
            >{{ item.label }}</gl-select-option
          >
        </gl-select>
      </gl-form-item>

      <gl-form-item label="字体">
        <font-collection v-model:font="form.textStyle" :show-color="true" />
      </gl-form-item>
      <gl-form-item label="位置">
        <gl-radio-group v-model:value="form.position">
          <gl-radio-button value="outside">外部显示</gl-radio-button>
          <gl-radio-button value="inside">内部显示</gl-radio-button>
        </gl-radio-group>
      </gl-form-item>
    </gl-form>
  </div>
</template>
<script lang="ts" setup>
import FontCollection from '../font-collection.vue'
import { MULTIPLE_LABEL } from '../../../constants'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const multipleLabelArr = reactive(MULTIPLE_LABEL)

const form = computed(() => props.contentOption.pieLabel)
</script>
<style lang="scss" scoped>
.pie-label {
  padding-left: 20px;
}
</style>
