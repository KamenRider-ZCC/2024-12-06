<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-07-12 13:54:00
 * @Description: 指标chart配置
-->
<template>
  <div class="index-options-pie">
    <gl-collapse
      accordion
      expand-icon-position="left"
      :bordered="false"
      v-model:activeKey="collapseKey"
    >
      <template #expandIcon="{ isActive }">
        <caret-right-outlined :rotate="isActive ? 90 : 0" />
      </template>
      <gl-collapse-panel
        v-for="(item, index) in indexList"
        :key="index"
        :collapsible="item.disabled + ''"
      >
        <template #header>
          <gl-checkbox v-model:checked="item.checked"></gl-checkbox>
          <gl-tooltip placement="top" :title="item.legendName" trigger="hover">
            <span class="option-collapse-title ellipsis"> {{ item.legendName }}</span>
          </gl-tooltip>
        </template>
        <gl-form
          :model="item"
          :colon="false"
          :label-col="{ span: 5 }"
          :wrapper-col="{ span: 18 }"
          label-align="left"
        >
          <gl-form-item label="图例名称">
            <gl-input
              v-model:value="item.legendName"
              class="wid-240"
              placeholder="请输入图例名称"
            />
          </gl-form-item>

          <gl-form-item label="颜色">
            <color-input v-model:value="item.itemColor" class="wid-240" />
          </gl-form-item>
        </gl-form>
      </gl-collapse-panel>
    </gl-collapse>
  </div>
</template>
<script lang="ts" setup>
import { CaretRightOutlined } from '@ant-design/icons-vue'
import { ColorInput } from '@mysteel-standard/components'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const indexList = computed(() => props.contentOption.indexOptionsPie)

//选中指标
const collapseKey = ref(0)
</script>
<style lang="scss" scoped>
.index-options-pie {
  .option-collapse-title {
    display: inline-block;
    max-width: 300px;
    vertical-align: middle;
    margin-left: 8px;
  }
}
</style>
