<template>
  <div class="font">
    <gl-select
      v-model:value="collection.fontFamily"
      placeholder="请选择字体"
      @change="change($event, 'fontFamily')"
    >
      <gl-select-option v-for="item in fontFamilyList" :key="item" :value="item">{{
        item
      }}</gl-select-option>
    </gl-select>
    <color-input
      style="margin-top: 20px"
      v-if="showColor"
      v-model:value="collection.color"
      @change-color="change($event, 'color')"
    />
    <div class="combination">
      <gl-input-number
        v-model:value="collection.fontSize"
        class="font-size"
        :min="12"
        :step="1"
        :precision="0"
        placeholder="请字号"
        @change="change($event, 'fontSize')"
      />
      <ul class="font-collection">
        <li
          :class="`font-collection-item font-weight ${
            collection.fontWeight === 'bold' ? 'active' : ''
          }`"
          @click="handleChange('bold', 'fontWeight')"
        >
          <icon name="icon-bold" class="icon" />
        </li>
        <li
          :class="`font-collection-item italic ${
            collection.fontStyle === 'italic' ? 'active' : ''
          }`"
          @click="handleChange('italic', 'fontStyle')"
        >
          <icon name="icon-italic" class="icon" />
        </li>
        <li
          :class="`font-collection-item underline ${
            collection.textDecoration === 'underline' ? 'active' : ''
          }`"
          @click="handleChange('underline', 'textDecoration')"
        >
          <icon name="icon-underline" class="icon" />
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { FONT_FAMILY_LIST } from '../../constants'
import { ColorInput } from '@mysteel-standard/components'
const DEFAULT_VALUE: any = {
  fontWeight: 'normal',
  fontStyle: 'normal',
  textDecoration: 'none'
}

interface Props {
  showColor?: boolean
  font: object
}

const props = withDefaults(defineProps<Props>(), {
  showColor: true,
  font: () => {
    return {
      fontFamily: '',
      color: '#333333',
      fontSize: 12,
      fontWeight: 'normal',
      fontStyle: 'normal',
      textDecoration: 'none'
    }
  }
})

interface Emits {
  (e: 'update:font', val: Object): void
  (e: 'change-style', val: any): void
}
const emits = defineEmits<Emits>()

const collection: any = computed(() => props.font)
const fontFamilyList: any = reactive(FONT_FAMILY_LIST)

const change = (e: Event, key: string) => {
  emits('update:font', {
    ...collection.value,
    [key]: e
  })
  emits('change-style', {
    [key]: e
  })
}

const handleChange = (val: string, key: string) => {
  emits('update:font', {
    ...collection.value,
    [key]: collection.value[key] === val ? DEFAULT_VALUE[key] || '' : val
  })
  emits('change-style', {
    [key]: collection.value[key] === val ? DEFAULT_VALUE[key] || '' : val
  })
}
</script>

<style lang="scss" scoped>
.font {
  .combination {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 20px;
    .font-size {
      width: 106px;
    }
    .font-collection {
      width: 280px;
      margin-left: 20px;
      margin-bottom: 0;
      &-item {
        float: left;
        width: 40px;
        height: 32px;
        line-height: 32px;
        text-align: center;
        cursor: pointer;
        border: 1px solid #dddddd;
        &:first-child {
          border-radius: 2px 0px 0px 2px;
        }
        &:last-child {
          border-radius: 0px 2px 2px 0px;
        }

        &:not(:first-child) {
          border-left: none;
        }

        &.active {
          background-color: #e5eff8;
          border-color: #80add5;
          border: 1px solid #80add5;
          .icon {
            color: #005bac;
          }
        }
      }
    }
  }
}
</style>
