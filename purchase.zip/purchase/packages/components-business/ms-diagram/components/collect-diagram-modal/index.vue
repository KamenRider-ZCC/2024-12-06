<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-29 10:34:24
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-18 11:19:02
 * @Description: 图表收藏
-->
<template>
  <gl-modal
    :title="'图表另存为'"
    v-model:visible="visible"
    class="chart-collect"
    :body-style="{
      height: '420px',
      overflow: 'auto'
    }"
    :confirm-loading="saveSpinning"
    @ok="confirmBtn"
    @cancel="cancelBtn"
  >
    <div>
      <div class="tab-group">
        <ms-tabs
          class="tab"
          v-model:value="tabIndex"
          :tabs="tabData"
          v-if="checkPermit(['sjzx:sjk:bcdgstbk'])"
          @change="(e:any) => tabClick(e)"
        />
      </div>
      <div class="collect-tree">
        <chart-tree
          ref="treeRef"
          :tabItem="tabItem"
          @update-loading="updateLoading"
          @get-catalogue-item="getCatalogueItem"
        />
      </div>
    </div>
    <gl-form ref="formRef" :model="formInfo" :rules="rules" label-align="right">
      <gl-form-item label="图表名称" name="name">
        <gl-input v-model:value="formInfo.name" :maxlength="50" placeholder="请输入图表名称" />
      </gl-form-item>
      <!-- <gl-form-item label="图表标签" name="label">
        <TInput
          v-model:value="formInfo.label"
          :maxlength="50"
          placeholder="请输入标签，以“,”隔开"
          :regex="/[^\a-\z\A-\Z0-9\u4E00-\u9FA5\,]/g"
        />
      </gl-form-item> -->
      <gl-form-item label="" name="checked"
        ><gl-checkbox v-model:checked="formInfo.checked">保存后跳转到图表中心</gl-checkbox>
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>

<script setup lang="ts">
import { message } from 'gl-design-vue'
import { MsTabs } from '@mysteel-standard/components'
import ChartTree from '../../../chart-tree/index.vue'
import { TabList, TabItem } from '../../types/interface'
import { enumToArray } from '@mysteel-standard/utils'
import { checkPermit } from '@mysteel-standard/hooks'
//props
interface Props {
  chartId: number
  collectVisible: boolean
  folderForm: any
  curEl: any
  seasonChecked: boolean
  extractParam: any
  indexDataSeason: any
}
const props = defineProps<Props>()
//emits
interface Emits {
  (e: 'add-and-update-diagram', val: Object): void
  (e: 'update:collectVisible', val: Object): void
}

const emits = defineEmits<Emits>()

const visible = computed(() => {
  return props.collectVisible
})

//选择树
const catalogueId = ref(-1)
const loading = ref(false)
const updateLoading = (flag: boolean) => {
  loading.value = flag
}
const treeRef = ref()
const tabData = ref(enumToArray(TabList))
const tabIndex = ref(TabList['公司图表库'])
const tabItem = computed(() => {
  return tabData.value.filter((item: TabItem) => item.value === tabIndex.value)[0]
})
// 切换树
const tabClick = (e: { target: { value: number } }) => {
  const { value } = e.target
  nextTick(() => {
    let label = ''
    if (value === 1) {
      label = '公司图表库'
    } else if (value === 2) {
      label = '我的图表库'
    }
    let parent = [{ label: label, id: 0, isLeaf: false, children: [] }]
    treeRef.value.getTree(parent)
  })
}
const getCatalogueItem = (item: any) => {
  catalogueId.value = item.id === undefined ? -1 : item.id
}

onMounted(() => {
  const label = checkPermit(['sjzx:sjk:bcdgstbk']) ? '公司图表库' : '我的图表库'
  tabIndex.value = checkPermit(['sjzx:sjk:bcdgstbk']) ? 1 : 2
  nextTick(() => {
    treeRef.value.getTree([{ label: label, id: 0, isLeaf: false, children: [] }])
  })
})
//表格信息
const formInfo: any = computed(() => {
  return props.folderForm
})
const rules = {
  name: [{ required: true, message: '请输入图表名称', trigger: 'blur' }]
}

//确认
const formRef: Ref = ref(null)
const confirmBtn = () => {
  if (catalogueId.value === -1) {
    message.warning('请选择目录')
    return
  }
  if (catalogueId.value === 0) {
    message.warning('不能放在根目录')
    return
  }
  formRef.value.validate().then(() => {
    emits('add-and-update-diagram', { type: 0, catalogueId: catalogueId.value, saveSpinning })
  })
}

//保存方法

const saveSpinning = ref(false)

//取消
const cancelBtn = () => {
  if (formRef.value) {
    formRef.value.resetFields()
  }
  // 重置选中状态
  catalogueId.value = -1
  emits('update:collectVisible', false)
}
</script>

<style lang="scss" scoped>
.chart-collect {
  .tab-group {
    margin: 0 auto 16px;
    width: 208px;
  }
  .collect-tree {
    border: 1px solid #dddddd;
    margin-bottom: 20px;
    height: 200px;
    overflow-y: auto;
    margin-top: 10px;
  }
}
</style>
