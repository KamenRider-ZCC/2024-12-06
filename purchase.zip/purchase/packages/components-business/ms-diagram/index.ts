/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-12 14:06:15
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-06-19 11:53:06
 * @Description:
 */
export { default as MsDiagram } from './index.vue'
