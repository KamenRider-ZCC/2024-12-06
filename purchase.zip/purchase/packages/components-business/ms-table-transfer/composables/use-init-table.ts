/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-25 16:56:35
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-15 14:24:13
 * @Description:
 */
import { cloneDeep } from 'lodash-es'
export default () => {
  const columns = [
    {
      title: '指标编码',
      dataIndex: 'code',
      width: 140,
      fixed: 'left'
    },
    {
      title: '指标名称',
      dataIndex: 'label'
    }
  ]

  // 数据源
  const leftIndexList: any = ref([])
  const rightIndexList: any = ref([])
  //存储搜索前数据
  const leftIndexList_temp: any = ref([])
  const rightIndexList_temp: any = ref([])
  // 勾选内容
  const leftSelectedList: any = ref([])
  const rightSelectedList: any = ref([])

  const leftSelectedRowKeys: any = reactive([])
  const rightSelectedRowKeys: any = reactive([])

  const leftRowSelection = {
    selectedRowKeys: leftSelectedRowKeys,
    onChange: (selectedRowKeys: string[], selectedRows: any[]) => {
      leftSelectedRowKeys.length = 0
      leftSelectedRowKeys.push(...selectedRowKeys)
      leftSelectedList.value = selectedRows

      addClick()
    },
    getCheckboxProps: (record: any) => ({
      disabled: !record.isOptional
    })
  }

  const rightRowSelection = {
    selectedRowKeys: rightSelectedRowKeys,
    onChange: (selectedRowKeys: string[], selectedRows: any[]) => {
      rightSelectedRowKeys.length = 0
      rightSelectedRowKeys.push(...selectedRowKeys)
      rightSelectedList.value = selectedRows
    }
  }

  //添加
  const addClick = () => {
    //过滤重复指标
    let temList = cloneDeep(leftSelectedList.value)
    rightIndexList.value.forEach((item: { code: string }) => {
      temList = temList.filter((ele: { code: string }) => ele.code !== item.code)
    })
    rightIndexList.value.push(...temList)
    rightIndexList_temp.value = cloneDeep(rightIndexList.value)
  }
  //批量删除
  const multipleDel = () => {
    rightSelectedList.value.forEach((item: any) => {
      rightIndexList.value = rightIndexList.value.filter((ele: any) => item.code !== ele.code)
      rightIndexList_temp.value = rightIndexList_temp.value.filter(
        (ele: any) => item.code !== ele.code
      )
    })
    const newList: string[] = []
    leftSelectedRowKeys.forEach((item: string) => {
      if (!rightSelectedRowKeys.includes(item)) {
        newList.push(item)
      } else {
        leftSelectedList.value = leftSelectedList.value.filter((ele: any) => item !== ele.code)
      }
    })
    rightSelectedList.value = []
    rightSelectedRowKeys.length = 0
    leftSelectedRowKeys.length = 0
    leftSelectedRowKeys.push(...newList)
  }
  return {
    columns,
    leftIndexList,
    rightIndexList,
    leftIndexList_temp,
    rightIndexList_temp,
    leftSelectedList,
    rightSelectedList,
    leftRowSelection,
    rightRowSelection,
    addClick,
    multipleDel
  }
}
