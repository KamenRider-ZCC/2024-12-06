/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-21 16:25:20
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-25 17:01:02
 * @Description:
 */
export { default as MsTableTransfer } from './index.vue'
