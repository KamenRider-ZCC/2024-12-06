/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-19 10:30:28
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-22 13:56:46
 * @Description:
 */
/// <reference types="vite/client" />
declare module '*.vue' {
  import { defineComponent } from 'vue'
  const Component: ReturnType<typeof defineComponent>
  export default Component
}
declare module 'gl-design-vue'
declare module 'moment'
declare module '@mysteel-standard/components'
declare module '@ant-design/icons-vue'
declare module 'crypto-js'
declare module 'lodash-es'
declare module '@mysteel-standard/apis'
declare module '@mysteel-standard/hooks'
