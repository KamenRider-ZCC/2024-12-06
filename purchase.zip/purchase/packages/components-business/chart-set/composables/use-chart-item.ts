import { message } from 'gl-design-vue'
import dayjs from 'dayjs'
import { useGetChart } from '@mysteel-standard/hooks'
import { watch, ref, reactive, computed, onMounted } from 'vue'
export default (props: any) => {
  const indexValue = ref<any[]>([])
  const options = ref([])
  const dateForm = reactive<any>({
    date: [],
    dateType: 0, //时间类型 0:公立 1:农历
    timeCount: null, //日期区间 最后：（日、周、月、年）
    timeType: null, //时间描述类型字符串（日， 周，月，年）
    intervalType: null
  })
  const chartId = computed(() => props.element?.id || props.element?.propsValue?.param?.id)
  const { loading, seasonChecked, indexDataSeason, tableData, curEl, initChart, state } =
    useGetChart()
  const elementName = computed(() => props.element?.elName || curEl.value?.componentName)
  //指标筛选
  watch(
    () => indexValue.value,
    (newValue, oldValue) => {
      if (oldValue.length === 7 && newValue.length > 7) {
        message.warning('最多筛选7个指标!')
        indexValue.value = oldValue
        return
      }
      if (oldValue.length === 1 && newValue.length === 0) {
        message.warning('请筛选最少1个指标!')
        indexValue.value = oldValue
        return
      }
      const deriveIndexArr = state.extractParam?.indexData?.filter(
        (item: any) => indexValue.value.includes(item.indexCode) && item.isDerive
      )
      const deriveIndexes: any[] = []
      deriveIndexArr?.map((item: any) => {
        deriveIndexes.push(item.indexCode)
      })
      const indexCodes = indexValue.value?.filter((item: any) => !deriveIndexes.includes(item))
      state.extractParam = {
        ...state.extractParam,
        indexCodes,
        deriveIndexObjs: deriveIndexArr?.map((item: any) => {
          return {
            indexCode: item.indexCode,
            unit: item.unit,
            indexName: item.indexName,
            frequency: item.frequency,
            decimalPlaces: item.decimalPlaces,
            indexShortName: item.indexShortName
          }
        }) // 衍生指标
      }
      if (oldValue.length && newValue.length) {
        initChart(chartId.value)
      }
    }
  )
  //时间选择
  const handleDateChange = (data: any) => {
    Object.assign(dateForm, data)
    const { date, dateType, intervalType, timeCount, timeType } = dateForm
    const beginTime = (date && date[0] && dayjs(date[0]).format('YYYY-MM-DD')) || ''
    const endTime = (date && date[1] && dayjs(date[1]).format('YYYY-MM-DD')) || ''
    state.extractParam = {
      ...state.extractParam,
      beginTime,
      endTime,
      dateType,
      intervalType,
      timeCount,
      timeType
    }
    initChart(chartId.value)
  }

  onMounted(async () => {
    if (elementName.value === 'text' || elementName.value === 'image') return
    await initChart(chartId.value)
    options.value = state.extractParam?.indexData?.map((item: any) => {
      return {
        value: item.indexCode,
        label: item.indexShortName || item.indexName
      }
    })
    indexValue.value = options.value?.slice(0, 7).map((item) => item.value)
    const { beginTime, endTime, dateType, timeCount, timeType, intervalType } = state.extractParam
    const formData = {
      date: [beginTime, endTime],
      dateType,
      timeCount,
      timeType,
      intervalType
    }
    Object.assign(dateForm, formData)
  })

  return {
    loading,
    seasonChecked,
    indexDataSeason,
    tableData,
    curEl,
    indexValue,
    options,
    handleDateChange,
    elementName,
    initChart,
    state,
    dateForm
  }
}
