/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-19 16:16:55
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 10:41:21
 * @Description:
 */
import { message } from 'gl-design-vue'
import { useChartHeight } from '@mysteel-standard/hooks'
export default () => {
  const pageData = reactive<any>({
    width: 794,
    height: 800,
    gap: 16,
    scale: 1,
    title: '',
    pages: []
  })
  const isEmpty = ref(false)
  const { resetWrapperHeight } = useChartHeight(3.61, '#page-view-content')
  const getPageData = async (configData: any) => {
    if (!configData) {
      message.warning('页面没有内容！')
      return
    }
    if (configData.pages && configData.pages[0].elements.length) {
      isEmpty.value = false
      // resetWrapperHeight(configData.pages)
      for (const key in configData) {
        pageData[key] = configData[key]
      }
    } else {
      isEmpty.value = true
    }
  }

  return {
    getPageData,
    isEmpty
  }
}
