<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-20 17:00:10
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-07 09:38:17
 * @Description: 
-->
<template>
  <gl-modal
    v-model:visible="collectVisible"
    :title="title"
    :body-style="{
      height: '380px',
      overflow: 'auto'
    }"
    @ok="handleSubmit"
  >
    <gl-spin :spinning="loading">
      <chart-tree
        ref="treeRef"
        :tabItem="selectTab"
        @update-loading="updateLoading"
        @get-catalogue-item="getCatalogueItem"
      />
    </gl-spin>
  </gl-modal>
</template>
<script setup lang="ts">
import { message } from 'gl-design-vue'
import ChartTree from '../../chart-tree/index.vue'
import { computed, ref, reactive, toRefs, onMounted } from 'vue'
interface Props {
  visible: boolean | any
  title: string | any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'update:visible', val: boolean): void
  (e: 'handle-submit', item: any): void
}
const emits = defineEmits<Emits>()

const collectVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})
const treeRef = ref()
const state = reactive({
  loading: false,
  selectTab: {
    value: 2,
    label: '我的图表库',
    name: '我的图表库'
  },
  selectItem: {}
})
const { loading, selectTab } = toRefs(state)
const updateLoading = (flag: boolean) => {
  state.loading = flag
}

const getCatalogueItem = (item: any) => {
  state.selectItem = item
}
const handleSubmit = () => {
  if (!state.selectItem) {
    message.error('请选择目录')
    return
  }
  emits('handle-submit', state.selectItem)
}
onMounted(() => {
  let parent = [{ label: '我的图表库', id: 0, isLeaf: false, children: [] }]
  treeRef.value && treeRef.value.getTree(parent)
})
</script>
