<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-19 16:03:28
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-21 16:45:54
 * @Description: 品种研究图集展示页面
-->
<template>
  <div :class="['element-wrapper-cht' + element.uuid, 'element-wrapper-cht']">
    <!-- <component
      v-if="elementName"
      :is="components[elementName]"
      :style="{
        ...getCommonStyle({
          top: 0,
          left: 0
        }),
        width: '100%',
        height: '100%'
      }"
      v-bind="{
        ...element.propsValue, //其他组件（图片、文字）
        elName: element.elName || curEl?.componentName,
        curEl,
        indexDataSeason,
        tableData,
        seasonChecked,
        uuid: element.uuid,
        editable: false,
        isPhone
      }"
    /> -->
  </div>
</template>

<script setup lang="ts">
// import ChartComponents from '../../editor/components'
import { editorProjectConfig } from '@mysteel-standard/utils'
import { computed } from 'vue'
// const components: any = ChartComponents
interface Props {
  element: any
  curEl?: any
  indexDataSeason?: any
  tableData?: any
  seasonChecked?: any
  isPhone?: boolean
}
const props = defineProps<Props>()
const { getCommonStyle } = editorProjectConfig
const elementName = computed(() => props.curEl.componentName || props.element.elName)
</script>

<style scoped lang="scss">
.element-wrapper-cht {
  flex: 1;
  position: relative;
  height: 100%;
}
</style>
