<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-20 17:00:10
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 10:41:15
 * @Description: 品种研究（图集页面）
-->
<template>
  <div
    class="page-view engine-template-content page-preview-wrapper"
    id="page-view-content"
    :style="{
      position: 'relative',
      width: '100%',
      height: '100%'
    }"
  >
    <template v-if="!isEmpty">
      <div
        v-for="page in configData.pages"
        :key="page.uuid"
        class="engine-template-pages"
        :style="{
          ...getCommonStyle({
            height: page.height
          }),
          display: 'flex',
          gap: '16px',
          marginBottom: '16px'
        }"
      >
        <chart-item
          v-for="item in page.elements"
          :key="item.uuid"
          :element="item"
          :style="{
            ...getCommonStyle({ top: 0, left: 0 }),
            position: 'unset',
            width: '100%',
            height: '100%'
          }"
          :collectAble="collectAble"
          :isConfig="isConfig"
        >
        </chart-item>
      </div>
    </template>
    <empty v-else />
  </div>
</template>

<script setup lang="ts">
import ChartItem from './chart-item/index.vue'
import { Empty } from '@mysteel-standard/components'
import { editorProjectConfig } from '@mysteel-standard/utils'
import useChartSet from './composables/use-chart-set'
import { watch } from 'vue'
interface Props {
  pageId: Number
  collectAble?: boolean //收藏
  isConfig?: boolean //是否是配置页面
  configData: any
}
const props = defineProps<Props>()
const { getCommonStyle } = editorProjectConfig
const { getPageData, isEmpty } = useChartSet()

watch(
  () => props.configData,
  (val: any) => {
    getPageData(val)
  },
  { deep: true }
)
</script>

<style scoped lang="scss">
:deep(.database-chart) {
  height: calc(100% - 48px) !important;
}
:deep(.database-chart.database-table),
:deep(.chart-radar),
:deep(.chart-season-checked) {
  height: 100% !important;
}
</style>
