<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-24 13:35:36
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-18 17:20:50
 * @Description: 
-->
<template>
  <div class="chart-set-tree">
    <gl-spin :spinning="loading">
      <div class="tab-group">
        <ms-tabs class="tab" v-model:value="tabIndex" :tabs="tabData" @change="changeTab" />
      </div>
      <div class="tree-wrap">
        <ms-tree
          v-show="tabIndex === TabList['公司图表库']"
          v-model:selected-keys="companySelectedKeys"
          v-model:expanded-keys="companyExpandedKeys"
          block-node
          :tree-data="companyTreeData"
          :field-names="replaceFields"
          @select="nodeClick"
          @expand="companyExpand"
          isMenu
        />
        <ms-tree
          v-show="tabIndex === TabList['我的图表库']"
          v-model:selected-keys="myChartSelectedKeys"
          v-model:expanded-keys="myChartExpandedKeys"
          block-node
          isMenu
          :tree-data="myChartTreeData"
          :field-names="replaceFields"
          @select="nodeClick"
          @expand="myChartExpand"
        />
      </div>
    </gl-spin>
  </div>
</template>
<script setup lang="ts">
import { ref } from 'vue'
import { enumToArray } from '@mysteel-standard/utils'
import { MsTree, MsTabs } from '@mysteel-standard/components'
import useChartTree from './composables/use-chart-tree'
interface Emits {
  (e: 'get-chart-list', data: Object): void
}
const emits = defineEmits<Emits>()
enum TabList {
  公司图表库 = 1,
  我的图表库 = 2
}
const tabIndex = ref(TabList['公司图表库'])
const tabData = ref(enumToArray(TabList))
const {
  loading,
  //公司
  companySelectedKeys,
  companyExpandedKeys,
  companyTreeData,
  replaceFields,
  //我的图表库
  myChartSelectedKeys,
  myChartExpandedKeys,
  myChartTreeData,
  nodeClick,
  getTree,
  companyExpand,
  myChartExpand
} = useChartTree(tabIndex, emits)
const changeTab = async () => {
  await getTree(tabIndex.value)
  emits('get-chart-list', { tabIndex: tabIndex.value, node: { id: 0 } })
}
</script>
<style scoped lang="scss">
$gap8: 8px;
.chart-set-tree {
  height: 100%;
  .gl-spin-nested-loading {
    height: 100%;
    :deep(.gl-spin-container) {
      height: 100%;
    }
  }
  .tab-group {
    :deep(.gl-radio-group) {
      width: 100%;
      margin-bottom: $gap8;
    }
    :deep(.gl-radio-button-wrapper) {
      width: 50%;
      text-align: center;
      padding: 0;
    }
  }
  .tree-wrap {
    height: calc(100% - 48px);
    overflow-y: auto;
  }
}
</style>
