/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-25 17:23:57
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-06 15:04:56
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap = {
  // 图表管理目录
  queryChartsCatalogueList: {
    method: 'post',
    url: '/database/catalogue/listTree'
  },
  // 图表列表
  queryChartsList: {
    method: 'post',
    url: '/database/chart/list'
  }
}
export default request(apiMap)
