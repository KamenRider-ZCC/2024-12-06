/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-05 10:07:57
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-05 10:09:25
 * @Description:
 */
//图例位置
export const LEGEND_POSITION: any = {
  top: {
    orient: 'horizontal',
    x: 'center',
    y: 'top'
  },
  bottom: {
    orient: 'horizontal',
    x: 'center',
    y: 'bottom'
  },
  left: {
    orient: 'vertical',
    x: 'left',
    y: 'center'
  },
  right: {
    orient: 'vertical',
    x: 'right',
    y: 'center'
  }
}

//横坐标时间格式
export const TIME_FORMAT: any = {
  'slash-YMD': 'YYYY/MM/DD',
  'slash-YM': 'YYYY/MM',
  'slash-MD': 'MM/DD',
  'slash-Y': 'YYYY',
  'slash-M': 'MM',
  'cross-YMD': 'YYYY-MM-DD',
  'cross-YM': 'YYYY-MM',
  'cross-MD': 'MM-DD',
  'cross-Y': 'YYYY',
  'cross-M': 'MM',
  'word-YMD': 'YYYY年MM月DD日',
  'word-YM': 'YYYY年MM月',
  'word-MD': 'MM月DD日',
  'word-Y': 'YYYY年',
  'word-M': 'MM月'
}
//线型
export const SERIES_TYPE: any = {
  line: 'line',
  bar: 'bar',
  area: 'line',
  stacking: 'bar',
  percentageStacking: 'bar'
}
