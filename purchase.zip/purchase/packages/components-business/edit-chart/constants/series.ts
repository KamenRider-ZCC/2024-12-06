const bar = function () {
  return {
    type: 'bar',
    barMaxWidth: 50,
    markPoint: {
      data: []
    },
    itemStyle: {
      color: ''
    }
  }
}

const line = function () {
  return {
    type: 'line',
    smooth: true,
    symbolSize: [4, 4],
    symbol: 'emptyCircle',
    showSymbol: true,
    connectNulls: true,
    itemStyle: {
      color: ''
    },
    lineStyle: {
      width: 1,
      color: ''
    },
    label: {
      show: false,
      position: 'top'
    }
  }
}

const area = function () {
  return {
    type: 'line',
    smooth: true,
    symbolSize: 4,
    symbol: 'emptyCircle',
    connectNulls: true,
    itemStyle: {
      color: ''
    },
    areaStyle: {
      color: ''
    },
    lineStyle: {
      width: 2,
      color: ''
    }
  }
}

const pieSimple = function () {
  return {
    type: 'pie',
    center: ['50%', '50%'],
    labelLayout: {
      hideOverlap: false
    },
    label: {
      color: '#333333',
      show: true,
      fontFamily: '微软雅黑',
      fontSize: 12,
      fontWeight: 'normal',
      fontStyle: 'normal'
    },
    radius: [0, 100],
    startAngle: ''
  }
}

export default {
  'bar-simple': bar,
  'line-simple': line,
  'area-simple': area,
  'pie-simple': pieSimple
}
