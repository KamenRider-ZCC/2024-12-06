<template>
  <ms-chart
    ref="chart"
    class="chart"
    autoresize
    :option="msChartOption"
    :update-options="{ notMerge: true, lazyUpdate: false }"
    :init-options="{ devicePixelRatio: 2 }"
  />
</template>

<script setup lang="ts">
import { MsChart } from '@mysteel-standard/components'
import useBarLineOptions from './composables/use-bar-line-options'
import usePieOptions from './composables/use-pie-options'
import useScatterOptions from './composables/use-scatter-options'
import useRadarOptions from './composables/use-radar-options'
import usePhoneOptions from './composables/use-phone-options'
import { getNullOption } from '@mysteel-standard/utils'
import style from './constants/style'
import { nextTick, computed, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { _blueTheme, deepClone } from '@mysteel-standard/utils'

const route = useRoute()
//props
interface Props {
  curEl: any
  seasonChecked?: boolean
  indexDataSeason?: any[]
  isPhone?: boolean
}
const props = withDefaults(defineProps<Props>(), {
  isPhone: false
})

const imgUrl = computed(() => new URL('./assets/bottom-line.png', import.meta.url).href)
const chartOption = ref(style['bar-line']())

//处理折线柱状图形函数
const { setBarLineSeries, setBarLineLegend, setBarLineXAxis, setBarLineYAxis, setPosition } =
  useBarLineOptions(chartOption, props, imgUrl)

//处理饼图形函数
const { setPieSeries, setPieLegend } = usePieOptions(chartOption, props, imgUrl)
//处理散点图 函数
const { setScatterSeries, setScatterXAxis, setScatterYAxis } = useScatterOptions(
  chartOption,
  props,
  imgUrl
)
//移动端样式处理
const { setPhoneOption } = usePhoneOptions(chartOption, props)
//处理散点图 函数
const { setRadar } = useRadarOptions(chartOption, props, imgUrl)

//季节性变化监听
watch(
  () => props.indexDataSeason,
  (newVal: any) => {
    if (newVal.length) {
      if (newVal.some((item: { data: any[] }) => item.data?.length)) {
        nextTick(() => {
          setBarLineSeries(null)
          setBarLineLegend(null)
          setBarLineXAxis()
          setBarLineYAxis(null)
          setPhoneOption()
        })
      } else {
        chartOption.value = getNullOption('')
      }
    } else {
      chartOption.value = getNullOption('')
    }
  },
  {
    deep: true
  }
)
//监听options
watch(
  () => props.curEl,
  async (newVal: any) => {
    const { contentOption } = newVal
    if (newVal.id === 'bar-line') {
      if (
        contentOption.indexOptionsBarLine.some((item: { data: any[] }) => item.data?.length) ||
        contentOption.seasonChecked
      ) {
        await nextTick()
        chartOption.value = style['bar-line']()
        setBarLineSeries(newVal.echartType)
        setBarLineLegend(null)
        setBarLineYAxis(newVal.echartType)
        setBarLineXAxis()
      } else {
        chartOption.value = getNullOption('')
      }
      const { legendLayout } = contentOption
      setPosition(legendLayout.position)
    } else if (newVal.id === 'chart-pie') {
      chartOption.value = getNullOption('pie')
      if (contentOption.indexOptionsPie.some((item: { data: any[] }) => item.data?.length)) {
        await nextTick()
        chartOption.value = style['chart-pie']()
        setPieSeries()
        setPieLegend()
      } else {
        chartOption.value = getNullOption('pie')
      }
    } else if (newVal.id === 'scatter-plot') {
      if (contentOption.indexOptionsScatter.some((item: { data: any[] }) => item.data?.length)) {
        await nextTick()
        chartOption.value = style['scatter-plot']()
        //注意这里要渲染XAxis、YAxis，因为setScatterSeries里面有设置XAxis、YAxis
        setScatterXAxis()
        setScatterYAxis()
        setScatterSeries()
      } else {
        chartOption.value = getNullOption('')
      }
    } else if (newVal.id === 'chart-radar') {
      chartOption.value = getNullOption('radar')
      if (
        contentOption.indexOptionsRadar.list.filter((v: { checked: boolean }) => v.checked).length >
        0
      ) {
        await nextTick()
        setRadar()
      } else {
        chartOption.value = getNullOption('pie')
      }
    }
    setPhoneOption()
  },
  { deep: true, immediate: true }
)

const msChartOption = computed(() => {
  // console.log('chartOption.value', chartOption.value, route?.fullPath)
  if (route?.fullPath === '/panorama-screen') {
    const deOption = {
      backgroundColor: '#ffffff',
      legend: {
        ...chartOption.value.legend,
        textStyle: {
          color: '#ffffff',
          ...chartOption.value.legend?.textStyle
        }
      }
    }
    const dataZoom = chartOption.value.dataZoom?.map((item: any) => {
      return {
        ...item,
        backgroundColor: '#fff',
        fillerColor: '#fff',
        borderColor: '#fff',
        textStyle: {
          color: '#fff'
        },
        handleStyle: {
          color: '#fff',
          borderColor: '#fff'
        }
      }
    })
    return deepClone(_blueTheme, { ...chartOption.value, ...deOption, dataZoom })
  } else {
    console.log(chartOption.value);
    
    return chartOption.value
  }
})

defineExpose({
  chartOption
})
</script>

<style lang="scss" scoped></style>
