/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-19 14:21:05
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-10 20:05:35
 * @Description: 散点图option设置
 */
import { cloneDeep } from 'lodash-es'
import style from '../constants/style'
export default (chartOption: any, props: any, imgUrl: any) => {
  //初始化数据
  const initScatterOption = style['scatter-plot']()
  //设置散点图series
  const setScatterSeries = () => {
    const { series, tooltip } = initScatterOption
    const { contentOption } = props.curEl
    const sery = cloneDeep(series[0])
    const scatterData = [...contentOption.indexOptionsScatter]
    const datas = scatterData
      .filter((y) => y.checked)
      .map((item) => {
        let relateData = 0
        let relateName = ''
        if (item.relatedIndexCode) {
          relateData =
            scatterData.filter((query) => query.indexCode === item.relatedIndexCode)[0]?.data || 0
          relateName =
            scatterData.filter((query) => query.indexCode === item.relatedIndexCode)[0]
              ?.legendName || ''
        }
        const curData = [
          item.axis === 'x' ? item.data || 0 : relateData,
          item.axis === 'x' ? relateData : item.data,
          item.symbolSize,
          item.itemColor,
          item.labelName || item.legendName,
          item.legendName,
          relateName
        ]
        return curData
      })

    chartOption.value.series[0] = {
      ...sery,
      data: datas,
      symbolSize(val: any) {
        return val[2]
      },
      itemStyle: {
        color({ data }: { data: any }) {
          return data[3]
        }
      },
      label: {
        position: 'top',
        show: true,
        formatter({ data }: { data: any }) {
          return data[4]
        }
      }
    }
    chartOption.value.tooltip = {
      ...tooltip,
      formatter({ data }: { data: any }) {
        return `${data[4]} <br />${data[5]}:${data[0]}<br />${
          data[6] ? `${data[6]}:${data[1]}` : data[1]
        }`
      }
    }
    //横纵轴最大值，最小值
    if (contentOption.scatterXAxis.min) {
      chartOption.value.xAxis.min = contentOption.scatterXAxis.min
    }
    if (contentOption.scatterXAxis.max) {
      chartOption.value.xAxis.max = contentOption.scatterXAxis.max
    }

    if (contentOption.scatterXAxis.interval) {
      chartOption.value.xAxis.interval = contentOption.scatterXAxis.interval
    }
    if (contentOption.scatterYAxis.min) {
      chartOption.value.yAxis.min = contentOption.scatterYAxis.min
    }
    if (contentOption.scatterYAxis.max) {
      chartOption.value.yAxis.max = contentOption.scatterYAxis.max
    }
    if (contentOption.scatterYAxis.interval) {
      chartOption.value.yAxis.interval = contentOption.scatterYAxis.interval
    }
  }
  //设置散点图xAxis
  const setScatterXAxis = () => {
    const { xAxis } = initScatterOption
    const { contentOption } = props.curEl
    chartOption.value.xAxis = {
      ...xAxis,
      name: contentOption.scatterXAxis.name,
      nameTextStyle: {
        ...xAxis.nameTextStyle,
        ...contentOption.scatterXAxis.nameTextStyle,
        backgroundColor: {
          image:
            contentOption.scatterXAxis.nameTextStyle.textDecoration === 'underline'
              ? imgUrl.value
              : 'transparent'
        }
      },
      axisLine: {
        ...xAxis.axisLine,
        ...contentOption.scatterXAxis.axisLine
      },
      splitLine: {
        ...xAxis.splitLine,
        ...contentOption.legendLayoutScatter.xSplitLine
      },
      axisLabel: {
        ...xAxis.axisLabel,
        ...contentOption.scatterXAxis.nameTextStyle,
        backgroundColor: {
          image:
            contentOption.scatterXAxis.nameTextStyle.textDecoration === 'underline'
              ? imgUrl.value
              : 'transparent'
        }
      }
    }
  }
  //设置散点图yAxis
  const setScatterYAxis = () => {
    const { yAxis } = initScatterOption
    const { contentOption } = props.curEl
    chartOption.value.yAxis = {
      ...yAxis,
      show: contentOption.scatterYAxis.show,
      name: contentOption.scatterYAxis.unit,
      nameTextStyle: {
        ...yAxis.nameTextStyle,
        ...contentOption.scatterYAxis.nameTextStyle,
        backgroundColor: {
          image:
            contentOption.scatterYAxis.nameTextStyle.textDecoration === 'underline'
              ? imgUrl.value
              : 'transparent'
        }
      },
      axisLine: {
        ...yAxis.axisLine,
        ...contentOption.scatterYAxis.axisLine
      },
      splitLine: {
        ...yAxis.splitLine,
        ...contentOption.legendLayoutScatter.ySplitLine
      },
      axisLabel: {
        ...yAxis.axisLabel,
        ...contentOption.scatterYAxis.nameTextStyle,
        backgroundColor: {
          image:
            contentOption.scatterYAxis.nameTextStyle.textDecoration === 'underline'
              ? imgUrl.value
              : 'transparent'
        }
      }
    }
  }

  return { setScatterSeries, setScatterXAxis, setScatterYAxis }
}
