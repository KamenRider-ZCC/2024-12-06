/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-19 14:21:05
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-10 10:47:55
 * @Description: 折线，柱状图option设置
 */
import { cloneDeep } from 'lodash-es'
import style from '../constants/style'
import { LEGEND_POSITION, SERIES_TYPE, TIME_FORMAT } from '../constants/index'
import moment from 'moment'
import { calendar } from '@mysteel-standard/utils'
import { ref } from 'vue'
export default (chartOption: any, props: any, imgUrl: any) => {
  //初始化数据
  const percentageStackingYIndex = ref(0)
  const initOption = style['bar-line']()
  let yAxisIndexArr: number[] = []

  //设置line-bar:series
  const setBarLineSeries = (echartType: string | null) => {
    const { contentOption } = props.curEl
    const { series } = initOption
    const percentageData: any = []
    const result: any = []
    yAxisIndexArr = []
    // 季节性分析-勾选的年份
    const checkedSeasonArr: any = []
    // 提取已勾选的年份
    // console.log(contentOption?.seasonOptions, props.indexDataSeason)
    // const checkedSeasonArr: string[] = Object.keys(contentOption?.seasonOptions)
    const contentOptionSeasons: any[] = Object.entries(contentOption?.seasonOptions)
    contentOptionSeasons.sort((a, b) => b[0] - a[0])

    const seasonContentOption: any = {}
    for (let i = 0; i < props.indexDataSeason.length; i++) {
      const itemContentSeason = contentOptionSeasons[i]
      if (itemContentSeason && itemContentSeason[1]) {
        seasonContentOption[props.indexDataSeason[i].legendName] = {
          ...itemContentSeason[1],
          name: props.indexDataSeason[i].legendName
        }
        if (itemContentSeason[1].checked) checkedSeasonArr.push(props.indexDataSeason[i].legendName)
      }
    }

    // console.log('checkedSeasonArr', checkedSeasonArr, contentOptionSeasons, seasonContentOption)

    // for (const v in contentOption?.seasonOptions) {
    //   if (contentOption.seasonOptions[v].checked) checkedSeasonArr.push(v)
    // }

    const indexCodeArr = props.seasonChecked
      ? props.indexDataSeason.filter((item: any) => checkedSeasonArr.includes(item.legendName))
      : contentOption.indexOptionsBarLine.filter((ser: { checked: boolean }) => ser.checked)
    indexCodeArr.forEach((item: { type: string; data: any }) => {
      if (item.type === 'percentageStacking') {
        percentageData.push(item.data)
      }
    })

    const isTypeHasPercentageStacking = indexCodeArr?.some
      ? indexCodeArr.some((item: { type: string }) => item.type === 'percentageStacking')
      : false
    // 设置虚拟Y轴
    const copyY = cloneDeep(contentOption.yAxis)
    const handledPercentageData = handlePercentageData(percentageData)
    if (echartType === 'percentageStacking' || isTypeHasPercentageStacking) {
      const cloneY: any = {}
      cloneY.position = 'right'
      cloneY.max = 100
      const checkIndex = handledPercentageData.findIndex((item: any) => Number(item) < 0)
      cloneY.min = checkIndex === -1 ? 0 : -100
      cloneY.axisLine = {
        lineStyle: {
          color: '#000',
          width: 2,
          type: 'solid',
          opacity: 1
        }
      }
      cloneY.axisLabel = { formatter: (value: string) => `${value}%` }
      copyY.push(cloneY)
      percentageStackingYIndex.value = copyY.length - 1
    }
    chartOption.value.yAxis = copyY
    let percentageDataIndex = 0 // 真实数据下标，防止取错数据
    indexCodeArr.forEach(
      (item: {
        type: string
        legendName: string
        data: any
        yAxisIndex: number
        itemColor: string
        isLabel: string
        labelPosition: string
        lineStyleWidth: string
        lineStyleType: string
        barWidth: string
        id: string
        areaColor: string
      }) => {
        item.id = item.legendName
        const sery = cloneDeep(series[0])
        sery.type = props.seasonChecked ? 'line' : SERIES_TYPE[item.type]
        // tooltip 中的名字
        sery.name = props.seasonChecked
          ? seasonContentOption[item.legendName].name || item.legendName
          : item.legendName
        // sery.name = item.legendName

        sery.data = item.data
        if (item.type === 'percentageStacking') {
          percentageDataIndex += 1
          sery.data = handledPercentageData[percentageDataIndex - 1]
          sery.yAxisIndex = percentageStackingYIndex.value
        } else {
          sery.yAxisIndex = item.yAxisIndex || 0
        }
        if (item.type === 'stacking' || item.type === 'percentageStacking') {
          sery.stack = `stack${sery.yAxisIndex}`
        } else {
          sery.stack = null
        }

        sery.itemStyle = {
          ...sery.itemStyle,
          color: props.seasonChecked
            ? seasonContentOption[item.legendName].itemColor
            : item.itemColor
        }
        sery.label = {
          show: item.isLabel,
          position: item.labelPosition,
          color: '#000000'
        }
        sery.labelLayout = {
          hideOverlap: true
        }
        sery.showSymbol = item.isLabel
        sery.lineStyle = {
          ...sery.lineStyle,
          width:
            (props.seasonChecked
              ? seasonContentOption[item.legendName].lineStyleWidth
              : item.lineStyleWidth) || 1,
          type:
            (props.seasonChecked
              ? seasonContentOption[item.legendName].lineStyleType
              : item.lineStyleType) || 'solid',
          color: props.seasonChecked
            ? seasonContentOption[item.legendName].itemColor
            : item.itemColor
        }
        sery.markLine = {
          symbol: ['none', 'none'],
          label: { show: false },
          lineStyle: { width: 3 },
          itemStyle: {
            color: 'red'
          },
          data: [{ xAxis: '春节' }]
        }
        sery.barWidth = item.barWidth
        sery.areaStyle = item.type === 'area' ? { color: item.areaColor } : null
        result.push(sery)
        yAxisIndexArr.push(item.yAxisIndex || 0)
      }
    )
    chartOption.value.series = result
    // 非季节性分析 && 农历
    if (!props.seasonChecked && props.curEl.contentOption?.dateType === 1) {
      chartOption.value.tooltip = {
        trigger: 'axis',
        formatter: (params: any[]) => {
          const momentObj = moment(params[0]?.axisValue)
          // 公历转农历
          const lunarDate = calendar.solarTolunarMonth(momentObj)
          const arr = [lunarDate]
          arr.push('<table>')
          params?.forEach((p: { marker: any; seriesName: any; value: any }) => {
            arr.push(`<tr>`)
            arr.push(`<td>${p.marker}${p.seriesName}</td>`)
            arr.push(`<td style="padding-left: 15px;text-align: right;">${p.value || '-'}</td>`)
            arr.push(`</tr>`)
          })
          arr.push('</table>')
          return arr.join('')
        }
      }
    }
    chartOption.value.title.text = ''
  }

  //设置line-bar:legend
  const setBarLineLegend = (legendOption: any) => {
    const { legend } = initOption
    const { contentOption } = props.curEl
    let legendArr = []
    // console.log(contentOption, props.indexDataSeason)
    if (props.seasonChecked) {
      // if (contentOption.seasonOptions) {
      //   // legendArr = props.indexDataSeason.map(
      //   //   (item: { legendName: string }) => contentOption.seasonOptions[item.legendName]
      //   // )
      //   legendArr = props.indexDataSeason.map((item: { legendName: any }) => item.legendName)
      // } else {
      //   legendArr = props.indexDataSeason.map((item: { legendName: any }) => item.legendName)
      // }
      legendArr = props.indexDataSeason.map((item: { legendName: any }) => item.legendName)
    } else {
      legendArr = contentOption.indexOptionsBarLine
        ?.filter((sery: { checked: boolean }) => sery.checked)
        .map((item: { legendName: string }) => item.legendName)
    }

    chartOption.value.legend = {
      ...legend,
      data: legendArr,
      textStyle: {
        ...legend.textStyle,
        ...contentOption.legendLayout.textStyle,
        backgroundColor: {
          image:
            contentOption.legendLayout.textStyle.textDecoration === 'underline'
              ? imgUrl.value
              : 'transparent'
        }
      },
      ...LEGEND_POSITION[contentOption.legendLayout.position]
    }
    if (contentOption.legendLayout.position === 'bottom') {
      delete chartOption.value.legend.y
      chartOption.value.legend.bottom = 20
      chartOption.value.legend.left = 'center'
    }
    if (legendOption) {
      chartOption.value.legend = {
        ...chartOption.value.legend,
        ...legendOption,
        textStyle: {
          ...chartOption.value.legend.textStyle,
          ...legendOption?.textStyle
        }
      }
    }
  }

  //设置line-bar:xAxis
  const setBarLineXAxis = () => {
    const { contentOption } = props.curEl
    const { xAxis } = initOption
    let xArr = []
    if (props.seasonChecked) {
      xArr = props.indexDataSeason[0]?.dateList
    } else {
      xArr = contentOption.indexOptionsBarLine[0].dateList
    }
    const format = `${contentOption.xAxis.dataFormat}-${contentOption.xAxis.dataFrequency}`
    chartOption.value.xAxis = {
      ...xAxis,
      data: xArr,
      name: contentOption.xAxis.name,
      nameTextStyle: {
        ...xAxis.nameTextStyle,
        ...contentOption.xAxis.nameTextStyle,
        backgroundColor: {
          image:
            contentOption.xAxis.nameTextStyle.textDecoration === 'underline'
              ? imgUrl.value
              : 'transparent'
        }
      },
      axisLine: {
        ...xAxis.axisLine,
        ...contentOption.xAxis.axisLine
      },
      splitLine: {
        ...xAxis.splitLine,
        ...contentOption.legendLayout.xSplitLine
      },
      axisLabel: {
        ...xAxis.axisLabel,
        ...contentOption.xAxis.nameTextStyle,
        backgroundColor: {
          image:
            contentOption.xAxis.nameTextStyle.textDecoration === 'underline'
              ? imgUrl.value
              : 'transparent'
        },

        formatter(value: string) {
          // 如果是农历X轴显示农历格式
          if (props.curEl.contentOption.xAxis.rangeDate.dateType === 1) {
            return value
          }
          if (moment(value).format(TIME_FORMAT[format]) === 'Invalid date') {
            return value
          } else {
            return props.seasonChecked ? value : moment(value).format(TIME_FORMAT[format])
          }
        }
      }
    }
    chartOption.value.dataZoom = [
      {
        type: 'inside',
        startValue: contentOption.xAxis.rangeDate
          ? moment(contentOption.xAxis.rangeDate[0]).format('YYYY-MM-DD')
          : '',
        endValue: contentOption.xAxis.rangeDate
          ? moment(contentOption.xAxis.rangeDate[1]).format('YYYY-MM-DD')
          : ''
      },
      {
        show: props.showZoom,
        type: 'slider',
        brushSelect: false,
        bottom: 10,
        height: 20
      }
    ]

    if (!contentOption?.xAxis?.rangeDate?.length) {
      chartOption.value.dataZoom[0].start = 0
      chartOption.value.dataZoom[0].end = 100
    }
  }
  //设置line-bar:yAxis
  const setBarLineYAxis = (echartType: string | null) => {
    const { yAxis } = initOption
    const { contentOption } = props.curEl
    const result: any = []

    contentOption.yAxis.forEach(
      (
        item: {
          show: boolean
          unit: string
          nameTextStyle: { textDecoration: string }
          axisLine: string
          min: number
          max: number
          interval: number
          position: string
          inverse: number
          offset: number
        },
        i: number
      ) => {
        const y = cloneDeep(yAxis[0])
        y.show = item.show && yAxisIndexArr.includes(i)
        y.name = item.unit
        y.nameTextStyle = {
          ...y.nameTextStyle,
          ...item.nameTextStyle,
          backgroundColor: {
            image: item.nameTextStyle.textDecoration === 'underline' ? imgUrl.value : 'transparent'
          }
        }
        y.axisLabel = {
          ...y.axisLabel,
          ...item.nameTextStyle,
          backgroundColor: {
            image: item.nameTextStyle.textDecoration === 'underline' ? imgUrl.value : 'transparent'
          },
          formatter(value: string) {
            return value
          }
        }
        y.axisLine = Object.assign(y.axisLine, item.axisLine)
        y.splitLine = {
          ...y.splitLine,
          ...contentOption.legendLayout.ySplitLine
        }
        if (item.min) {
          y.min = item.min
        }
        if (item.max) {
          y.max = item.max
        }
        if (item.interval) {
          y.interval = item.interval
        }
        y.position = item.position
        y.inverse = item.inverse
        y.offset = item.offset
        result.push(y)
      }
    )
    if (!props.seasonChecked) {
      // 设置虚拟Y轴
      const indexCodeArr = contentOption.indexOptionsBarLine.filter(
        (item: { checked: boolean }) => item.checked
      )
      const isTypeHasPercentageStacking = indexCodeArr.some(
        (item: { type: string }) => item.type === 'percentageStacking'
      )
      if (echartType === 'percentageStacking' || isTypeHasPercentageStacking) {
        const cloneY: any = {}
        cloneY.position = 'right'
        cloneY.max = 100
        const percentageData: any[] = []
        indexCodeArr.forEach((item: { type: string; data: any }) => {
          if (item.type === 'percentageStacking') {
            percentageData.push(item.data)
          }
        })
        const handledPercentageData = handlePercentageData(percentageData)
        const checkIndex = handledPercentageData.findIndex((item: any) => Number(item) < 0)
        cloneY.min = checkIndex === -1 ? 0 : -100
        cloneY.axisLine = {
          lineStyle: {
            color: '#000',
            width: 2,
            type: 'solid',
            opacity: 1
          }
        }
        cloneY.axisLabel = { formatter: (value: any) => `${value}%` }
        result.push(cloneY)
        percentageStackingYIndex.value = result.length - 1
      }
    }

    chartOption.value.yAxis = result
  }

  // 将原始数据转换成百分比
  const handlePercentageData = (params: any[]) => {
    const cloneData = cloneDeep(params)
    const { length } = cloneData
    let index = 0
    let totalArray: any = null // 每列数据中每项累加值集合
    const handleAccumulation: any = (firstArr: any[], secondArr: { [x: string]: any }) => {
      const res: number[] = []
      firstArr.forEach((item: unknown, i: string | number) => {
        item = item ? parseFloat(item as string) : 0
        secondArr[i] = secondArr[i] ? parseFloat(secondArr[i]) : 0
        res.push(
          ((
            ((item as number) < 0 ? Math.abs(item as number) : item) +
            (secondArr[i] < 0 ? Math.abs(secondArr[i]) : secondArr[i])
          ).toFixed(0) *
            100) /
            100
        )
      })
      if (index === 0) {
        index += 2
      } else {
        index += 1
      }
      if (index <= length - 1) {
        return handleAccumulation(res, cloneData[index])
      } else {
        return res
      }
    }
    if (length >= 2) {
      totalArray = handleAccumulation(cloneData[index], cloneData[index + 1])
    } else {
      totalArray = cloneData[0] && cloneData[0].map((item: any) => (item ? item : 0))
    }
    return cloneData.map((item: any[]) =>
      item.map((child: unknown, i: string | number) => {
        child = child ? child : 0
        if (!totalArray[i]) {
          return '0'
        } else {
          return `${((parseFloat(child as string) / totalArray[i]) * 100).toFixed(2)}`
        }
      })
    )
  }

  //设置position
  const setPosition = (position: string) => {
    if (position === 'left') {
      setGrid(chartOption, { left: '22%' })
    } else if (position === 'right') {
      setGrid(chartOption, { right: '20%' })
    } else if (position === 'bottom') {
      setGrid(chartOption, { bottom: '17%' })
      setBarLineLegend({
        width: 'auto',
        textStyle: {}
      })
    } else {
      setGrid(chartOption, {})
      setBarLineLegend(null)
    }
  }

  // 设置grid
  const setGrid = (chartOption: any, position: any) => {
    const { grid } = initOption
    chartOption.value.grid = {
      ...grid,
      ...position
    }
  }

  return {
    setBarLineSeries,
    setBarLineLegend,
    setBarLineXAxis,
    setBarLineYAxis,
    setGrid,
    setPosition
  }
}
