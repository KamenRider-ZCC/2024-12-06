/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-19 14:21:05
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-12 20:02:52
 * @Description: 雷达图option设置
 */
import { LEGEND_POSITION, TIME_FORMAT } from '../constants/index'
import moment from 'moment'

export default (chartOption: any, props: any, imgUrl: any) => {
  //设置雷达图
  const setRadar = () => {
    const { contentOption } = props.curEl
    const {
      originData,
      dateList,
      indexOptionsRadar,
      legendLayoutRadar,
      radarAxisLine,
      radarSettings,
      colors
    } = contentOption
    const indexCodesRadarChartChecked = indexOptionsRadar.list.filter(
      (v: { checked: boolean }) => v.checked
    )
    const indexCodesChecked = indexCodesRadarChartChecked.map(
      (v: { indexCode: string }) => v.indexCode
    )

    const displayOriginData = originData.filter((v1: { indexCode: string }) =>
      indexCodesChecked.includes(v1.indexCode)
    )

    const { legend } = legendLayoutRadar
    const indexCodeText = indexOptionsRadar.textStyle

    const radarSettingsChecked = radarSettings.filter((v: { checked: boolean }) => v.checked)
    const legendData = radarSettingsChecked.map((v: { xAxisValue: string }) => v.xAxisValue)

    const indexArr = legendData.map((v: string) => dateList.findIndex((val: string) => val === v))
    const displayData = indexArr.map((v: string | number) =>
      displayOriginData
        .map((v2: { dataVOS: any[] }) =>
          v2.dataVOS.map((y: { dataValue: string }) => (y.dataValue === '-' ? 0 : y.dataValue))
        )
        .map((d: { [x: string]: any }) => d[v] || 0)
    )
    const maxData = Math.max(...displayData.flat().filter((item: number) => item !== null)) || 0
    const minData = Math.min(...displayData.flat().filter((item: number) => item !== null)) || 0
    const max = radarAxisLine.max || radarAxisLine.max === 0 ? radarAxisLine.max : maxData
    const min = radarAxisLine.min || radarAxisLine.min === 0 ? radarAxisLine.min : minData

    const formats = radarSettingsChecked.map(
      (v: { dataFormat: any; dataFrequency: any }) => `${v.dataFormat}-${v.dataFrequency}`
    )
    chartOption.value = {
      color: colors,
      grid: {
        top: '96%',
        left: '8%',
        right: '8%',
        bottom: '6%'
      },
      visualMap: null,
      legend: {
        data: legendData,
        show: true,
        itemGap: 10,
        orient: 'horizontal',
        align: 'auto',
        textStyle: {
          fontSize: legend.textStyle.fontSize,
          fontFamily: legend.textStyle.fontFamily,
          fontWeight: legend.textStyle.fontWeight,
          fontStyle: legend.textStyle.fontStyle,
          backgroundColor: {
            image: legend.textStyle.textDecoration === 'underline' ? imgUrl.value : 'transparent'
          },
          overflow: 'truncate'
        },
        padding: [20, 80],
        z: -1,
        formatter(v: string) {
          const index = legendData.findIndex((val: any) => val === v)
          if (moment(v).format(TIME_FORMAT[formats[index]]) === 'Invalid date') {
            return v
          } else {
            return moment(v).format(TIME_FORMAT[formats[index]])
          }
        },
        ...LEGEND_POSITION[legend.position]
      },
      tooltip: {
        trigger: 'item'
      },
      radar: {
        radius: '60%',
        splitNumber: Math.min(radarAxisLine.splitNumber, 50),
        indicator: indexCodesRadarChartChecked.map((v: { indicatorName: any }, index: any) => ({
          name: v.indicatorName,
          max,
          min,
          axisLabel: {
            show: !index && radarAxisLine.mark === '1',
            formatter(v: number) {
              return v.toFixed(0)
            }
          }
        })),
        axisName: {
          color: indexCodeText.color,
          fontFamily: indexCodeText.fontFamily,
          fontSize: indexCodeText.fontSize,
          fontWeight: indexCodeText.fontWeight,
          fontStyle: indexCodeText.fontStyle,
          backgroundColor: {
            image: indexCodeText.textDecoration === 'underline' ? imgUrl.value : 'transparent'
          }
        },
        axisLine: {
          lineStyle: {
            type: radarAxisLine.lineStyleType,
            width: radarAxisLine.lineStyleWidth,
            color: radarAxisLine.color
          }
        }
      },
      series: [
        {
          name: '',
          type: 'radar',
          data: indexArr.map((v: any, k: string | number) => ({
            value: displayData[k],
            name: legendData[k],
            lineStyle: {
              width: radarSettings[k].lineStyleWidth,
              type: radarSettings[k].lineStyleType
            },
            itemStyle: {
              color: radarSettings[k].itemColor
            }
          }))
        }
      ]
    }
  }

  return { setRadar }
}
