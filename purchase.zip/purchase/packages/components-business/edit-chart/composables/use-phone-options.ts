/*
 * @Autor: zhouwanwan
 * @Date: 2023-09-21 16:46:21
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 10:41:08
 * @Description:
 */
import { nextTick } from 'vue'
export default (chartOption: any, props: any) => {
  const setFontSize = (data: any, size?: any) => {
    if (data) {
      data['fontSize'] = size || 12
    }
  }
  const changePhoneOption = () => {
    const { legend, title, grid, dataZoom, series } = chartOption.value
    let phoneGrid = {}
    if (grid) {
      phoneGrid = {
        top: '8px',
        left: '8px',
        right: '8px',
        bottom: '8px',
        containLabel: true
      }
      Object.assign(grid, phoneGrid)
    }
    if (legend) {
      legend && setFontSize(legend.textStyle)
      if (grid) {
        if (legend.y === 'top') {
          legend.padding = [8, 8]
          phoneGrid = {
            top: '40px',
            left: '8px',
            right: '8px',
            bottom: '8px',
            containLabel: true
          }
        } else {
          legend.padding = [0, 8, -8, 8]
          if (series[0].type === 'radar') {
            legend.padding = [0, 8, 8, 8]
          }
          phoneGrid = {
            top: '8px',
            left: '8px',
            right: '8px',
            bottom: '40px',
            containLabel: true
          }
        }
        Object.assign(grid, phoneGrid)
      }
    }
    if (dataZoom && dataZoom.length) {
      dataZoom[1].show = false
    }
    if (title && title.length) {
      title.forEach((item: any) => {
        setFontSize(item.textStyle, 14)
      })
    }
  }
  const setPhoneOption = () => {
    nextTick(() => {
      props.isPhone && changePhoneOption()
    })
  }
  return {
    setPhoneOption
  }
}
