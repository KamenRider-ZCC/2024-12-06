<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-14 14:06:16
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-02 16:11:45
 * @Description: 
-->
<template>
  <gl-spin :spinning="mysteelTreeLoading" style="margin-top: 50px">
    <ms-tree
      v-model:expandedKeys="mysteelExpandedKeys"
      autoExpandParent
      block-node
      :tree-data="mysteelTreeData"
      :fieldNames="mysteelFields"
      :load-data="mysteelTreeLoad"
      @select="mysteelNodeClick"
      @expand="mysteelTreeExpand"
    >
      <template #default="{ data }">
        <tree-node-mysteel :data="data"> </tree-node-mysteel>
      </template>
    </ms-tree>
  </gl-spin>
</template>
<script setup lang="ts">
import { MsTree, TreeNodeMysteel } from '@mysteel-standard/components'
import useMysteelTree from '../composables/use-mysteel-tree'
import { MysteelDataType } from '../types/interface'
interface Emits {
  (e: 'extract-index', nodes: MysteelDataType[]): void //添加提取指标
}
const emits = defineEmits<Emits>()

const {
  treeData: mysteelTreeData,
  replaceFields: mysteelFields,
  treeLoading: mysteelTreeLoading,
  onLoadData: mysteelTreeLoad,
  getTreeData: getMysteelTree,
  expandedKeys: mysteelExpandedKeys,
  nodeClick: mysteelNodeClick,
  treeExpand: mysteelTreeExpand
} = useMysteelTree(emits)

defineExpose({ getMysteelTree })
</script>
