/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-18 02:59:23
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-06-18 03:18:54
 * @Description:
 */
import MyCollectionTree from './my-collection-tree.vue'
import MysteelTree from './mysteel-tree.vue'
import CompanyTree from './company-tree.vue'
export default {
  'mysteel-tree': MysteelTree,
  'my-collection-tree': MyCollectionTree,
  'company-tree': CompanyTree
}
