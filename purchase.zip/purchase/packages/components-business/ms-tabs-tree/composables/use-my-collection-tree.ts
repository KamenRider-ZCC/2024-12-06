/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-14 10:38:19
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-11-28 16:47:25
 * @Description:
 */
import api from '../api/index'
import { useTreeExpand } from '@mysteel-standard/hooks'
export default (emits: any, isDirectory?: boolean, frequency?: string) => {
  const treeLoading = ref<boolean>(false)
  const treeData = ref([
    {
      moduleType: 1,
      label: '我的收藏',
      type: 1,
      pid: 0,
      id: 0,
      children: [],
      isLeaf: false,
      isEnd: 0
    }
  ])
  const replaceFields = ref({
    children: 'children',
    title: 'label',
    key: 'id'
  })
  const myCollectSelectedNodes = ref<any>([])
  const getTreeData = async () => {
    treeLoading.value = true
    const params = {
      isDirectory: isDirectory ? '1' : '0', // 是否只查目录 0否 1是
      frequency
    }
    const { err, res } = await api.getCollectIndexList(params)
    treeLoading.value = false
    if (!err && res) {
      const { data } = res
      treeData.value[0].children = data || []
    }
  }
  const getIndexData = async (id: number, frequency?: string) => {
    const params = {
      catalogId: id,
      frequency
    }
    const { err, res } = await api.getCollectIndexList(params)
    treeLoading.value = false
    if (!err && res) {
      res.data.map((item: any) => {
        item.code = item.indexCode
      })
      const addData = res.data.map((item: any) => {
        const obj = {
          ...item,
          dbType: 3
        }
        return obj
      })
      emits('extract-index', addData, myCollectSelectedNodes.value)
    }
  }
  //树选中
  const nodeClick = (selectedKeys: number[], { node }: any) => {
    const { isLeaf, id } = node
    myCollectSelectedNodes.value = [...myCollectSelectedNodes.value, node]
    if (isLeaf) {
      getIndexData(id, frequency)
    } else {
      nodeExpand(node)
    }
  }
  const { expandedKeys, treeExpand, nodeExpand } = useTreeExpand()
  return {
    treeData,
    replaceFields,
    getTreeData,
    treeLoading,
    nodeClick,
    treeExpand,
    expandedKeys
  }
}
