/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 11:23:44
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-01 19:29:07
 * @Description:
 */
import { TabList } from '../types/interface'
import { enumToArray } from '@mysteel-standard/utils'
export default () => {
  const treeRef = ref()
  const tabIndex: any = ref(TabList['公司数据库'])
  const tabData: any = ref(enumToArray(TabList))
  const tabName = computed(() => {
    return tabIndex.value === TabList['我的收藏'] ? 'my-collection-tree' : 'company-tree'
  })
  const tabClick = (e: { target: { value: number } }) => {
    const { value } = e.target
    nextTick(() => {
      value === TabList['我的收藏'] && treeRef.value.getMyCollectionTree()
      if (!treeRef.value?.companyTreeData?.length) {
        value === TabList['公司数据库'] && treeRef.value.getCompanyTree()
      }
    })
  }
  onMounted(() => {
    treeRef.value.getCompanyTree && treeRef.value?.getCompanyTree()
  })
  return {
    tabName,
    tabIndex,
    tabData,
    treeRef,
    tabClick
  }
}
