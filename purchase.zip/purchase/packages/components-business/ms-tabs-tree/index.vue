<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-07-25 10:24:36
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-01 19:26:58
 * @Description: 
-->
<template>
  <div class="ms-tabs-index-tree">
    <div class="tab-group">
      <ms-tabs
        class="tab"
        v-model:value="tabIndex"
        :tabs="tabData"
        @change="(e: any) => tabClick(e)"
      />
    </div>
    <!-- Mysteel数据库,公司数据库，我的收藏 -->
    <div class="tree-wrap" :class="{ 'collect-tree': tabIndex === TabList['我的收藏'] }">
      <keep-alive>
        <component
          :is="components[tabName as any]"
          ref="treeRef"
          :frequency="frequency"
          @extract-index="extractIndex"
        ></component>
      </keep-alive>
    </div>
  </div>
</template>

<script setup lang="ts">
import { MsTabs } from '@mysteel-standard/components'
import useSwitchTree from './composables/use-switch-tree'
import TreeComponents from './components/index'
import { TabList } from './types/interface'

//props
interface Props {
  frequency?: string
}
defineProps<Props>()

interface Emits {
  (e: 'extract-index', nodes: Array<any>, selectedNodes: Array<any>): void //添加提取指标
}
const emits = defineEmits<Emits>()

const components: any = TreeComponents
// // 切换树
const { tabName, tabIndex, tabData, treeRef, tabClick } = useSwitchTree()
// //指标搜索弹框

const extractIndex = (data: Array<any>, selectedNodes: Array<any>) => {
  emits('extract-index', data, selectedNodes)
}
</script>

<style lang="scss" scoped>
.ms-tabs-index-tree {
  height: 100%;
  width: 100%;
  .tab-group {
    :deep(.gl-radio-button-wrapper) {
      font-size: 12px;
      padding: 0 4px;
    }
  }
  .tree-wrap {
    margin-top: 8px;
    height: 90%;
    overflow: auto;
  }
}
</style>
