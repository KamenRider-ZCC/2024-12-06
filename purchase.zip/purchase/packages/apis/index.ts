import { checkLogin, getTokenUser } from './request/login/login'
import request from './axios'

export { checkLogin, getTokenUser }
export default request as any
