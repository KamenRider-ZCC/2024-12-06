import axios from "../../../axios"

const apiMap = {
  getTokenUser: {
    method: "get",
    url: "/framework/token/getTokenUser"
  }
}

export default axios(apiMap) as {
  getTokenUser: (params: any) => Promise<any>
}