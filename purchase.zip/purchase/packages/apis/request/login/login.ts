import cookie from '../cookie';
import api from './api/index'
import router from '@/router'

function checkLogin() {
  const code = _getCodeByUrl();
  if (!code) {
    localStorage.setItem('login', 'false')
    getCode()
  }
}

function _getCodeByUrl() {
  let _code = localStorage.getItem('code');
  if (!_code) {
    const params = new URLSearchParams(new URL(location.href).searchParams)
    
    _code = params.get('code');
  
    if (_code) {
      localStorage.setItem('code', _code!)
    } 
  }
  return _code;
}

function getCode() {
    const url ='https://iam.trinasolar.com/mga/sps/oauth/oauth20/authorize';
    let redirect_uri = 'http://172.22.3.17/fw_front/'
    if (import.meta.env.MODE === 'development') {
      redirect_uri = 'http://localhost:8099'
    }
    const params ={
      response_type:'code',
      client_id:'sci_insight_cli',
      redirect_uri
    };
    
    const newUrl = url +'?'+ new URLSearchParams(params).toString();
    location.href = newUrl
}


interface IuserInfo {
  accessToken: string
  userType: number
  companyId: string
  companyName: string
  menuPermissions: string
}

async function getTokenUser() {
  if (!cookie.get('accessToken')) {
    const { res, err } = await api.getTokenUser({
      code: localStorage.getItem('code')
    })
    if (!err && res) {
      const localStorage = window.localStorage
      const userInfo: IuserInfo = res.data
      if (localStorage) {
        const { menuPermissions } = userInfo
        localStorage.setItem('menuPermissions', JSON.stringify(menuPermissions))
        localStorage.setItem('userInfo', JSON.stringify(userInfo))
        window.sessionStorage.setItem('menuList', '[]')
        cookie.set('companyId', userInfo.companyId, undefined)
        cookie.set('companyName', userInfo.companyName, undefined)
      }
      const baseHref = window.location.origin + window.location.pathname;
      if (userInfo.userType === 1) {
        // router.replace('/company-choose')
        window.location.href = baseHref + "#/company-choose";
      } else {
        window.location.href = baseHref + "#/home";
        // router.replace('/home')
      }
    }
  }
}

export { checkLogin, getTokenUser }