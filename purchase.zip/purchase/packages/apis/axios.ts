/*
 * @Autor: zouchuanfeng
 * @Date: 2023-05-08 10:26:29
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-07 15:13:53
 * @Description:
 */

import axios from './request/http'
import addLog from './request/log'

const request = (apiObj: any) => {
  if (apiObj) {
    const requestMap: { [propName: string]: Function } = {}
    Object.keys(apiObj).forEach((alias) => {
      const { url, config } = apiObj[alias]
      let { method } = apiObj[alias]
      method = method?.toUpperCase()
      requestMap[alias] = (dataOrParams = {}, instanceConf = {}) => {
        const keyName = ['PUT', 'POST', 'PATCH'].includes(method) ? 'data' : 'params'
        setTimeout(() => {
          addLog({ url: apiObj[alias].url, params: dataOrParams })
        }, 100)
        return axios({
          method,
          url,
          [keyName]: dataOrParams,
          ...Object.assign(config || {}, instanceConf)
        })
          .then((res) => {
            return { err: null, res }
          })
          .catch((err) => {
            return { err, res: undefined }
          })
      }
    })
    return requestMap
  } else {
    return axios
  }
}
export default request as any
